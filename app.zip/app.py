"""
CapCut Wiggle — приложение.

Запускает маленький локальный сервер (только на этом компьютере, 127.0.0.1)
и открывает интерфейс отдельным окном через Edge/Chrome в режиме приложения.
Ничего устанавливать не нужно — только Python.

  python app.py              — открыть приложение
  python app.py --no-window  — только сервер (адрес будет в консоли)
"""

import argparse
import base64
import shutil
import tempfile
import json
import os
import secrets
import subprocess
import sys
import threading
import time
import traceback
import urllib.parse
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import capcut_wiggle as cw

def _read_version():
    try:
        return (cw.BASE_DIR / "VERSION").read_text(encoding="utf-8").strip() or "dev"
    except OSError:
        return "dev"


APP_VERSION = _read_version()
import corner
from wiggle_project import CapCutWatch, Project, capcut_exe

BASE = cw.BASE_DIR
UI_DIR = BASE / "ui"
LOG_PATH = BASE / "wiggle_error.log"
TOKEN = secrets.token_urlsafe(18)
PARAM_KEYS = ("position_px", "rotation_deg", "scale_pct", "frequency", "octaves", "keys_per_second")
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def log_error(text):
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S") + "\n" + text + "\n")
    except OSError:
        pass


class NeedAnswer(Exception):
    """Нужен ответ пользователя (например, CapCut открыт или ключи менялись)."""

    def __init__(self, need, **extra):
        super().__init__(need)
        self.payload = {"ok": False, "need": need, **extra}


# ------------------------------------------------------------- логика ----
class Backend:
    def __init__(self):
        self.lock = threading.Lock()
        self.cfg = cw.load_config()
        self.project = None
        self.project_mtime = None
        self.watch = CapCutWatch()
        self.last_beat = None
        self.downloader = corner.Downloader()
        self.jobs = {}
        self.media = {}   # токен -> путь к файлу, который можно отдать в превью

    # ---- общее
    def save_cfg(self):
        with open(cw.CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(self.cfg, f, indent=4, ensure_ascii=False)

    def drafts_dir(self):
        try:
            return cw.find_drafts_dir(self.cfg)
        except SystemExit:
            return None

    def projects(self):
        d = self.drafts_dir()
        if not d:
            return []
        out = []
        for p in cw.project_dirs(d):
            out.append({"name": p.name, "mtime": int(p.stat().st_mtime)})
        return out

    def main_mtime(self):
        if not self.project:
            return None
        try:
            return (self.project.path / "draft_content.json").stat().st_mtime_ns
        except OSError:
            return None

    def open_project(self, name):
        d = self.drafts_dir()
        if not d or not name or not (d / name).is_dir():
            self.project = None
            return None
        self.project = Project(d / name)
        self.project_mtime = self.main_mtime()
        if self.cfg.get("project") != name:
            self.cfg["project"] = name
            self.save_cfg()
        return self.project.info()

    def reload(self):
        if self.project:
            self.project.load()
            self.project_mtime = self.main_mtime()

    def require_safe(self, force):
        st = self.watch.state(self.project.path if self.project else None)
        if not force and not st["safe"]:
            raise NeedAnswer("close_capcut", capcut=st)

    # ---- API
    def api_state(self, _):
        projects = self.projects()
        names = [p["name"] for p in projects]
        current = self.cfg.get("project")
        if current not in names:
            current = names[0] if names else None
        info = self.open_project(current) if current else None
        d = self.drafts_dir()
        return {
            "config": {k: self.cfg.get(k) for k in PARAM_KEYS + ("seed", "same_motion")},
            "drafts_dir": str(d) if d else "",
            "projects": projects,
            "project": info,
            "version": APP_VERSION,
        }

    def api_open(self, body):
        return {"project": self.open_project(body.get("name"))}

    def api_refresh(self, _):
        """Перечитать список проектов и текущий проект с диска (например, после того
        как в CapCut добавили текст). Чтение безопасно даже при открытом CapCut."""
        projects = self.projects()
        names = [p["name"] for p in projects]
        name = self.project.name if self.project else self.cfg.get("project")
        if name not in names:
            name = names[0] if names else None
        for attempt in range(3):  # CapCut мог как раз дописывать файл
            try:
                info = self.open_project(name) if name else None
                return {"ok": True, "projects": projects, "project": info}
            except (json.JSONDecodeError, UnicodeDecodeError, OSError):
                time.sleep(0.4)
        return {"ok": False, "projects": projects,
                "error": "CapCut как раз сохраняет проект — нажми «Обновить» ещё раз."}

    def api_capcut(self, _):
        st = self.watch.state(self.project.path if self.project else None)
        st["changed"] = bool(self.project) and self.main_mtime() != self.project_mtime
        return st

    def api_noise(self, body):
        out = {}
        for s in body.get("seeds") or []:
            s = int(s)
            out[str(s)] = [cw.Noise1D(s * 7919 + k).table for k in range(4)]
        return {"tables": out}

    def api_save_config(self, body):
        for k in PARAM_KEYS:
            if k in body:
                self.cfg[k] = float(body[k])
        if "seed" in body:
            self.cfg["seed"] = int(body["seed"])
        if "same_motion" in body:
            self.cfg["same_motion"] = bool(body["same_motion"])
        self.save_cfg()
        return {"ok": True}

    def api_apply(self, body):
        if not self.project:
            return {"ok": False, "error": "Проект не выбран."}
        self.reload()
        self.require_safe(body.get("force"))
        ids = set(body.get("ids") or [])
        params = {k: float(body["params"][k]) for k in PARAM_KEYS}
        params["octaves"] = int(round(params["octaves"]))
        on_edited = body.get("on_edited")
        edited = self.project.needs_answer(ids)
        if edited and on_edited not in ("current", "restore"):
            raise NeedAnswer("edited", count=len(edited))
        n = self.project.apply(ids, params, int(body.get("seed") or 0),
                               bool(body.get("same_motion")), on_edited or "restore")
        self.project.save()
        self.project_mtime = self.main_mtime()
        self.watch.mark_written(self.project.path)
        return {"ok": True, "count": n, "project": self.project.info()}

    def api_remove(self, body):
        if not self.project:
            return {"ok": False, "error": "Проект не выбран."}
        self.reload()
        self.require_safe(body.get("force"))
        ids = set(body.get("ids") or [])
        st = self.project.statuses(ids)
        known = {i for i, v in st.items() if v != "none"}
        unknown = {e["id"] for e in self.project.elements()
                   if e["id"] in ids and e["status"] == "none" and e["keys"]}
        wipe = body.get("wipe_unknown")
        if unknown and wipe is None:
            raise NeedAnswer("unknown", count=len(unknown))
        if wipe:
            known |= unknown
        if not known:
            return {"ok": True, "count": 0, "project": self.project.info()}
        on_edited = body.get("on_edited")
        edited = self.project.needs_answer(known)
        if edited and on_edited not in ("current", "restore"):
            raise NeedAnswer("edited_remove", count=len(edited))
        n = self.project.remove(known, on_edited or "restore")
        self.project.save()
        self.project_mtime = self.main_mtime()
        self.watch.mark_written(self.project.path)
        return {"ok": True, "count": n, "project": self.project.info()}

    def api_undo(self, body):
        if not self.project:
            return {"ok": False, "error": "Проект не выбран."}
        self.require_safe(body.get("force"))
        n = self.project.undo()
        self.project_mtime = self.main_mtime()
        self.watch.mark_written(self.project.path)
        return {"ok": True, "count": n, "project": self.project.info()}

    def api_launch_capcut(self, _):
        exe = capcut_exe()
        if not exe:
            return {"ok": False, "error": "Не нашёл CapCut — запусти его сам."}
        os.startfile(str(exe))  # noqa — только Windows
        return {"ok": True}

    def api_set_drafts_dir(self, body):
        path = str(body.get("path") or "").strip()
        if path and not Path(os.path.expandvars(os.path.expanduser(path))).is_dir():
            return {"ok": False, "error": "Такой папки нет."}
        self.cfg["drafts_dir"] = path
        self.cfg["project"] = ""
        self.save_cfg()
        return {"ok": True, **self.api_state({})}

    def api_browse(self, _):
        if not sys.platform.startswith("win"):
            return {"path": ""}
        script = ("Add-Type -AssemblyName System.Windows.Forms;"
                  "$f=New-Object System.Windows.Forms.FolderBrowserDialog;"
                  "$f.Description='Папка с проектами CapCut (com.lveditor.draft)';"
                  "if($f.ShowDialog() -eq 'OK'){[Console]::OutputEncoding=[Text.Encoding]::UTF8;$f.SelectedPath}")
        out = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", script],
                             capture_output=True, creationflags=NO_WINDOW).stdout
        return {"path": out.decode("utf-8", "replace").strip()}

    # ---- растяжение по углам
    def media_url(self, path):
        if not path:
            return ""
        tok = uuid.uuid5(uuid.NAMESPACE_URL, path).hex
        self.media[tok] = path
        return f"/media/{tok}/{urllib.parse.quote(Path(path).name)}"

    def corner_payload(self, seg_id):
        d = self.project.main
        _, seg = corner.find_segment(d, seg_id)
        if not seg:
            raise ValueError("Клип не найден — нажми «Обновить».")
        cstate = corner.load_corner_state(self.project.path)
        info = corner.source_info(d, seg, cstate, self.project.state)
        if not info:
            return {"ok": False, "error": "У этого клипа нет видео или картинки — растягивать можно только их."}
        w, h = corner._canvas(d)
        tr = seg.get("target_timerange") or {}
        fps = float(d.get("fps") or 30)
        frames = max(1, int(round(int(tr.get("duration") or 0) / 1e6 * fps)))
        motion = corner.motion_quads(info["seg"], info["material"], w, h, info["lists"], info["uniform"], fps, frames)
        # клипы, которые лежат под выбранным — для фона в превью
        bg = []
        for track in d.get("tracks") or []:
            if track.get("type") != "video":
                continue
            for s in track.get("segments") or []:
                if s.get("id") == seg_id:
                    continue
                bi = corner.source_info(d, s, cstate)
                if not bi:
                    continue
                str_ = s.get("target_timerange") or {}
                bg.append({"url": self.media_url(bi["path"]), "type": bi["type"], "start": int(str_.get("start") or 0),
                           "dur": int(str_.get("duration") or 0), "src_start": bi["src_start"], "speed": bi["speed"],
                           "quad": bi["quad"], "w": bi["asset_w"], "h": bi["asset_h"],
                           "row": s.get("render_index", 0)})
        return {
            "ok": True, "id": seg_id, "url": self.media_url(info["path"]), "type": info["type"],
            "asset_w": info["asset_w"], "asset_h": info["asset_h"], "has_audio": info["has_audio"],
            "src_start": info["src_start"], "speed": info["speed"], "quad": info["quad"],
            "start": int(tr.get("start") or 0), "dur": int(tr.get("duration") or 0),
            "keys": info["keys"], "cornered": info["cornered"],
            "mods": corner.norm_mods((cstate.get(str(seg_id)) or {}).get("mods")),
            "wiggle": self.clip_wiggle(seg_id, cstate),
            "canvas": {"w": w, "h": h}, "fps": fps, "bg": bg,
            "motion": [[[round(c, 2) for c in pt] for pt in q] for q in motion] if motion else None,
            "exists": bool(info["path"]) and Path(info["path"]).exists(),
        }

    def clip_wiggle(self, seg_id, cstate):
        """Рысканье клипа: из ключей CapCut (если наложено) или то, что уже запечено в рендер."""
        st = self.project.state.get(str(seg_id))
        if st and st.get("params"):
            return {"params": st["params"], "seed": int(st["params"].get("seed") or 0)}
        return (cstate.get(str(seg_id)) or {}).get("wiggle")

    def api_corner_info(self, body):
        if not self.project:
            return {"ok": False, "error": "Проект не выбран."}
        return self.corner_payload(body.get("id"))

    def api_corner_save(self, body):
        """Запомнить ключи углов (ещё не отрендеренные), чтобы работа не пропала."""
        if not self.project:
            return {"ok": False}
        drafts = self.cfg.setdefault("corner_drafts", {})
        drafts[f"{self.project.name}/{body.get('id')}"] = {"keys": body.get("keys"), "mods": body.get("mods")}
        self.save_cfg()
        return {"ok": True}

    def api_corner_draft(self, body):
        if not self.project:
            return {"keys": None}
        d = (self.cfg.get("corner_drafts") or {}).get(f"{self.project.name}/{body.get('id')}")
        if isinstance(d, list):          # старый формат — только ключи
            d = {"keys": d}
        return {"keys": (d or {}).get("keys"), "mods": (d or {}).get("mods")}

    def api_ffmpeg(self, _):
        return {"found": bool(corner.ffmpeg_path()), "download": self.downloader.state,
                "codecs": {k: v["label"] for k, v in corner.CODECS.items()}}

    def api_ffmpeg_install(self, _):
        self.downloader.start()
        return {"ok": True}

    def api_render(self, body):
        if not self.project:
            return {"ok": False, "error": "Проект не выбран."}
        if not corner.ffmpeg_path():
            return {"ok": False, "need": "ffmpeg"}
        p = self.corner_payload(body.get("id"))
        if not p.get("ok"):
            return p
        if not p["exists"]:
            return {"ok": False, "error": "Не нашёл исходный файл клипа на диске."}
        keys = body.get("keys") or [{"t": 0, "pts": p["quad"], "ease": "smooth"}]
        codec = body.get("codec") or self.cfg.get("corner_codec") or "prores"
        self.cfg["corner_codec"] = codec
        self.save_cfg()
        info = corner.source_info(self.project.main, corner.find_segment(self.project.main, p["id"])[1],
                                  corner.load_corner_state(self.project.path))
        job = corner.RenderJob({
            "codec": codec, "fps": p["fps"], "dur": p["dur"], "project_dir": str(self.project.path),
            "seg_id": p["id"], "keys": keys, "asset_w": p["asset_w"], "asset_h": p["asset_h"],
            "canvas_w": p["canvas"]["w"], "canvas_h": p["canvas"]["h"], "speed": p["speed"],
            "is_video": p["type"] == "video", "src": info["path"], "src_start": p["src_start"],
            "has_audio": p["has_audio"], "mods": body.get("mods") or p["mods"], "wiggle": p["wiggle"],
            "quad": p["quad"], "motion": p["motion"],
        })
        jid = uuid.uuid4().hex
        self.jobs[jid] = {"job": job, "id": p["id"], "keys": keys, "dur": p["dur"],
                          "mods": body.get("mods") or p["mods"], "wiggle": p["wiggle"]}
        return {"ok": True, "job": jid}

    def api_render_status(self, body):
        j = self.jobs.get(body.get("job"))
        return j["job"].state if j else {"running": False, "error": "Задача не найдена."}

    def api_corner_apply(self, body):
        """Подменить клип готовым рендером (нужно, чтобы проект был закрыт в CapCut)."""
        j = self.jobs.get(body.get("job"))
        if not j or not j["job"].state.get("done"):
            return {"ok": False, "error": "Рендер ещё не готов."}
        self.reload()
        self.require_safe(body.get("force"))
        st = j["job"].state
        cstate = corner.load_corner_state(self.project.path)
        drafts = list(self.project.drafts.values())
        first = str(j["id"]) not in cstate
        corner.replace_with_render(drafts, j["id"], st["out"], j["dur"], st.get("has_audio"), j["keys"], cstate)
        # рысканье этого клипа теперь внутри рендера (вокруг центра клипа), его ключи убраны
        wst = self.project.state.pop(str(j["id"]), None)
        entry = cstate[str(j["id"])]
        if first:
            entry["orig_wiggle_state"] = wst
        entry["mods"] = j["mods"]
        entry["wiggle"] = j["wiggle"]
        self.project.save()
        corner.save_corner_state(self.project.path, cstate)
        self.project_mtime = self.main_mtime()
        self.watch.mark_written(self.project.path)
        return {"ok": True, "count": 1, "project": self.project.info()}

    def api_corner_restore(self, body):
        if not self.project:
            return {"ok": False, "error": "Проект не выбран."}
        self.reload()
        self.require_safe(body.get("force"))
        cstate = corner.load_corner_state(self.project.path)
        ows = (cstate.get(str(body.get("id"))) or {}).get("orig_wiggle_state")
        ok = corner.restore_original(list(self.project.drafts.values()), body.get("id"), cstate)
        if ok:
            # вместе с ключами клипа возвращается и его рысканье
            if ows:
                self.project.state[str(body.get("id"))] = ows
            else:
                self.project.state.pop(str(body.get("id")), None)
            self.project.save()
            corner.save_corner_state(self.project.path, cstate)
            self.project_mtime = self.main_mtime()
            self.watch.mark_written(self.project.path)
        return {"ok": True, "count": int(ok), "project": self.project.info()}

    # ---- мои пресеты (общие для всех проектов)
    PRESET_KINDS = ("wiggle", "corner", "mods")

    def presets_file(self):
        return cw.BASE_DIR / "user_presets.json"

    def load_presets(self):
        try:
            data = json.loads(self.presets_file().read_text(encoding="utf-8"))
        except (OSError, ValueError):
            data = {}
        return {k: list(data.get(k) or []) for k in self.PRESET_KINDS}

    def api_presets_list(self, _):
        return {"ok": True, "presets": self.load_presets()}

    def api_preset_save(self, body):
        kind, name = body.get("kind"), str(body.get("name") or "").strip()[:60]
        if kind not in self.PRESET_KINDS or not name:
            return {"ok": False, "error": "Нужно имя пресета."}
        data = self.load_presets()
        items = [x for x in data[kind] if x.get("name") != name]   # то же имя — перезаписать
        items.append({"id": uuid.uuid4().hex[:10], "name": name, "data": body.get("data")})
        data[kind] = items
        self.presets_file().write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        return {"ok": True, "presets": data}

    def api_preset_delete(self, body):
        data = self.load_presets()
        for k in data:
            data[k] = [x for x in data[k] if x.get("id") != body.get("id")]
        self.presets_file().write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        return {"ok": True, "presets": data}

    # ---- превью (обложка ролика)
    def thumb_dir(self):
        return (self.project.path / "wiggle_thumbs") if self.project else (cw.BASE_DIR / "thumbs")

    def api_thumb_state(self, _):
        d = self.thumb_dir()
        doc = {}
        f = d / "thumb.json"
        if f.exists():
            try:
                doc = json.loads(f.read_text(encoding="utf-8"))
            except ValueError:
                doc = {}
        for l in doc.get("layers") or []:
            if l.get("file"):
                l["url"] = self.media_url(str(d / "assets" / l["file"]))
        # видео проекта — чтобы взять из них кадр
        sources, seen = [], set()
        main = self.project.main if self.project else {}
        for m in ((main or {}).get("materials") or {}).get("videos") or []:
            path = m.get("path") or ""
            if m.get("type") == "video" and path and path not in seen and Path(path).exists():
                seen.add(path)
                sources.append({"name": m.get("material_name") or Path(path).name, "url": self.media_url(path)})
        return {"ok": True, "doc": doc, "sources": sources, "dir": str(d), "project": self.project.name if self.project else ""}

    def api_thumb_save(self, body):
        d = self.thumb_dir()
        d.mkdir(parents=True, exist_ok=True)
        doc = body.get("doc") or {}
        for l in doc.get("layers") or []:
            l.pop("url", None)
        (d / "thumb.json").write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")
        return {"ok": True}

    def api_thumb_upload(self, body):
        data = str(body.get("data") or "")
        head, _, b64 = data.partition(",")
        ext = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "image/gif": ".gif",
               "image/bmp": ".bmp"}.get(head[5:].split(";")[0], ".png")
        a = self.thumb_dir() / "assets"
        a.mkdir(parents=True, exist_ok=True)
        name = uuid.uuid4().hex[:12] + ext
        (a / name).write_bytes(base64.b64decode(b64))
        return {"ok": True, "file": name, "url": self.media_url(str(a / name))}

    def api_thumb_render(self, body):
        if not corner.ffmpeg_path():
            return {"ok": False, "need": "ffmpeg"}
        doc = body.get("doc") or {}
        texts = body.get("texts") or {}
        W, H = int(doc.get("w") or 1280), int(doc.get("h") or 720)
        d = self.thumb_dir()
        tmp = Path(tempfile.mkdtemp(prefix="wiggle_texts_"))
        layers = []
        for l in doc.get("layers") or []:
            if not l.get("visible", True):
                continue
            if l.get("kind") == "text":
                raw = str(texts.get(l["id"]) or "")
                if not raw:
                    continue
                src = tmp / f"{l['id']}.png"
                src.write_bytes(base64.b64decode(raw.partition(",")[2]))
            else:
                src = d / "assets" / str(l.get("file") or "")
                if not src.exists():
                    continue
            spec = {"asset_w": int(l["aw"]), "asset_h": int(l["ah"]), "canvas_w": W, "canvas_h": H,
                    "keys": [{"t": 0, "pts": l["pts"], "r": float(l.get("r") or 0)}], "mods": l.get("mods"),
                    "wiggle": None, "quad": l.get("base") or l["pts"], "motion": None, "is_video": False,
                    "speed": 1.0, "src": str(src)}
            layers.append((spec, max(0.0, min(1.0, float(l.get("opacity", 100)) / 100))))
        job = corner.ThumbJob(W, H, doc.get("bg") or "#000000", layers, d)
        jid = uuid.uuid4().hex
        self.jobs[jid] = {"job": job, "tmp": tmp}
        return {"ok": True, "job": jid}

    def api_thumb_status(self, body):
        j = self.jobs.get(body.get("job"))
        if not j:
            return {"running": False, "error": "Задача не найдена."}
        st = dict(j["job"].state)
        if not st["running"]:
            shutil.rmtree(j["tmp"], ignore_errors=True)
            if st.get("png"):
                st["url"] = self.media_url(st["png"])
        return st

    def api_open_path(self, body):
        """Показать файл или папку в проводнике."""
        p = Path(str(body.get("path") or ""))
        if not p.exists():
            return {"ok": False, "error": "Файл не найден."}
        if sys.platform.startswith("win"):
            if p.is_file():
                subprocess.Popen(["explorer", "/select,", str(p)])
            else:
                os.startfile(str(p))
        else:
            subprocess.Popen(["xdg-open", str(p if p.is_dir() else p.parent)])
        return {"ok": True}

    def api_beat(self, _):
        self.last_beat = time.time()
        return {"ok": True}


# ------------------------------------------------------------- сервер ----
CONTENT_TYPES = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
                 ".js": "text/javascript; charset=utf-8", ".svg": "image/svg+xml",
                 ".png": "image/png", ".ico": "image/x-icon"}


def make_handler(backend):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def send(self, code, body, ctype="application/json; charset=utf-8"):
            data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def send_media(self, file_path):
            p = Path(file_path)
            if not p.is_file():
                return self.send(404, b"not found", "text/plain")
            size = p.stat().st_size
            ext = p.suffix.lower()
            ctype = {".mp4": "video/mp4", ".mov": "video/quicktime", ".webm": "video/webm", ".m4v": "video/mp4",
                     ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp",
                     ".gif": "image/gif", ".bmp": "image/bmp"}.get(ext, "application/octet-stream")
            start, end = 0, size - 1
            rng = self.headers.get("Range")
            if rng and rng.startswith("bytes="):
                a, _, b = rng[6:].partition("-")
                if a:
                    start = int(a)
                    end = int(b) if b else size - 1
                else:
                    start = max(0, size - int(b))
                end = min(end, size - 1)
                self.send_response(206)
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            else:
                self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(end - start + 1))
            self.end_headers()
            try:
                with open(p, "rb") as f:
                    f.seek(start)
                    left = end - start + 1
                    while left > 0:
                        chunk = f.read(min(1 << 20, left))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        left -= len(chunk)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass

        def do_GET(self):
            path = self.path.split("?", 1)[0]
            if path.startswith("/media/"):
                tok = path.split("/")[2]
                if tok in backend.media:
                    return self.send_media(backend.media[tok])
                return self.send(404, b"not found", "text/plain")
            if path == "/":
                path = "/index.html"
            target = (UI_DIR / path.lstrip("/")).resolve()
            if UI_DIR.resolve() not in target.parents or not target.is_file():
                return self.send(404, b"not found", "text/plain")
            data = target.read_bytes()
            if target.name == "index.html":
                data = data.replace(b"{{TOKEN}}", TOKEN.encode())
            self.send(200, data, CONTENT_TYPES.get(target.suffix, "application/octet-stream"))

        def do_POST(self):
            if self.headers.get("X-Token") != TOKEN:
                return self.send(403, {"error": "forbidden"})
            name = self.path.split("?", 1)[0].rsplit("/", 1)[-1]
            fn = getattr(backend, "api_" + name, None)
            if not fn:
                return self.send(404, {"error": "unknown api"})
            try:
                length = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(length) or b"{}")
                with backend.lock:
                    result = fn(body)
                self.send(200, result)
            except NeedAnswer as e:
                self.send(200, e.payload)
            except Exception:
                text = traceback.format_exc()
                log_error(text)
                self.send(500, {"ok": False, "error": text.strip().splitlines()[-1], "trace": text})

    return Handler


def find_browser():
    env = os.environ
    roots = [env.get("ProgramFiles(x86)"), env.get("ProgramFiles"), env.get("LOCALAPPDATA")]
    rels = [r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"]
    for rel in rels:
        for root in roots:
            if root and (Path(root) / rel).exists():
                return Path(root) / rel
    return None


def open_window(url):
    exe = find_browser()
    if not exe:
        webbrowser.open(url)
        return None
    profile = BASE / ".window"
    return subprocess.Popen([
        str(exe), f"--app={url}", f"--user-data-dir={profile}",
        "--window-size=1440,920", "--no-first-run", "--no-default-browser-check",
        "--disable-extensions", "--disable-sync", "--disable-features=Translate,msEdgeSidebarV2",
    ])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-window", action="store_true")
    ap.add_argument("--port", type=int, default=0)
    args = ap.parse_args()

    backend = Backend()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(backend))
    url = f"http://127.0.0.1:{server.server_address[1]}/"
    threading.Thread(target=server.serve_forever, daemon=True).start()

    if args.no_window:
        print("CapCut Wiggle:", url)
        print("TOKEN:", TOKEN)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        server.shutdown()
        return

    proc = open_window(url)
    started = time.time()
    # живём, пока открыто окно. Страница шлёт «пульс» каждые 2 с; у свёрнутого окна
    # браузер замедляет таймеры до раза в минуту, поэтому при живом процессе ждём дольше.
    while True:
        time.sleep(1)
        window_alive = proc is not None and proc.poll() is None
        beat = backend.last_beat
        if beat is None:
            if window_alive or time.time() - started < 60:
                continue
            break
        age = time.time() - beat
        if age < 8 or (window_alive and age < 150):
            continue
        break
    server.shutdown()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log_error(traceback.format_exc())
        raise
