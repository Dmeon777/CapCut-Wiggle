"use strict";
/* Превью (обложка ролика): слои-картинки и текст, у каждого углы, скругление и стек эффектов.
   Итог рендерится тем же движком ffmpeg, что и клипы, в PNG и JPG. */

const TH_SIZES = [[1280, 720, "YouTube 1280×720"], [1920, 1080, "Full HD 1920×1080"], [1080, 1920, "Вертикальное 1080×1920"], [1080, 1080, "Квадрат 1080×1080"]];
/* шрифты с кириллицей: [название, начертания для Google Fonts] — null значит системный */
const TH_FONTS = [
  ["Montserrat", "400;700;900"], ["Rubik", "400;700;900"], ["Oswald", "400;700"], ["Russo One", ""], ["Unbounded", "400;700;900"],
  ["Exo 2", "400;700;900"], ["Press Start 2P", ""], ["Rubik Mono One", ""], ["Lobster", ""], ["Pacifico", ""], ["Comfortaa", "400;700"],
  ["Ruslan Display", ""], ["Days One", ""], ["Yanone Kaffeesatz", "400;700"], ["Rubik Glitch", ""],
  ["Impact", null], ["Arial Black", null], ["Segoe UI", null],
];
const TEXT_DEFAULTS = { value: "Текст", font: "Russo One", weight: 400, size: 120, color: "#ffffff", color2: "#ffd000",
  gradient: false, italic: false, spacing: 0, line: 105, align: "center", upper: true };
/* стили: настройки текста + готовый стек эффектов ("warp" — черта растяжения) */
const TEXT_STYLES = [
  { name: "Ютуб", text: { font: "Russo One", weight: 400, color: "#ffffff", gradient: false, italic: false, upper: true },
    fx: [["outline", { width: 12, color: "#000000" }], "warp", ["shadow", { x: 0, y: 12, blur: 24, opacity: 70 }]] },
  { name: "Кликбейт", text: { font: "Montserrat", weight: 900, color: "#ffe100", gradient: false, italic: false, upper: true },
    fx: [["outline", { width: 14, color: "#000000" }], "warp", ["shadow", { x: 6, y: 14, blur: 10, opacity: 85 }]] },
  { name: "Неон", text: { font: "Comfortaa", weight: 700, color: "#ffffff", gradient: false, italic: false, upper: false },
    fx: [["outline", { width: 4, color: "#ff2fd0" }], ["outline", { width: 0, soft: 50, opacity: 260, color: "#ff2fd0" }], "warp"] },
  { name: "Ретро", text: { font: "Press Start 2P", weight: 400, color: "#8cff3a", gradient: false, italic: false, upper: true },
    fx: [["outline", { width: 8, color: "#0b1a00" }], "warp", ["pixel", { size: 6 }]] },
  { name: "Огонь", text: { font: "Rubik", weight: 900, color: "#fff200", color2: "#ff3d00", gradient: true, italic: false, upper: true },
    fx: [["outline", { width: 8, color: "#2a0500" }], ["outline", { width: 0, soft: 45, opacity: 200, color: "#ff5a00" }], "warp"] },
  { name: "Лёд", text: { font: "Exo 2", weight: 900, color: "#ffffff", color2: "#5fd0ff", gradient: true, italic: true, upper: true },
    fx: [["outline", { width: 6, color: "#06243f" }], ["outline", { width: 0, soft: 35, opacity: 180, color: "#5fd0ff" }], "warp"] },
  { name: "Комикс", text: { font: "Rubik Mono One", weight: 400, color: "#ffffff", gradient: false, italic: false, upper: true },
    fx: [["outline", { width: 10, color: "#000000" }], ["shadow", { x: 12, y: 12, blur: 0, opacity: 100, color: "#000000" }], "warp"] },
  { name: "Сталкер", text: { font: "Ruslan Display", weight: 400, color: "#e8dcb0", color2: "#9c8a52", gradient: true, italic: false, upper: true },
    fx: [["outline", { width: 6, color: "#120d05" }], "warp", ["shadow", { x: 0, y: 10, blur: 30, opacity: 80 }]] },
  { name: "Глитч", text: { font: "Rubik Glitch", weight: 400, color: "#ffffff", gradient: false, italic: false, upper: true },
    fx: [["outline", { width: 0, soft: 24, opacity: 200, color: "#00e5ff" }], "warp", ["shadow", { x: -8, y: 0, blur: 0, opacity: 80, color: "#ff0055" }]] },
  { name: "Минимал", text: { font: "Montserrat", weight: 700, color: "#ffffff", gradient: false, italic: false, upper: false },
    fx: ["warp", ["shadow", { x: 0, y: 6, blur: 28, opacity: 60 }]] },
];
const styleStack = (st) => normMods({ stack: st.fx.map((x) => (x === "warp" ? { type: "warp" } : { type: x[0], ...x[1] })) });

function loadFontsCss() {
  if (document.getElementById("thFontsCss")) return;
  const fams = TH_FONTS.filter((f) => f[1] !== null).map(([n, w]) => "family=" + n.replace(/ /g, "+") + (w ? ":wght@" + w : ""));
  const link = document.createElement("link");
  link.id = "thFontsCss"; link.rel = "stylesheet";
  link.href = "https://fonts.googleapis.com/css2?" + fams.join("&") + "&display=swap";
  document.head.append(link);
}

/* текст -> картинка с прозрачностью; рисуем в 2 раза крупнее, чтобы при растяжении оставался чётким */
async function rasterText(t) {
  const px = t.size * 2;
  const font = `${t.italic ? "italic " : ""}${t.weight} ${px}px "${t.font}", "Segoe UI", sans-serif`;
  const value = (t.upper ? t.value.toUpperCase() : t.value) || " ";
  try { await document.fonts.load(font, value); } catch { /* нет сети — системный шрифт */ }
  const lines = value.split("\n");
  const c = document.createElement("canvas"), g = c.getContext("2d");
  const setup = () => { g.font = font; g.letterSpacing = t.spacing * 2 + "px"; g.textBaseline = "alphabetic"; };
  setup();
  const m = lines.map((l) => g.measureText(l || " "));
  const asc = Math.max(...m.map((x) => x.fontBoundingBoxAscent || px * 0.8));
  const desc = Math.max(...m.map((x) => x.fontBoundingBoxDescent || px * 0.2));
  const lh = (px * t.line) / 100, pad = Math.ceil(px * 0.18);
  const W = Math.ceil(Math.max(...m.map((x) => x.width), 1) + pad * 2 + (t.italic ? px * 0.2 : 0));
  const H = Math.ceil(asc + desc + lh * (lines.length - 1) + pad * 2);
  c.width = W; c.height = H; setup();
  if (t.gradient) {
    const gr = g.createLinearGradient(0, pad, 0, H - pad);
    gr.addColorStop(0, t.color); gr.addColorStop(1, t.color2);
    g.fillStyle = gr;
  } else g.fillStyle = t.color;
  g.textAlign = t.align;
  const x = t.align === "left" ? pad : t.align === "right" ? W - pad : W / 2;
  lines.forEach((l, i) => g.fillText(l, x, pad + asc + i * lh));
  return { url: c.toDataURL("image/png"), aw: W, ah: H };
}

const rectQuad = (x, y, w, h) => [[x, y], [x + w, y], [x, y + h], [x + w, y + h]];
const inQuad = (q, x, y) => {   // точка внутри четырёхугольника (обход ЛВ, ПВ, ПН, ЛН)
  const poly = [q[0], q[1], q[3], q[2]];
  let inside = false;
  for (let i = 0, j = 3; i < 4; j = i++) {
    const [xi, yi] = poly[i], [xj, yj] = poly[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
};

/* ======================================================================= */
const TH = {
  active: false,
  doc: null,        // { w, h, bg, layers: [...] } — слои снизу вверх
  rt: new Map(),    // id -> { L, src }
  sel: null,
  k: 1,
  loaded: false,
  sources: [],
  dir: "",

  /* ---------- вход и выход ---------- */
  async enter() {
    this.active = true;
    loadFontsCss();
    $("thFrame").hidden = false; $("frame").hidden = true;
    $("thPanel").hidden = false;
    $("playBtn").hidden = true; $("cpScrub").hidden = true;
    $("stageEmpty").hidden = true;
    if (!this.loaded || this._project !== (S.project && S.project.name)) await this.load();
    this.layout();
    this.renderAll();
    this.syncInspector();
    $("stageCaption").textContent = `Обложка ${this.doc.w}×${this.doc.h}`;
    $("clipTitle").textContent = "";
  },
  leave() {
    if (!this.active) return;
    this.active = false;
    $("thFrame").hidden = true; $("frame").hidden = false;
    $("thPanel").hidden = true;
    $("playBtn").hidden = false;
  },

  async load() {
    const st = await api("thumb_state");
    this._project = S.project && S.project.name;
    this.sources = st.sources || [];
    this.dir = st.dir || "";
    for (const r of this.rt.values()) disposeLayer(r.L);
    this.rt.clear();
    const d = st.doc || {};
    this.doc = { w: d.w || 1280, h: d.h || 720, bg: d.bg || "#101014", layers: [] };
    for (const l of d.layers || []) {
      const layer = { opacity: 100, r: 0, visible: true, ...l, mods: normMods(l.mods) };
      if (layer.kind === "text") layer.text = { ...TEXT_DEFAULTS, ...(l.text || {}) };
      this.doc.layers.push(layer);
    }
    this.sel = null;
    this.loaded = true;
    for (const l of this.doc.layers) await this.mount(l);
    this.renderRows();
  },

  saveSoon() {
    clearTimeout(this._saveT);
    this._saveT = setTimeout(() => api("thumb_save", { doc: this.doc }), 400);
  },

  /* ---------- раскладка ---------- */
  layout() {
    if (!this.active) return;
    const stage = $("stage"), f = $("thFrame"), pad = 28;
    const sw = stage.clientWidth - pad * 2, sh = stage.clientHeight - pad * 2;
    const k = Math.max(0.05, Math.min(sw / this.doc.w, sh / this.doc.h));
    f.style.width = this.doc.w * k + "px"; f.style.height = this.doc.h * k + "px";
    this.k = k;
    $("thBg").style.background = this.doc.bg;
    for (const l of this.doc.layers) this.applyLayerFx(l);
    this.renderAll();
  },

  /* ---------- слои: DOM ---------- */
  async mount(l) {
    let url = l.url, aw = l.aw, ah = l.ah;
    const r = { L: null, src: "" };
    if (l.kind === "text") {
      const t = await rasterText(l.text);
      url = r.src = t.url;
      if (t.aw !== l.aw || t.ah !== l.ah) this.refit(l, t.aw, t.ah);
      aw = l.aw; ah = l.ah;
    }
    r.L = makeLayerDom(url, "image", aw, ah);
    r.L.s0 = this.s0(l);
    this.rt.set(l.id, r);
    $("thLayers").append(r.L.box);
    this.applyLayerFx(l);
    return r;
  },
  restack() {   // порядок DOM = порядок слоёв
    for (const l of this.doc.layers) { const r = this.rt.get(l.id); if (r) $("thLayers").append(r.L.box); }
  },
  s0(l) { return Math.max(1e-6, Math.hypot(l.base[1][0] - l.base[0][0], l.base[1][1] - l.base[0][1]) / l.aw); },

  /* размер текста поменялся — держим тот же центр и наклон */
  refit(l, aw, ah) {
    const w0 = l.aw / 2, h0 = l.ah / 2, w1 = aw / 2, h1 = ah / 2;
    const local = rectQuad((w0 - w1) / 2, (h0 - h1) / 2, w1, h1);
    for (const key of ["pts", "base"]) {
      const A = affine2(rectQuad(0, 0, w0, h0), l[key]);
      l[key] = applyAff(A, local);
    }
    l.aw = aw; l.ah = ah;
  },

  applyLayerFx(l) {
    const r = this.rt.get(l.id); if (!r) return;
    r.L.s0 = this.s0(l);
    applyFx(r.L, l.mods.stack, this.k);
    r.L.box.style.opacity = l.visible ? l.opacity / 100 : 0;
    const rad = (l.r / 100) * Math.min(l.aw, l.ah);
    r.L.skin.style.borderRadius = r.L.reflSkin.style.borderRadius = rad + "px";
  },

  renderAll() {
    if (!this.active || !this.doc) return;
    const k = this.k;
    for (const l of this.doc.layers) {
      const r = this.rt.get(l.id); if (!r) continue;
      const disp = l.pts.map(([x, y]) => [x * k, y * k]);
      r.L.unit.style.transform = matrix3d(l.aw, l.ah, disp);
      if (r.L.shadeFx) renderLayerShade(r.L, disp);
      drawLayerRefl(r.L);
    }
    this.drawHandles();
  },

  /* ---------- ручки выбранного слоя ---------- */
  drawHandles() {
    const svg = $("thHandles");
    const l = this.selLayer();
    svg.innerHTML = "";
    if (!l) return;
    const d = l.pts.map(([x, y]) => [x * this.k, y * this.k]);
    const poly = document.createElementNS(SVGNS, "polygon");
    poly.setAttribute("class", "quad"); poly.dataset.part = "body";
    poly.setAttribute("points", [d[0], d[1], d[3], d[2]].map((p) => p.join(",")).join(" "));
    svg.append(poly);
    d.forEach((p, c) => {
      const h = document.createElementNS(SVGNS, "circle");
      h.setAttribute("r", 7); h.setAttribute("class", "h"); h.dataset.part = String(c);
      h.setAttribute("cx", p[0]); h.setAttribute("cy", p[1]);
      svg.append(h);
    });
    placeRotHandle(makeRotHandle(svg), d, this.drag && this.drag.part === "rot" ? this.drag.angle : null);
  },

  selLayer() { return this.doc && this.doc.layers.find((l) => l.id === this.sel) || null; },
  select(id) {
    this.sel = id;
    this.renderRows(); this.drawHandles(); this.syncInspector();
  },

  toCanvas(ev) {
    const r = $("thFrame").getBoundingClientRect();
    return [(ev.clientX - r.left) / this.k, (ev.clientY - r.top) / this.k];
  },

  pointerDown(ev) {
    if (ev.button !== 0) return;
    const part = ev.target.dataset && ev.target.dataset.part;
    let l = this.selLayer();
    const [x, y] = this.toCanvas(ev);
    if (part == null || !l) {
      // выбор слоя щелчком: сверху вниз, только видимые
      const hit = [...this.doc.layers].reverse().find((q) => q.visible && inQuad(q.pts, x, y));
      if (!hit) { this.select(null); return; }
      if (hit.id !== this.sel) this.select(hit.id);
      l = hit;
    }
    ev.preventDefault();
    $("thFrame").focus();
    this.drag = { l, part: part == null || part === "body" ? "body" : part === "rot" ? "rot" : +part, x0: x, y0: y, start: clonePts(l.pts) };
    if (this.drag.part === "rot") { [this.drag.cx, this.drag.cy] = Q.center(l.pts); this.drag.angle = 0; }
    $("thFrame").setPointerCapture(ev.pointerId);
  },
  pointerMove(ev) {
    const d = this.drag; if (!d) return;
    const [x, y] = this.toCanvas(ev);
    const dx = x - d.x0, dy = y - d.y0;
    if (d.part === "rot") {   // поворот всего слоя вокруг центра
      d.angle = rotDelta(d.cx, d.cy, d.x0, d.y0, x, y, ev.shiftKey);
      d.l.pts = Q.rotate(d.start, d.angle);
    } else if (d.part === "body") d.l.pts = d.start.map(([a, b]) => [a + dx, b + dy]);
    else d.l.pts[d.part] = [d.start[d.part][0] + dx, d.start[d.part][1] + dy];
    this.renderAll();
  },
  pointerUp() {
    if (!this.drag) return;
    this.drag = null;
    this.drawHandles();
    this.saveSoon();
  },
  wheel(ev) {
    const l = this.selLayer(); if (!l) return;
    ev.preventDefault();
    if (ev.shiftKey) l.pts = Q.rotate(l.pts, ev.deltaY > 0 ? 2 : -2);
    else l.pts = Q.scale(l.pts, ev.deltaY > 0 ? 1 / 1.05 : 1.05);
    this.renderAll(); this.saveSoon();
  },

  /* ---------- добавление ---------- */
  newLayer(kind, extra) {
    return { id: kind + "_" + Math.random().toString(36).slice(2, 9), kind, visible: true, opacity: 100, r: 0,
      mods: normMods(null), ...extra };
  },

  async addImageData(dataUrl, name) {
    const up = await api("thumb_upload", { data: dataUrl });
    if (!up.ok) return toast(up.error || "Не получилось сохранить картинку.", { kind: "error" });
    const img = new Image();
    await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = up.url; }).catch(() => {});
    const aw = img.naturalWidth || 512, ah = img.naturalHeight || 512;
    const W = this.doc.w, H = this.doc.h;
    // первая картинка — фоном на весь кадр, остальные — по центру
    const first = !this.doc.layers.some((l) => l.kind === "image");
    const s = first ? Math.max(W / aw, H / ah) : Math.min((W * 0.6) / aw, (H * 0.6) / ah);
    const w = aw * s, h = ah * s;
    const q = rectQuad((W - w) / 2, (H - h) / 2, w, h);
    const l = this.newLayer("image", { name: name || "Картинка", file: up.file, url: up.url, aw, ah, base: clonePts(q), pts: clonePts(q) });
    this.doc.layers.push(l);
    await this.mount(l);
    this.select(l.id); this.renderAll(); this.saveSoon();
  },

  async addFiles(files) {
    for (const f of files) {
      if (!f.type.startsWith("image/")) continue;
      const data = await new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(f); });
      await this.addImageData(data, f.name.replace(/\.[^.]+$/, ""));
    }
  },

  async addText() {
    const st = TEXT_STYLES[0];
    const text = { ...TEXT_DEFAULTS, ...st.text, value: "Текст" };
    const t = await rasterText(text);
    const w = t.aw / 2, h = t.ah / 2;
    const q = rectQuad((this.doc.w - w) / 2, (this.doc.h - h) / 2, w, h);
    const l = this.newLayer("text", { name: "Текст", text, aw: t.aw, ah: t.ah, base: clonePts(q), pts: clonePts(q), mods: styleStack(st) });
    this.doc.layers.push(l);
    await this.mount(l);
    this.select(l.id); this.renderAll(); this.saveSoon();
    requestAnimationFrame(() => { $("thText").focus(); $("thText").select(); });
  },

  async updateText() {
    const l = this.selLayer(); if (!l || l.kind !== "text") return;
    const seq = (this._textSeq = (this._textSeq || 0) + 1);
    const t = await rasterText(l.text);
    if (seq !== this._textSeq) return;   // пока рисовали, текст поменяли ещё раз
    if (t.aw !== l.aw || t.ah !== l.ah) this.refit(l, t.aw, t.ah);
    const r = this.rt.get(l.id);
    r.src = t.url;
    setLayerSource(r.L, t.url, "image", l.aw, l.ah);
    l.name = (l.text.value.split("\n")[0] || "Текст").slice(0, 40);
    this.applyLayerFx(l); this.renderAll(); this.renderRows(); this.saveSoon();
  },

  async pickFrame() {
    if (!this.sources.length) return toast("В проекте нет видео, из которого можно взять кадр.", { kind: "error" });
    const dlg = $("thFrameDlg"), sel = $("thSrc"), vid = $("thVid"), pos = $("thVidPos");
    sel.innerHTML = "";
    this.sources.forEach((s, i) => sel.append(new Option(s.name, i)));
    const load = () => { vid.src = this.sources[+sel.value].url; pos.value = 0; };
    sel.onchange = load;
    vid.onloadedmetadata = () => { vid.currentTime = 0; };
    pos.oninput = () => { if (vid.duration) vid.currentTime = (pos.value / 1000) * vid.duration; };
    load();
    dlg.showModal();
    const v = await new Promise((res) => dlg.addEventListener("close", () => res(dlg.returnValue), { once: true }));
    if (v !== "take" || !vid.videoWidth) { vid.removeAttribute("src"); vid.load(); return; }
    const c = document.createElement("canvas"); c.width = vid.videoWidth; c.height = vid.videoHeight;
    c.getContext("2d").drawImage(vid, 0, 0);
    const name = "Кадр " + fmtTime(vid.currentTime * 1e6, true);
    vid.removeAttribute("src"); vid.load();
    await this.addImageData(c.toDataURL("image/png"), name);
  },

  removeLayer(id) {
    const r = this.rt.get(id);
    if (r) disposeLayer(r.L);
    this.rt.delete(id);
    this.doc.layers = this.doc.layers.filter((l) => l.id !== id);
    if (this.sel === id) this.sel = null;
    this.renderRows(); this.drawHandles(); this.syncInspector(); this.saveSoon();
  },

  async duplicate() {
    const l = this.selLayer(); if (!l) return;
    const c = JSON.parse(JSON.stringify(l));
    c.id = l.kind + "_" + Math.random().toString(36).slice(2, 9);
    c.pts = Q.move(c.pts, 24, 24);
    c.mods.stack.forEach((e) => { if (e.type !== "warp") e.id = fxId(e.type); });
    const i = this.doc.layers.indexOf(l);
    this.doc.layers.splice(i + 1, 0, c);
    await this.mount(c);
    this.restack(); this.select(c.id); this.renderAll(); this.saveSoon();
  },

  /* ---------- список слоёв (внизу) ---------- */
  renderRows() {
    const box = $("thRows"); if (!box || !this.doc) return;
    box.innerHTML = "";
    if (!this.doc.layers.length) {
      box.innerHTML = `<p class="th-empty">Слоёв пока нет. Перетащи картинку на холст или нажми «+ Картинка», «+ Текст».</p>`;
      return;
    }
    const list = [...this.doc.layers].reverse();   // сверху — передний слой
    list.forEach((l) => {
      const row = document.createElement("div");
      row.className = "th-row" + (l.id === this.sel ? " sel" : "") + (l.visible ? "" : " hidden-layer");
      row.dataset.id = l.id;
      const grip = document.createElement("span"); grip.className = "fx-grip"; grip.textContent = "⠿"; grip.title = "Перетащить";
      const eye = document.createElement("input"); eye.type = "checkbox"; eye.checked = l.visible; eye.title = "Показывать";
      eye.onclick = (e) => e.stopPropagation();
      eye.onchange = () => { l.visible = eye.checked; this.applyLayerFx(l); this.renderRows(); this.saveSoon(); };
      const img = document.createElement("img"); img.className = "th-thumb"; img.alt = "";
      const r = this.rt.get(l.id);
      img.src = l.kind === "text" ? (r && r.src) || "" : l.url || "";
      const name = document.createElement("span"); name.className = "th-name";
      name.innerHTML = `${(l.name || "").replace(/</g, "&lt;")} <span class="th-kind">${l.kind === "text" ? "текст" : "картинка"}</span>`;
      const idx = this.doc.layers.indexOf(l);
      const btn = (t, title, dis, fn) => { const b = document.createElement("button"); b.className = "fx-btn"; b.textContent = t; b.title = title; b.disabled = dis;
        b.onclick = (e) => { e.stopPropagation(); fn(); }; return b; };
      const up = btn("↑", "Выше (вперёд)", idx === this.doc.layers.length - 1, () => this.moveLayer(idx, idx + 1));
      const down = btn("↓", "Ниже (назад)", idx === 0, () => this.moveLayer(idx, idx - 1));
      const del = btn("✕", "Удалить", false, () => this.removeLayer(l.id));
      row.append(grip, eye, img, name, up, down, del);
      row.onclick = () => this.select(l.id);
      grip.addEventListener("pointerdown", () => { row.draggable = true; });
      row.addEventListener("dragstart", (e) => { this._dragRow = l.id; row.classList.add("dragging"); e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", l.id); });
      row.addEventListener("dragend", () => { row.draggable = false; row.classList.remove("dragging"); this._dragRow = null; });
      row.addEventListener("dragover", (e) => { if (this._dragRow) e.preventDefault(); });
      row.addEventListener("drop", (e) => {
        e.preventDefault();
        const from = this.doc.layers.findIndex((x) => x.id === this._dragRow);
        if (from >= 0) this.moveLayer(from, this.doc.layers.indexOf(l));
      });
      box.append(row);
    });
  },
  moveLayer(from, to) {
    const L = this.doc.layers;
    if (to < 0 || to >= L.length || from === to) return;
    const [it] = L.splice(from, 1); L.splice(to, 0, it);
    this.restack(); this.renderRows(); this.saveSoon();
  },

  /* ---------- инспектор ---------- */
  buildInspector() {
    const sizeSel = $("thSize");
    TH_SIZES.forEach(([w, h, label]) => sizeSel.append(new Option(label, `${w}x${h}`)));
    sizeSel.onchange = () => {
      const [w, h] = sizeSel.value.split("x").map(Number);
      const sx = w / this.doc.w, sy = h / this.doc.h;
      for (const l of this.doc.layers) for (const key of ["pts", "base"]) l[key] = l[key].map(([x, y]) => [x * sx, y * sy]);
      Object.assign(this.doc, { w, h });
      $("stageCaption").textContent = `Обложка ${w}×${h}`;
      this.layout(); this.saveSoon();
    };
    $("thBgColor").addEventListener("input", (e) => { this.doc.bg = e.target.value; $("thBg").style.background = this.doc.bg; this.saveSoon(); });

    // текст
    const fontSel = $("thFont");
    TH_FONTS.forEach(([n]) => { const o = new Option(n, n); o.style.fontFamily = `"${n}"`; fontSel.append(o); });
    const text = () => { const l = this.selLayer(); return l && l.kind === "text" ? l.text : null; };
    const edit = (fn) => { const t = text(); if (!t) return; fn(t); this.updateText(); };
    $("thText").addEventListener("input", (e) => edit((t) => { t.value = e.target.value; }));
    fontSel.onchange = () => edit((t) => { t.font = fontSel.value; });
    $("thWeight").onchange = (e) => edit((t) => { t.weight = +e.target.value; });
    this.tSize = makeSlider($("thTSize"), (v) => edit((t) => { t.size = v; }));
    this.tSpacing = makeSlider($("thTSpacing"), (v) => edit((t) => { t.spacing = v; }));
    this.tLine = makeSlider($("thTLine"), (v) => edit((t) => { t.line = v; }));
    $("thColor").addEventListener("input", (e) => edit((t) => { t.color = e.target.value; }));
    $("thColor2").addEventListener("input", (e) => edit((t) => { t.color2 = e.target.value; }));
    $("thGrad").onchange = (e) => edit((t) => { t.gradient = e.target.checked; });
    $("thUpper").onchange = (e) => edit((t) => { t.upper = e.target.checked; });
    $("thItalic").onchange = (e) => edit((t) => { t.italic = e.target.checked; });
    $("thAlign").querySelectorAll("button").forEach((b) => {
      b.onclick = () => { edit((t) => { t.align = b.dataset.a; }); this.syncInspector(); };
    });
    // стили текста
    const box = $("thStyles");
    for (const st of TEXT_STYLES) {
      const b = document.createElement("button");
      b.textContent = st.name; b.title = "Стиль «" + st.name + "»: шрифт, цвет и эффекты";
      b.style.fontFamily = `"${st.text.font}"`;
      b.style.color = st.text.color;
      b.onclick = () => {
        const l = this.selLayer(); if (!l || l.kind !== "text") return;
        Object.assign(l.text, st.text);
        l.mods = styleStack(st);
        this.fxUI.sync(); this.syncInspector(); this.updateText();
      };
      box.append(b);
    }
    // слой
    this.opacity = makeSlider($("thOpacity"), (v) => { const l = this.selLayer(); if (!l) return; l.opacity = v; this.applyLayerFx(l); this.saveSoon(); });
    this.radius = makeSlider($("thRadius"), (v) => { const l = this.selLayer(); if (!l) return; l.r = v; this.applyLayerFx(l); this.saveSoon(); });
    const pbox = $("thPresets"), base = [[3, 3], [31, 3], [3, 19], [31, 19]];
    for (const p of PRESETS.filter((x) => !x.anim)) {
      const b = document.createElement("button");
      b.className = "preset"; b.title = p.name;
      const svg = document.createElementNS(SVGNS, "svg"); svg.setAttribute("viewBox", "0 0 34 22");
      const q = p.make(base, base)[0];
      const poly = document.createElementNS(SVGNS, "polygon"); poly.setAttribute("class", "to");
      poly.setAttribute("points", [q[0], q[1], q[3], q[2]].map((x) => x.join(",")).join(" "));
      svg.append(poly);
      const span = document.createElement("span"); span.textContent = p.name;
      b.append(svg, span);
      b.onclick = () => {
        const l = this.selLayer(); if (!l) return;
        l.pts = clonePts(p.make(l.pts, flatOfQuad(l.pts, l.base))[0]);
        this.renderAll(); this.saveSoon();
      };
      pbox.append(b);
    }
    $("thResetQuad").onclick = () => { const l = this.selLayer(); if (!l) return; l.pts = flatOfQuad(l.pts, l.base); this.renderAll(); this.saveSoon(); };
    $("thDup").onclick = () => this.duplicate();
    $("thDel").onclick = () => { if (this.sel) this.removeLayer(this.sel); };
    // мои пресеты: растяжение (форма углов в долях рамки слоя) и эффекты
    const needLayer = () => { if (this.selLayer()) return true; toast("Сначала выбери слой.", { kind: "error" }); return false; };
    new PresetBar($("thMyCorner"), "corner", {
      title: "Сохранить форму углов слоя",
      canSave: needLayer,
      collect: () => { const l = this.selLayer(); return { keys: [{ t: 0, pts: toUnit(l.pts, l.base), ease: "smooth", r: l.r }] }; },
      apply: (d, name) => {
        const l = this.selLayer(); if (!needLayer()) return;
        const k = (d.keys || [])[0]; if (!k) return;
        l.pts = fromUnit(k.pts, l.base); l.r = k.r || 0;
        this.applyLayerFx(l); this.renderAll(); this.syncInspector(); this.saveSoon();
        toast(`«${name}» применён к слою`);
      },
    });
    new PresetBar($("thMyMods"), "mods", {
      title: "Сохранить эффекты слоя",
      canSave: () => {
        const l = this.selLayer(); if (!needLayer()) return false;
        if (l.mods.stack.length > 1) return true;
        toast("У слоя пока нет эффектов.", { kind: "error" }); return false;
      },
      collect: () => ({ stack: stackForPreset(this.selLayer().mods.stack) }),
      apply: (d, name) => {
        const l = this.selLayer(); if (!needLayer()) return;
        l.mods = stackFromPreset(d.stack);
        this.fxUI.sync(); this.applyLayerFx(l); this.renderAll(); this.saveSoon();
        toast(`Эффекты «${name}» применены к слою`);
      },
    });
    // эффекты выбранного слоя
    this.fxUI = new FxStackUI($("thFxList"), $("thFxAdd"), {
      get: () => (this.selLayer() || { mods: { stack: [{ type: "warp", id: "warp" }] } }).mods.stack,
      set: (v) => { const l = this.selLayer(); if (l) l.mods.stack = v; },
      changed: () => { const l = this.selLayer(); if (l) { this.applyLayerFx(l); this.renderAll(); this.saveSoon(); } },
    });
  },

  syncInspector() {
    if (!this.doc) return;
    const l = this.selLayer();
    $("thCanvasBody").hidden = !!l;
    $("thLayerBody").hidden = !l;
    $("thSize").value = `${this.doc.w}x${this.doc.h}`;
    $("thBgColor").value = this.doc.bg;
    if (!l) return;
    $("thTextGroup").hidden = l.kind !== "text";
    if (l.kind === "text") {
      const t = l.text;
      if (document.activeElement !== $("thText")) $("thText").value = t.value;
      $("thFont").value = t.font; $("thWeight").value = String(t.weight);
      this.tSize.show(t.size); this.tSpacing.show(t.spacing); this.tLine.show(t.line);
      $("thColor").value = t.color; $("thColor2").value = t.color2;
      $("thColor2").hidden = !t.gradient;
      $("thGrad").checked = t.gradient; $("thUpper").checked = t.upper; $("thItalic").checked = t.italic;
      $("thAlign").querySelectorAll("button").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.a === t.align)));
    }
    this.opacity.show(l.opacity); this.radius.show(l.r);
    this.fxUI.sync();
  },

  /* ---------- сохранение картинки ---------- */
  async exportCover() {
    if (!this.doc.layers.some((l) => l.visible)) return toast("Добавь хотя бы один слой.", { kind: "error" });
    if (!(await CP.ensureFfmpeg())) return;
    const btn = $("thExport"), bar = $("thProgress"), fill = $("thProgressFill");
    btn.disabled = true; btn.textContent = "Рендер…"; bar.hidden = false; fill.style.width = "0";
    try {
      const texts = {};
      for (const l of this.doc.layers) if (l.kind === "text") texts[l.id] = this.rt.get(l.id)?.src || "";
      const r = await api("thumb_render", { doc: this.doc, texts });
      if (!r.ok) return toast(r.error || "Не получилось начать рендер.", { kind: "error" });
      let st;
      while (true) {
        await new Promise((res) => setTimeout(res, 300));
        st = await api("thumb_status", { job: r.job });
        fill.style.width = Math.round((st.progress || 0) * 100) + "%";
        if (!st.running) break;
      }
      if (!st.done) return toast("Обложка не сохранилась: " + (st.error || "неизвестная ошибка"), { kind: "error" });
      this.lastPng = st.png;
      toast("Обложка сохранена: PNG и JPG в папке проекта (wiggle_thumbs).", { action: { label: "Показать", run: () => api("open_path", { path: st.png }) } });
    } finally {
      btn.disabled = false; btn.textContent = "Сохранить обложку"; bar.hidden = true;
    }
  },

  /* ---------- запуск ---------- */
  init() {
    this.buildInspector();
    const f = $("thFrame");
    f.addEventListener("pointerdown", (e) => this.pointerDown(e));
    f.addEventListener("pointermove", (e) => this.pointerMove(e));
    f.addEventListener("pointerup", () => this.pointerUp());
    f.addEventListener("pointercancel", () => this.pointerUp());
    f.addEventListener("wheel", (e) => this.wheel(e), { passive: false });
    // картинки перетаскиванием на холст
    const stage = $("stage");
    stage.addEventListener("dragover", (e) => {
      if (!this.active || !e.dataTransfer.types.includes("Files")) return;
      e.preventDefault(); $("thDrop").hidden = false;
    });
    stage.addEventListener("dragleave", (e) => { if (!stage.contains(e.relatedTarget)) $("thDrop").hidden = true; });
    stage.addEventListener("drop", (e) => {
      if (!this.active) return;
      e.preventDefault(); $("thDrop").hidden = true;
      this.addFiles([...e.dataTransfer.files]);
    });
    document.addEventListener("paste", (e) => {
      if (!this.active || /^(INPUT|TEXTAREA)$/.test(document.activeElement?.tagName || "")) return;
      const files = [...(e.clipboardData?.files || [])].filter((x) => x.type.startsWith("image/"));
      if (files.length) { e.preventDefault(); this.addFiles(files); }
    });
    $("thAddImage").onclick = () => $("thFile").click();
    $("thFile").onchange = (e) => { this.addFiles([...e.target.files]); e.target.value = ""; };
    $("thAddText").onclick = () => this.addText();
    $("thAddFrame").onclick = () => this.pickFrame();
    $("thExport").onclick = () => this.exportCover();
    $("thOpen").onclick = () => api("open_path", { path: this.lastPng || this.dir }).then((r) => r.ok || toast("Папки пока нет — сохрани обложку.", { kind: "error" }));
    $("thClear").onclick = async () => {
      if (!this.doc.layers.length) return;
      const v = await openSheet({ title: "Удалить все слои обложки?", text: "Картинки останутся в папке проекта, но слои пропадут.",
        buttons: [{ label: "Удалить", value: "go", danger: true }, { label: "Отмена", value: "cancel" }], inline: true });
      if (v !== "go") return;
      for (const l of [...this.doc.layers]) this.removeLayer(l.id);
    };
    document.addEventListener("keydown", (e) => {
      if (!this.active || $("sheet").open || $("thFrameDlg").open) return;
      if (/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement?.tagName || "")) return;
      const l = this.selLayer();
      if ((e.key === "Delete" || e.key === "Backspace") && l) { e.preventDefault(); this.removeLayer(l.id); }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "d" && l) { e.preventDefault(); this.duplicate(); }
      if (e.key === "Escape") this.select(null);
      if (l && e.key.startsWith("Arrow")) {
        e.preventDefault();
        const s = e.shiftKey ? 10 : 1;
        const [dx, dy] = { ArrowLeft: [-s, 0], ArrowRight: [s, 0], ArrowUp: [0, -s], ArrowDown: [0, s] }[e.key];
        l.pts = Q.move(l.pts, dx, dy); this.renderAll(); this.saveSoon();
      }
    });
    new ResizeObserver(() => this.layout()).observe(stage);
  },
};
window.TH = TH;
