"use strict";
/* Общее для «Углов», «Модификаторов» и «Превью»: изинги, геометрия, стек эффектов и его превью на слое. */

const EASE = {
  linear: [0, 0, 1, 1], smooth: [0.42, 0, 0.58, 1], out: [0.16, 1, 0.3, 1],
  in: [0.7, 0, 0.84, 0], back: [0.34, 1.56, 0.64, 1],
};
const EASE_NAMES = { smooth: "Плавно", out: "Замедление", in: "Ускорение", back: "С отскоком", linear: "Линейно", hold: "Стоп до ключа" };

function easeVal(name, p) {
  p = Math.min(1, Math.max(0, p));
  if (name === "hold") return p < 1 ? 0 : 1;
  const [x1, y1, x2, y2] = EASE[name] || EASE.smooth;
  let lo = 0, hi = 1;
  for (let i = 0; i < 30; i++) { const m = (lo + hi) / 2; if (bez(0, x1, x2, 1, m) < p) lo = m; else hi = m; }
  return bez(0, y1, y2, 1, (lo + hi) / 2);
}

function cornersAt(keys, t) {
  if (!keys.length) return null;
  if (t <= keys[0].t) return keys[0].pts.map((p) => p.slice());
  const last = keys[keys.length - 1];
  if (t >= last.t) return last.pts.map((p) => p.slice());
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i], b = keys[i + 1];
    if (t >= a.t && t <= b.t) {
      const e = easeVal(a.ease || "smooth", (t - a.t) / Math.max(1, b.t - a.t));
      return a.pts.map((p, j) => [p[0] + (b.pts[j][0] - p[0]) * e, p[1] + (b.pts[j][1] - p[1]) * e]);
    }
  }
  return last.pts.map((p) => p.slice());
}

function radiusAt(keys, t) {
  if (!keys.length) return 0;
  const r = (k) => +k.r || 0;
  if (t <= keys[0].t) return r(keys[0]);
  const last = keys[keys.length - 1];
  if (t >= last.t) return r(last);
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i], b = keys[i + 1];
    if (t >= a.t && t <= b.t) return r(a) + (r(b) - r(a)) * easeVal(a.ease || "smooth", (t - a.t) / Math.max(1, b.t - a.t));
  }
  return r(last);
}
const samePts = (a, b) => !!a && !!b && a.every((p, i) => Math.abs(p[0] - b[i][0]) < 0.01 && Math.abs(p[1] - b[i][1]) < 0.01);
const clonePts = (q) => q.map((p) => p.slice());

/* ---------- модификаторы: те же значения по умолчанию, что в corner.py ---------- */
/* ---------- стек эффектов: те же значения по умолчанию, что в corner.py ---------- */
const FX_DEFAULTS = {
  color: { brightness: 0, contrast: 0, saturation: 0, temperature: 0, tint: 0, hue: 0 },
  shade: { angle: -135, strength: 60 },
  outline: { width: 8, soft: 0, opacity: 100, color: "#ffffff" },
  shadow: { x: 18, y: 24, blur: 30, opacity: 55, color: "#000000" },
  reflect: { opacity: 35, length: 45, gap: 4 },
  pixel: { size: 8 },
  blur: { radius: 8 },
};
/* что показывать в карточке эффекта; place — куда ставить новый: plane — над чертой, frame — в конец */
const FX = {
  color: { name: "Цвет", place: "plane", reset: true, params: [["brightness", "Яркость", -100, 100, ""], ["contrast", "Контраст", -100, 100, ""],
    ["saturation", "Насыщенность", -100, 100, ""], ["temperature", "Температура", -100, 100, ""], ["tint", "Оттенок", -100, 100, ""], ["hue", "Сдвиг цвета", -180, 180, "°"]] },
  outline: { name: "Обводка", place: "plane", color: true, params: [["width", "Толщина", 0, 40, "px"], ["soft", "Мягкость", 0, 120, "px"], ["opacity", "Плотность", 0, 300, "%"]] },
  shadow: { name: "Тень", place: "frame", color: true, params: [["x", "Сдвиг →", -150, 150, "px"], ["y", "Сдвиг ↓", -150, 150, "px"], ["blur", "Размытие", 0, 120, "px"], ["opacity", "Плотность", 0, 100, "%"]] },
  shade: { name: "Свет и тень", place: "plane", dial: true, params: [["strength", "Сила", 0, 100, "%"]] },
  reflect: { name: "Отражение", place: "plane", single: true, planeOnly: true, params: [["opacity", "Яркость", 0, 100, "%"], ["length", "Длина", 5, 100, "%"], ["gap", "Отступ", 0, 80, "px"]] },
  blur: { name: "Размытие", place: "frame", params: [["radius", "Сила", 0, 60, "px"]] },
  pixel: { name: "Пикселизация", place: "frame", params: [["size", "Пиксель", 2, 48, "px"]] },
};
const OLD_ORDER = [["color", "shade", "outline", "reflect"], ["shadow", "pixel"]];
const fxId = (t) => t + "_" + Math.random().toString(36).slice(2, 8);
function normMods(m) {
  m = m || {};
  let raw;
  if (Array.isArray(m.stack)) raw = m.stack;
  else {   // старые сохранения: включённые эффекты в прежнем порядке
    raw = OLD_ORDER[0].filter((t) => m[t] && m[t].on).map((t) => ({ ...m[t], type: t }));
    raw.push({ type: "warp" });
    raw.push(...OLD_ORDER[1].filter((t) => m[t] && m[t].on).map((t) => ({ ...m[t], type: t })));
  }
  const out = []; let warp = false;
  raw.forEach((e, i) => {
    const t = e && e.type;
    if (t === "warp") { if (!warp) { out.push({ type: "warp", id: "warp" }); warp = true; } return; }
    if (!FX_DEFAULTS[t]) return;
    const item = { ...FX_DEFAULTS[t] };
    for (const k of Object.keys(FX_DEFAULTS[t])) if (e[k] != null) item[k] = e[k];
    out.push({ ...item, type: t, id: String(e.id || fxId(t)), on: e.on !== false });
  });
  if (!warp) out.push({ type: "warp", id: "warp" });
  return { stack: out };
}
/* цветокоррекция одной матрицей 3x4 — та же, что color_matrix() в corner.py */
function colorMatrix(c) {
  const mul = (A, B) => A.map((row) => [0, 1, 2, 3].map((j) => row[0] * B[0][j] + row[1] * B[1][j] + row[2] * B[2][j] + (j === 3 ? row[3] : 0)));
  const t = c.temperature / 100, tn = c.tint / 100;
  let M = [[1 + 0.22 * t + 0.08 * tn, 0, 0, 0], [0, 1 + 0.04 * t - 0.16 * tn, 0, 0], [0, 0, 1 - 0.22 * t + 0.08 * tn, 0]];
  const s = Math.max(0, 1 + c.saturation / 100);
  M = mul([[0.213 + 0.787 * s, 0.715 - 0.715 * s, 0.072 - 0.072 * s, 0], [0.213 - 0.213 * s, 0.715 + 0.285 * s, 0.072 - 0.072 * s, 0],
    [0.213 - 0.213 * s, 0.715 - 0.715 * s, 0.072 + 0.928 * s, 0]], M);
  const a = (c.hue * Math.PI) / 180, ca = Math.cos(a), sa = Math.sin(a);
  M = mul([[0.213 + ca * 0.787 - sa * 0.213, 0.715 - ca * 0.715 - sa * 0.715, 0.072 - ca * 0.072 + sa * 0.928, 0],
    [0.213 - ca * 0.213 + sa * 0.143, 0.715 + ca * 0.285 + sa * 0.14, 0.072 - ca * 0.072 - sa * 0.283, 0],
    [0.213 - ca * 0.213 - sa * 0.787, 0.715 - ca * 0.715 + sa * 0.715, 0.072 + ca * 0.928 + sa * 0.072, 0]], M);
  const k = Math.max(0, 1 + c.contrast / 100);
  M = mul([[k, 0, 0, 0.5 - 0.5 * k], [0, k, 0, 0.5 - 0.5 * k], [0, 0, k, 0.5 - 0.5 * k]], M);
  const b = Math.max(0, 1 + c.brightness / 100);
  return mul([[b, 0, 0, 0], [0, b, 0, 0], [0, 0, b, 0]], M);
}
const colorIsIdentity = (c) => ["brightness", "contrast", "saturation", "temperature", "tint", "hue"].every((k) => Math.abs(c[k]) < 0.5);
const hexRgba = (hex, a) => {
  const n = parseInt(String(hex || "#000000").slice(1), 16) || 0;
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
};
/* аффинное преобразование рамки src в рамку dst (как affine() в corner.py) */
function affine2(src, dst) {
  const ux = src[1][0] - src[0][0], uy = src[1][1] - src[0][1], vx = src[2][0] - src[0][0], vy = src[2][1] - src[0][1];
  const Ux = dst[1][0] - dst[0][0], Uy = dst[1][1] - dst[0][1], Vx = dst[2][0] - dst[0][0], Vy = dst[2][1] - dst[0][1];
  const det = ux * vy - vx * uy;
  if (Math.abs(det) < 1e-9) return [1, 0, 0, 0, 1, 0];
  const ia = vy / det, ib = -vx / det, ic = -uy / det, id = ux / det;
  const a = Ux * ia + Vx * ic, b = Ux * ib + Vx * id, d = Uy * ia + Vy * ic, e = Uy * ib + Vy * id;
  return [a, b, dst[0][0] - a * src[0][0] - b * src[0][1], d, e, dst[0][1] - d * src[0][0] - e * src[0][1]];
}
const applyAff = ([a, b, c, d, e, f], q) => q.map(([x, y]) => [a * x + b * y + c, d * x + e * y + f]);

/* рысканье вокруг центра клипа — как в рендере */
function wiggleQuad(q, [dx, dy, rot, sc]) {
  const cx = (q[0][0] + q[1][0] + q[2][0] + q[3][0]) / 4, cy = (q[0][1] + q[1][1] + q[2][1] + q[3][1]) / 4;
  const a = (rot * Math.PI) / 180, ca = Math.cos(a), sa = Math.sin(a);
  return q.map(([x, y]) => [cx + sc * ((x - cx) * ca - (y - cy) * sa) + dx, cy + sc * ((x - cx) * sa + (y - cy) * ca) + dy]);
}
/* ползунок с полем ввода (разметка как у ползунков рысканья) */
function makeSlider(el, onEdit) {
  const min = +el.dataset.min, max = +el.dataset.max, step = +el.dataset.step || 1;
  const label = el.querySelector("label");
  const range = Object.assign(document.createElement("input"), { type: "range", min, max, step });
  range.id = "r_" + Math.random().toString(36).slice(2, 8); label.htmlFor = range.id;
  const val = document.createElement("div"); val.className = "val";
  val.innerHTML = `<input type="number" min="${min}" max="${max}" step="${step}" aria-label="${label.textContent}"><span class="unit">${el.dataset.unit || ""}</span>`;
  el.append(range, val);
  const num = val.querySelector("input");
  const show = (v) => { range.value = v; num.value = Math.round(v); range.style.setProperty("--fill", ((v - min) / (max - min)) * 100 + "%"); };
  const edit = (v) => { v = Math.min(max, Math.max(min, Math.round(+v / step) * step)); if (Number.isNaN(v)) return; show(v); onEdit(v); };
  range.addEventListener("input", () => edit(range.value));
  num.addEventListener("change", () => edit(num.value));
  return { show, range };
}

/* гомография прямоугольника w×h в четырёхугольник -> CSS matrix3d */
function solve8(src, dst) {
  const A = [];
  for (let i = 0; i < 4; i++) {
    const [x, y] = src[i], [u, v] = dst[i];
    A.push([x, y, 1, 0, 0, 0, -u * x, -u * y, u]);
    A.push([0, 0, 0, x, y, 1, -v * x, -v * y, v]);
  }
  for (let c = 0; c < 8; c++) {
    let p = c;
    for (let r = c + 1; r < 8; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
    [A[c], A[p]] = [A[p], A[c]];
    if (Math.abs(A[c][c]) < 1e-12) return null;
    for (let r = 0; r < 8; r++) {
      if (r === c) continue;
      const f = A[r][c] / A[c][c];
      for (let k = c; k < 9; k++) A[r][k] -= f * A[c][k];
    }
  }
  return A.map((row, i) => row[8] / row[i]);
}
function matrix3d(w, h, quad) {
  const H = solve8([[0, 0], [w, 0], [0, h], [w, h]], quad);
  if (!H) return "scale(0)";
  const [a, b, c, d, e, f, g, hh] = H;
  return `matrix3d(${a},${d},0,${g},${b},${e},0,${hh},0,0,1,0,${c},${f},0,1)`;
}

/* ---------- геометрия для пресетов (углы: ЛВ, ПВ, ЛН, ПН) ---------- */
const Q = {
  center: (q) => [(q[0][0] + q[1][0] + q[2][0] + q[3][0]) / 4, (q[0][1] + q[1][1] + q[2][1] + q[3][1]) / 4],
  map: (q, fn) => q.map((p) => fn(p[0], p[1])),
  scale(q, s) { const [cx, cy] = Q.center(q); return Q.map(q, (x, y) => [cx + (x - cx) * s, cy + (y - cy) * s]); },
  move(q, dx, dy) { return Q.map(q, (x, y) => [x + dx, y + dy]); },
  rotate(q, deg) {
    const [cx, cy] = Q.center(q), a = (deg * Math.PI) / 180, ca = Math.cos(a), sa = Math.sin(a);
    return Q.map(q, (x, y) => [cx + (x - cx) * ca - (y - cy) * sa, cy + (x - cx) * sa + (y - cy) * ca]);
  },
  // «дальний» край уменьшается — получается разворот в глубину
  tilt(q, side, k) {
    const r = q.map((p) => p.slice());
    const lerp = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
    const pairs = { right: [1, 3, 0, 2], left: [0, 2, 1, 3], top: [0, 1, 2, 3], bottom: [2, 3, 0, 1] }[side];
    const [i, j, oi, oj] = pairs;
    const a = q[i], b = q[j];
    r[i] = lerp(a, b, k / 2); r[j] = lerp(b, a, k / 2);              // край короче
    const inward = k * 0.45;
    r[i] = lerp(r[i], q[oi], inward); r[j] = lerp(r[j], q[oj], inward); // и дальше от зрителя
    return r;
  },
};

/* Пресет меняет ключ под курсором. cur — углы в этот момент, flat — та же рамка без наклонов.
   Анимированные ставят два ключа: в момент курсора и через span мкс. */
const PRESETS = [
  { id: "flat", name: "Плоско", make: (c, f) => [f] },
  { id: "right", name: "Вправо", make: (c, f) => [Q.tilt(f, "right", 0.24)] },
  { id: "left", name: "Влево", make: (c, f) => [Q.tilt(f, "left", 0.24)] },
  { id: "floor", name: "Пол", make: (c, f) => [Q.tilt(f, "top", 0.34)] },
  { id: "ceil", name: "Потолок", make: (c, f) => [Q.tilt(f, "bottom", 0.34)] },
  { id: "monitor", name: "Монитор", make: (c, f) => [Q.rotate(Q.tilt(f, "right", 0.18), -3)] },
  { id: "flyin", name: "Влёт", anim: true, span: 700000, ease: "back",
    make: (c) => [Q.rotate(Q.scale(Q.tilt(c, "right", 0.5), 0.15), 12), c] },
  { id: "swing", name: "Поворот", anim: true, span: 2000000, ease: "smooth",
    make: (c, f) => [Q.tilt(f, "left", 0.26), Q.tilt(f, "right", 0.26)] },
  { id: "dolly", name: "Наезд", anim: true, span: 1500000, ease: "smooth",
    make: (c) => [c, Q.scale(c, 1.15)] },
  { id: "flyout", name: "Улёт", anim: true, span: 600000, ease: "in",
    make: (c) => [c, Q.rotate(Q.scale(Q.tilt(c, "left", 0.5), 0.12), -10)] },
];


/* ========================================================== слой с эффектами ===
   Один слой превью: box (кадр, эффекты «в кадре») > unit (перспектива, эффекты после отражения)
   > [refl (отражение), skin (скругление, эффекты до отражения) > media + свет]. */
const SVGNS = "http://www.w3.org/2000/svg";
function makeLayerDom(url, type, aw, ah) {
  const el = document.createElement(type === "video" ? "video" : "img");
  el.src = url; el.width = aw; el.height = ah; el.draggable = false;
  if (type === "video") { el.muted = true; el.playsInline = true; el.preload = "auto"; }
  const box = document.createElement("div"); box.className = "cp-box";
  const unit = document.createElement("div"); unit.className = "cp-unit";
  const skin = document.createElement("div"); skin.className = "cp-skin";
  const dark = document.createElement("div"), light = document.createElement("div");
  dark.className = light.className = "cp-light";
  const refl = document.createElement("div"); refl.className = "cp-refl"; refl.hidden = true;
  const rskin = document.createElement("div"); rskin.className = "cp-refl-skin";
  const rcv = document.createElement("canvas");
  rskin.append(rcv); refl.append(rskin);
  skin.append(el, dark, light); unit.append(refl, skin);
  // фильтры лежат в общем скрытом SVG: ссылаться на фильтр внутри самого слоя Chrome не умеет
  let root = document.getElementById("fxDefsRoot");
  if (!root) {
    root = document.createElementNS(SVGNS, "svg"); root.id = "fxDefsRoot";
    root.setAttribute("width", "0"); root.setAttribute("height", "0");
    root.style.position = "absolute"; root.setAttribute("aria-hidden", "true");
    document.body.append(root);
  }
  const defs = document.createElementNS(SVGNS, "defs"); root.append(defs);
  box.append(unit);
  const L = { box, unit, skin, refl, reflSkin: rskin, reflCv: rcv, darkEl: dark, lightEl: light, media: el, defs, type,
    aw: 0, ah: 0, s0: 1, shadeFx: null, _reflDirty: true, _modsK: null };
  setLayerSource(L, url, type, aw, ah);
  if (type !== "video") el.addEventListener("load", () => (L._reflDirty = true));
  return L;
}
function disposeLayer(L) {
  if (!L) return;
  L.defs.remove(); L.box.remove();
}
function setLayerSource(L, url, type, aw, ah) {
  if (L.media.getAttribute("src") !== url) L.media.src = url;
  L.aw = aw; L.ah = ah;
  L.media.width = aw; L.media.height = ah;
  L.unit.style.width = aw + "px"; L.unit.style.height = ah + "px";
  if (type !== "video") for (const d of [L.darkEl, L.lightEl]) d.style.webkitMaskImage = d.style.maskImage = `url("${url}")`;
  L._reflDirty = true;
}

/* CSS-фильтр одного эффекта; mul — сколько пикселей элемента в пикселе кадра проекта */
const PIX_MAPS = {};
function fxCss(e, mul, defs) {
  const id = "fx_" + e.id;
  if (e.type === "color") {
    if (colorIsIdentity(e)) return "";
    const v = colorMatrix(e).map((r) => `${r[0]} ${r[1]} ${r[2]} 0 ${r[3]}`).join("  ") + "  0 0 0 1 0";
    defs.push(`<filter id="${id}" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values="${v}"/></filter>`);
    return `url(#${id})`;
  }
  if (e.type === "blur") return e.radius > 0 ? `blur(${(e.radius * mul).toFixed(2)}px)` : "";
  if (e.type === "shadow") return e.opacity > 0
    ? `drop-shadow(${(e.x * mul).toFixed(2)}px ${(e.y * mul).toFixed(2)}px ${(e.blur * mul).toFixed(2)}px ${hexRgba(e.color, e.opacity / 100)})` : "";
  if (e.type === "outline") {
    const w = Math.max(0, Math.round(e.width * mul)), sf = e.soft * mul;
    if (e.opacity <= 0 || (w === 0 && sf < 0.5)) return "";
    defs.push(`<filter id="${id}" x="-60%" y="-60%" width="220%" height="220%" color-interpolation-filters="sRGB">` +
      `<feGaussianBlur in="SourceAlpha" stdDeviation="${w ? Math.max(0.5, w / 2) : 0}" result="b"/>` +
      `<feComponentTransfer in="b" result="d"><feFuncA type="linear" slope="42" intercept="-0.494"/></feComponentTransfer>` +
      `<feGaussianBlur in="d" stdDeviation="${sf >= 0.5 ? sf / 2 : 0}" result="g0"/>` +
      `<feComponentTransfer in="g0" result="g"><feFuncA type="linear" slope="${e.opacity / 100}" intercept="-0.008"/></feComponentTransfer>` +
      `<feFlood flood-color="${e.color}"/><feComposite in2="g" operator="in" result="o"/>` +
      `<feMerge><feMergeNode in="o"/><feMergeNode in="SourceGraphic"/></feMerge></filter>`);
    return `url(#${id})`;
  }
  if (e.type === "pixel") {
    if (e.size < 2) return "";
    const c = Math.max(2, Math.round(e.size * mul));
    // карта смещений одной клетки: каждый пиксель берёт цвет из центра своей клетки
    if (!PIX_MAPS[c]) {
      const cv = document.createElement("canvas"); cv.width = cv.height = c;
      const g = cv.getContext("2d"), img = g.createImageData(c, c), h = Math.floor(c / 2), sc = 2 * c;
      for (let y = 0; y < c; y++) for (let x = 0; x < c; x++) {
        const o = (y * c + x) * 4;
        img.data[o] = Math.round((0.5 + (h - x) / sc) * 255); img.data[o + 1] = Math.round((0.5 + (h - y) / sc) * 255);
        img.data[o + 2] = 0; img.data[o + 3] = 255;
      }
      g.putImageData(img, 0, 0);
      PIX_MAPS[c] = cv.toDataURL();
    }
    defs.push(`<filter id="${id}" x="-60%" y="-60%" width="220%" height="220%" color-interpolation-filters="sRGB">` +
      `<feImage href="${PIX_MAPS[c]}" x="0" y="0" width="${c}" height="${c}" preserveAspectRatio="none"/><feTile result="map"/>` +
      `<feDisplacementMap in="SourceGraphic" in2="map" scale="${2 * c}" xChannelSelector="R" yChannelSelector="G"/></filter>`);
    return `url(#${id})`;
  }
  return "";
}

/* стек эффектов на слое L; k — масштаб показа кадра, L.s0 — пикселей кадра в пикселе ассета */
function applyFx(L, stack, k) {
  const s0 = L.s0, pm = 1 / s0, aw = L.aw, ah = L.ah;
  L._modsK = k;
  const wi = stack.findIndex((e) => e.type === "warp");
  const plane = stack.slice(0, wi).filter((e) => e.on), frame = stack.slice(wi + 1).filter((e) => e.on && e.type !== "reflect");
  const ri = plane.findIndex((e) => e.type === "reflect");
  const before = ri >= 0 ? plane.slice(0, ri) : plane, after = ri >= 0 ? plane.slice(ri + 1) : [];
  const defs = [];
  const css = (list, mul) => list.filter((e) => e.type !== "shade").map((e) => fxCss(e, mul, defs)).filter(Boolean).join(" ");
  L.skin.style.filter = L.reflSkin.style.filter = css(before, pm);
  L.unit.style.filter = css(after, pm);
  L.box.style.filter = css(frame, k);
  L.defs.innerHTML = defs.join("");
  // свет — градиентом поверх клипа (в рендере он точный)
  L.shadeFx = [...plane, ...frame].find((e) => e.type === "shade" && e.strength > 0) || null;
  L.darkEl.hidden = L.lightEl.hidden = !L.shadeFx;
  // отражение: где кончается картинка к этому моменту (как L,T,R,B в рендере)
  const rf = ri >= 0 ? plane[ri] : null;
  if (rf && rf.opacity > 0 && rf.length > 0) {
    let X0 = 0, Y0 = 0, X1 = aw, Y1 = ah;
    for (const e of before) {
      let l = 0, t = 0, r = 0, b = 0;
      if (e.type === "blur" && e.radius > 0) l = t = r = b = Math.ceil((e.radius / s0) * 3);
      if (e.type === "outline" && e.opacity > 0) {
        const w = Math.max(0, Math.round(e.width / s0)), sf = e.soft / s0;
        if (w || sf >= 0.5) l = t = r = b = w + (sf >= 0.5 ? Math.ceil(sf * 1.8) : 0);
      }
      if (e.type === "shadow" && e.opacity > 0) {
        const dx = e.x / s0, dy = e.y / s0, ext = Math.ceil((e.blur / 2 / s0) * 3);
        l = ext + Math.ceil(Math.max(0, -dx)); r = ext + Math.ceil(Math.max(0, dx));
        t = ext + Math.ceil(Math.max(0, -dy)); b = ext + Math.ceil(Math.max(0, dy));
      }
      X0 -= l; Y0 -= t; X1 += r; Y1 += b;
    }
    const h = Y1 - Y0, LH = Math.max(2, Math.min(h, Math.round((rf.length / 100) * h))), gap = Math.max(0, Math.round(rf.gap / s0));
    Object.assign(L.refl.style, { left: X0 + "px", top: Y1 + gap + "px", width: X1 - X0 + "px", height: LH + "px" });
    Object.assign(L.reflSkin.style, { left: -X0 + "px", top: Y1 - ah + "px", width: aw + "px", height: ah + "px" });
    const stops = [];
    for (let n = 0; n <= 8; n++) stops.push(`rgba(0,0,0,${((rf.opacity / 100) * Math.pow(1 - n / 8, 1.6)).toFixed(3)}) ${((LH * n) / 8).toFixed(1)}px`);
    L.refl.style.webkitMaskImage = L.refl.style.maskImage = `linear-gradient(to bottom, ${stops.join(", ")})`;
    const scale = Math.min(1, 640 / Math.max(aw, ah));   // отражению хватит и уменьшенного кадра
    L.reflCv.width = Math.max(1, Math.round(aw * scale)); L.reflCv.height = Math.max(1, Math.round(ah * scale));
    L.refl.hidden = false; L._reflDirty = true; L._reflT = -1;
  } else L.refl.hidden = true;
}

function drawLayerRefl(L) {
  if (L.refl.hidden) return;
  const m = L.media;
  if (L.type === "video") {
    if (m.readyState < 2 || (m.currentTime === L._reflT && !L._reflDirty)) return;
    L._reflT = m.currentTime;
  } else if (!L._reflDirty || !m.complete) return;
  L._reflDirty = false;
  const cv = L.reflCv, c = cv.getContext("2d");
  c.clearRect(0, 0, cv.width, cv.height);
  c.drawImage(m, 0, 0, cv.width, cv.height);
}

/* свет: градиент по растянутому слою от стороны, откуда светит. В рендере он точный (по гомографии),
   здесь — линейный по плоскости, этого хватает, чтобы видеть результат. disp — углы на экране. */
function renderLayerShade(L, disp) {
  const sh = L.shadeFx; if (!sh) return;
  const aw = L.aw, ah = L.ah;
  const ang = (sh.angle * Math.PI) / 180, lx = Math.cos(ang), ly = Math.sin(ang), s = sh.strength / 100;
  const cx = (disp[0][0] + disp[1][0] + disp[2][0] + disp[3][0]) / 4, cy = (disp[0][1] + disp[1][1] + disp[2][1] + disp[3][1]) / 4;
  const dots = disp.map(([x, y]) => (x - cx) * lx + (y - cy) * ly);
  const R = Math.max(...dots.map(Math.abs)) || 1;
  const g = dots.map((d) => d / R);
  const a = (g[1] - g[0] + g[3] - g[2]) / (2 * aw), b = (g[2] - g[0] + g[3] - g[1]) / (2 * ah);
  const c0 = (g[0] + g[1] + g[2] + g[3]) / 4 - (a * aw) / 2 - (b * ah) / 2;
  const len = Math.hypot(a, b);
  if (len < 1e-9) { L.darkEl.style.background = L.lightEl.style.background = "none"; return; }
  const dx = a / len, dy = b / len;
  const deg = (Math.atan2(dx, -dy) * 180) / Math.PI;
  const Lg = Math.abs(aw * dx) + Math.abs(ah * dy);
  const gAt = (t) => { const x = aw / 2 + dx * Lg * (t - 0.5), y = ah / 2 + dy * Lg * (t - 0.5); return Math.max(-1, Math.min(1, c0 + a * x + b * y)); };
  const g0 = gAt(0), g1 = gAt(1);
  const stopsFor = (fn) => {
    const pts = [0, 1];
    if ((g0 < 0) !== (g1 < 0)) pts.splice(1, 0, g0 / (g0 - g1));
    return pts.map((t) => `${fn(gAt(t))} ${(t * 100).toFixed(2)}%`).join(", ");
  };
  L.darkEl.style.background = `linear-gradient(${deg.toFixed(2)}deg, ${stopsFor((v) => `rgba(0,0,0,${Math.min(1, s * 0.85 * Math.max(0, -v)).toFixed(3)})`)})`;
  L.lightEl.style.background = `linear-gradient(${deg.toFixed(2)}deg, ${stopsFor((v) => `rgba(255,255,255,${Math.min(1, s * 0.45 * Math.max(0, v)).toFixed(3)})`)})`;
}

/* та же рамка, что base, но с центром и размером cur и без наклонов — для пресетов */
function flatOfQuad(cur, base) {
  const q = base, len = (a, b) => Math.hypot(b[0] - a[0], b[1] - a[1]);
  const s = Math.max(Math.max(len(cur[0], cur[1]), len(cur[2], cur[3])) / Math.max(1, len(q[0], q[1])),
    Math.max(len(cur[0], cur[2]), len(cur[1], cur[3])) / Math.max(1, len(q[0], q[2])));
  const [cx, cy] = Q.center(cur), [qx, qy] = Q.center(q);
  return Q.move(Q.scale(q, s), cx - qx, cy - qy);
}

/* ========================================================== стек эффектов: UI ===
   host: { get() -> stack, set(stack), changed() } */
class FxStackUI {
  constructor(listEl, addEl, host) {
    this.listEl = listEl; this.addEl = addEl; this.host = host; this.fxOpen = new Set();
    this.build();
  }

  build() {
    const box = this.addEl;
    for (const [t, d] of Object.entries(FX)) {
      const b = document.createElement("button");
      b.textContent = "+ " + d.name; b.dataset.t = t;
      b.onclick = () => this.add(t);
      box.append(b);
    }
    const list = this.listEl;
    list.addEventListener("dragover", (e) => this.dragOver(e));
    list.addEventListener("drop", (e) => { e.preventDefault(); this.drop(); });
  }

  add(t) {
    const st = this.host.get(), wi = st.findIndex((e) => e.type === "warp");
    if (FX[t].single && st.some((e) => e.type === t)) return;
    const item = { ...FX_DEFAULTS[t], type: t, id: fxId(t), on: true };
    if (FX[t].place === "plane") st.splice(wi, 0, item); else st.push(item);
    this.fxOpen.add(item.id);
    this.sync(); this.host.changed();
    requestAnimationFrame(() => this.listEl.querySelector(`.fx[data-id="${item.id}"]`)?.scrollIntoView({ block: "nearest", behavior: "smooth" }));
  }

  /* переставить элемент from на позицию to (индекс в итоговом списке) */
  move(from, to) {
    const st = this.host.get();
    if (to < 0 || to >= st.length || from === to) return;
    const next = st.slice(); const [it] = next.splice(from, 1); next.splice(to, 0, it);
    const wi = next.findIndex((e) => e.type === "warp");
    if (next.some((e, n) => FX[e.type] && FX[e.type].planeOnly && n > wi)) {
      toast("Отражение работает только на плоскости клипа — над чертой «Растяжение по углам».", { kind: "error" });
      return;
    }
    this.host.set(next);
    this.sync(); this.host.changed();
  }

  dragOver(e) {
    if (this._dragFx == null) return;
    e.preventDefault();
    const items = [...this.listEl.querySelectorAll(".fx, .fx-warp")];
    let at = items.length;
    for (let n = 0; n < items.length; n++) {
      const r = items[n].getBoundingClientRect();
      if (e.clientY < r.top + r.height / 2) { at = n; break; }
    }
    this._dropAt = at;
    let line = this.listEl.querySelector(".fx-drop");
    if (!line) { line = document.createElement("div"); line.className = "fx-drop"; }
    if (at < items.length) items[at].before(line); else this.listEl.append(line);
  }
  drop() {
    const from = this._dragFx, at = this._dropAt;
    this.listEl.querySelector(".fx-drop")?.remove();
    this._dragFx = null;
    if (from == null || at == null) return;
    this.move(from, at > from ? at - 1 : at);
  }

  sync() {
    const list = this.listEl; if (!list) return;
    const st = this.host.get(), wi = st.findIndex((e) => e.type === "warp");
    list.innerHTML = "";
    const counts = {};
    st.forEach((e) => { counts[e.type] = (counts[e.type] || 0) + 1; });
    const seen = {};
    st.forEach((e, idx) => {
      const grip = document.createElement("span"); grip.className = "fx-grip"; grip.textContent = "⠿"; grip.title = "Перетащить";
      const btn = (txt, title, dis, fn) => {
        const b = document.createElement("button"); b.className = "fx-btn"; b.textContent = txt; b.title = title; b.disabled = dis;
        b.onclick = fn; return b;
      };
      const up = btn("↑", "Выше", idx === 0, () => this.move(idx, idx - 1));
      const down = btn("↓", "Ниже", idx === st.length - 1, () => this.move(idx, idx + 1));
      let el;
      if (e.type === "warp") {
        el = document.createElement("div"); el.className = "fx-warp";
        const lab = document.createElement("span"); lab.textContent = "Растяжение по углам";
        el.append(grip, lab, up, down);
      } else {
        const d = FX[e.type];
        seen[e.type] = (seen[e.type] || 0) + 1;
        el = document.createElement("section");
        el.className = "fx" + (e.on ? "" : " off") + (this.fxOpen.has(e.id) ? "" : " closed");
        const head = document.createElement("div"); head.className = "fx-head";
        const on = document.createElement("input"); on.type = "checkbox"; on.checked = e.on; on.title = "Включить";
        on.onchange = () => { e.on = on.checked; el.classList.toggle("off", !e.on); this.host.changed(); };
        const title = document.createElement("button"); title.className = "fx-title";
        title.innerHTML = `${d.name}${counts[e.type] > 1 ? " " + seen[e.type] : ""}<span class="fx-where">${idx < wi ? "плоскость" : "кадр"}</span>`;
        title.onclick = () => { const open = el.classList.toggle("closed"); open ? this.fxOpen.delete(e.id) : this.fxOpen.add(e.id); };
        const del = btn("✕", "Удалить", false, () => {
          this.host.set(this.host.get().filter((x) => x !== e));
          this.sync(); this.host.changed();
        });
        head.append(grip, on, title, up, down, del);
        const body = document.createElement("div"); body.className = "fx-body";
        if (d.dial) body.append(this.makeDial(e));
        for (const [key, label, min, max, unit] of d.params) {
          const row = document.createElement("div"); row.className = "slider";
          Object.assign(row.dataset, { min, max, step: 1, unit });
          row.innerHTML = `<label>${label}</label>`;
          body.append(row);
          const sl = makeSlider(row, (v) => { e[key] = v; this.host.changed(); });
          sl.show(e[key]);
        }
        if (d.color) {
          const row = document.createElement("div"); row.className = "row";
          row.innerHTML = `<label>Цвет</label><input type="color" class="swatch">`;
          const c = row.querySelector("input"); c.value = e.color;
          c.addEventListener("input", () => { e.color = c.value; this.host.changed(); });
          body.append(row);
        }
        if (d.reset) {
          const r = document.createElement("div"); r.className = "btn-row";
          const b = document.createElement("button"); b.className = "small-btn"; b.textContent = "Сбросить";
          b.onclick = () => { Object.assign(e, FX_DEFAULTS[e.type]); this.sync(); this.host.changed(); };
          r.append(b); body.append(r);
        }
        el.append(head, body);
      }
      el.dataset.id = e.id;
      // тянуть можно только за ⠿, чтобы ползунки внутри не начинали перетаскивание
      grip.addEventListener("pointerdown", () => { el.draggable = true; });
      el.addEventListener("dragstart", (ev) => { this._dragFx = idx; el.classList.add("dragging"); ev.dataTransfer.effectAllowed = "move"; ev.dataTransfer.setData("text/plain", e.id); });
      el.addEventListener("dragend", () => { el.draggable = false; el.classList.remove("dragging"); this.listEl.querySelector(".fx-drop")?.remove(); this._dragFx = null; });
      list.append(el);
    });
    if (st.length === 1) {
      const p = document.createElement("p"); p.className = "fx-empty"; p.textContent = "Эффектов пока нет — добавь сверху.";
      list.prepend(p);
    }
    this.addEl.querySelectorAll("button").forEach((b) => { b.disabled = !!FX[b.dataset.t].single && st.some((e) => e.type === b.dataset.t); });
  }

  /* направление света: тянешь солнце по кругу */
  makeDial(e) {
    const row = document.createElement("div"); row.className = "row light-row";
    row.innerHTML = `<label>Откуда свет</label><div class="dial" role="slider" tabindex="0" aria-label="Направление света">
      <svg viewBox="0 0 64 64"><circle class="ring" cx="32" cy="32" r="24"/><line class="ray" x1="32" y1="32" x2="32" y2="8"/><circle class="sun" cx="32" cy="8" r="6"/></svg></div>
      <span class="dial-val"></span>`;
    const dial = row.querySelector(".dial"), val = row.querySelector(".dial-val");
    const names = [[-180, "слева"], [-135, "слева сверху"], [-90, "сверху"], [-45, "справа сверху"], [0, "справа"], [45, "справа снизу"], [90, "снизу"], [135, "слева снизу"], [180, "слева"]];
    const show = () => {
      const a = (e.angle * Math.PI) / 180, x = 32 + 24 * Math.cos(a), y = 32 + 24 * Math.sin(a);
      dial.querySelector(".sun").setAttribute("cx", x); dial.querySelector(".sun").setAttribute("cy", y);
      dial.querySelector(".ray").setAttribute("x2", x); dial.querySelector(".ray").setAttribute("y2", y);
      dial.setAttribute("aria-valuenow", e.angle);
      val.textContent = names.reduce((b, n) => (Math.abs(n[0] - e.angle) < Math.abs(b[0] - e.angle) ? n : b))[1];
      val.title = e.angle + "°";
    };
    const set = (deg) => { deg = Math.round(deg); if (deg > 180) deg -= 360; if (deg <= -180) deg += 360; e.angle = deg; show(); this.host.changed(); };
    const from = (ev) => { const r = dial.getBoundingClientRect(); set((Math.atan2(ev.clientY - (r.top + r.height / 2), ev.clientX - (r.left + r.width / 2)) * 180) / Math.PI); };
    let drag = false;
    dial.addEventListener("pointerdown", (ev) => { drag = true; dial.setPointerCapture(ev.pointerId); from(ev); });
    dial.addEventListener("pointermove", (ev) => drag && from(ev));
    dial.addEventListener("pointerup", () => (drag = false));
    dial.addEventListener("keydown", (ev) => {
      if (ev.key === "ArrowLeft" || ev.key === "ArrowDown") { ev.preventDefault(); set(e.angle - 5); }
      if (ev.key === "ArrowRight" || ev.key === "ArrowUp") { ev.preventDefault(); set(e.angle + 5); }
    });
    show();
    return row;
  }
}

/* ========================================================== мои пресеты ===
   Общие для всех проектов: рысканье, растяжение по углам, стек модификаторов.
   PresetBar рисует ряд кнопок: щелчок — применить, ✕ — удалить, «+ Сохранить» — запомнить текущее. */
const MY = {
  store: { wiggle: [], corner: [], mods: [] },
  bars: [],
  async load() {
    const r = await api("presets_list");
    if (r.ok) this.store = r.presets;
    this.bars.forEach((b) => b.render());
  },
  set(presets) { this.store = presets; this.bars.forEach((b) => b.render()); },
};
const UNIT_Q = [[0, 0], [1, 0], [0, 1], [1, 1]];
/* углы ключей -> в долях рамки клипа (и обратно), чтобы пресет ложился на любой клип или слой */
const toUnit = (pts, base) => applyAff(affine2(base, UNIT_Q), pts);
const fromUnit = (pts, base) => applyAff(affine2(UNIT_Q, base), pts);

class PresetBar {
  /* opts: { title, collect() -> data | null, apply(data, name), canSave() } */
  constructor(el, kind, opts) {
    this.el = el; this.kind = kind; this.opts = opts;
    MY.bars.push(this);
    this.render();
  }
  render() {
    const el = this.el; if (!el) return;
    el.innerHTML = "";
    el.className = "my-presets";
    for (const p of MY.store[this.kind] || []) {
      const b = document.createElement("button");
      b.className = "my-chip"; b.title = "Применить «" + p.name + "»";
      const n = document.createElement("span"); n.textContent = p.name;
      const x = document.createElement("span"); x.className = "my-x"; x.textContent = "✕"; x.title = "Удалить пресет";
      x.onclick = async (e) => {
        e.stopPropagation();
        const v = await openSheet({ title: `Удалить пресет «${p.name}»?`, buttons: [{ label: "Удалить", value: "go", danger: true }, { label: "Отмена", value: "cancel" }], inline: true });
        if (v !== "go") return;
        const r = await api("preset_delete", { id: p.id });
        if (r.ok) MY.set(r.presets);
      };
      b.append(n, x);
      b.onclick = () => this.opts.apply(JSON.parse(JSON.stringify(p.data)), p.name);
      el.append(b);
    }
    const save = document.createElement("button");
    save.className = "my-chip my-save"; save.textContent = "+ Сохранить";
    save.title = this.opts.title || "Сохранить текущие настройки как пресет";
    save.onclick = () => this.save();
    el.append(save);
  }
  async save() {
    if (this.opts.canSave && !this.opts.canSave()) return;
    const data = this.opts.collect();
    if (!data) return;
    const n = (MY.store[this.kind] || []).length + 1;
    const v = await openSheet({ title: "Название пресета", field: { value: `Мой пресет ${n}` },
      buttons: [{ label: "Сохранить", value: "go", primary: true }, { label: "Отмена", value: "cancel" }], inline: true });
    const name = $("sheetInput").value.trim();
    if (v !== "go" || !name) return;
    const r = await api("preset_save", { kind: this.kind, name, data });
    if (!r.ok) return toast(r.error || "Не получилось сохранить.", { kind: "error" });
    MY.set(r.presets);
    toast(`Пресет «${name}» сохранён`);
  }
}
/* стек эффектов из пресета: новые id, чтобы два слоя с одним пресетом не делили фильтры */
const stackFromPreset = (stack) => normMods({ stack: stack.map((e) => (e.type === "warp" ? e : { ...e, id: fxId(e.type) })) });
const stackForPreset = (stack) => stack.map(({ id, ...e }) => (e.type === "warp" ? { type: "warp" } : e));

/* ========================================================== ручка поворота ===
   Кружок над серединой верхнего края: тянешь — весь объект крутится вокруг центра, Shift — шаг 15°. */
function rotHandleAt(d) {
  const [cx, cy] = Q.center(d);
  const mx = (d[0][0] + d[1][0]) / 2, my = (d[0][1] + d[1][1]) / 2;
  let vx = mx - cx, vy = my - cy;
  const len = Math.hypot(vx, vy);
  if (len < 1e-6) { vx = 0; vy = -1; } else { vx /= len; vy /= len; }
  return { cx, cy, mx, my, hx: mx + vx * 32, hy: my + vy * 32 };
}
function makeRotHandle(svg) {
  const mk = (tag, cls) => { const e = document.createElementNS(SVGNS, tag); e.setAttribute("class", cls); svg.append(e); return e; };
  const line = mk("line", "rot-line");
  const h = mk("circle", "h rot"); h.setAttribute("r", 9); h.dataset.part = "rot";
  const title = document.createElementNS(SVGNS, "title"); title.textContent = "Повернуть (Shift — шагами по 15°)"; h.append(title);
  const icon = mk("path", "rot-icon");
  icon.setAttribute("d", "M3.6,-1.6 A4,4 0 1,0 3.2,2.4 M3.9,-4.4 L3.6,-1.4 L0.7,-1.9");
  const val = mk("text", "rot-val"); val.setAttribute("text-anchor", "middle");
  return { line, h, icon, val };
}
function placeRotHandle(R, d, angle) {
  const g = rotHandleAt(d);
  R.line.setAttribute("x1", g.mx); R.line.setAttribute("y1", g.my); R.line.setAttribute("x2", g.hx); R.line.setAttribute("y2", g.hy);
  R.h.setAttribute("cx", g.hx); R.h.setAttribute("cy", g.hy);
  R.icon.setAttribute("transform", `translate(${g.hx},${g.hy})`);
  R.val.setAttribute("x", g.hx); R.val.setAttribute("y", g.hy - 16);
  R.val.textContent = angle == null ? "" : `${angle > 0 ? "+" : ""}${Math.round(angle)}°`;
  return g;
}
/* угол поворота мыши вокруг (cx, cy) с начала перетаскивания, градусы по часовой */
function rotDelta(cx, cy, x0, y0, x, y, snap) {
  let a = ((Math.atan2(y - cy, x - cx) - Math.atan2(y0 - cy, x0 - cx)) * 180) / Math.PI;
  while (a > 180) a -= 360;
  while (a <= -180) a += 360;
  return snap ? Math.round(a / 15) * 15 : a;
}
