"""
Проект CapCut для приложения: чтение элементов, рысканье, сохранение, отмена,
и проверка, открыт ли проект сейчас в CapCut.
"""

import copy
import os
import sys
import time
from pathlib import Path

import capcut_wiggle as cw

TYPE_NAMES = {"text": "Текст", "video": "Видео", "sticker": "Стикер"}
IS_WINDOWS = sys.platform.startswith("win")


# ------------------------------------------------------- окна CapCut ----
def capcut_windows():
    """Видимые окна CapCut: список (заголовок, путь к exe). Только Windows."""
    if not IS_WINDOWS:
        return []
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD,
                                                    wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    found = []
    names = {}

    def exe_of(pid):
        if pid in names:
            return names[pid]
        path = ""
        h = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if h:
            buf = ctypes.create_unicode_buffer(1024)
            size = wintypes.DWORD(1024)
            if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                path = buf.value
            kernel32.CloseHandle(h)
        names[pid] = path
        return path

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def enum(hwnd, _):
        if not user32.IsWindowVisible(hwnd):
            return True
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return True
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        path = exe_of(pid.value)
        if os.path.basename(path).lower() == "capcut.exe":
            title = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, title, length + 1)
            found.append((title.value, path))
        return True

    try:
        user32.EnumWindows(enum, 0)
    except OSError:
        return []
    return found


_last_capcut_exe = None


def capcut_exe():
    """Чем запускать CapCut: лаунчер из AppData или exe, который мы видели запущенным."""
    cands = []
    local = os.environ.get("LOCALAPPDATA")
    if local:
        cands.append(Path(local) / "CapCut" / "Apps" / "CapCut.exe")
    if _last_capcut_exe:
        cands.append(Path(_last_capcut_exe))
    return next((c for c in cands if c.exists()), None)


class CapCutWatch:
    """Можно ли сейчас безопасно писать в проект.

    Безопасно, когда проект не открыт в CapCut (нет окон CapCut или нет файла-
    блокировки .locked) и файл проекта не меняется хотя бы 2 секунды — то есть
    CapCut уже дописал своё сохранение."""

    def __init__(self):
        self.last_mtime = None
        self.stable_since = time.time()

    def mark_written(self, project_path):
        """Файл записали мы сами — это не сохранение CapCut, ждать не нужно."""
        try:
            self.last_mtime = (Path(project_path) / "draft_content.json").stat().st_mtime_ns
        except OSError:
            self.last_mtime = None
        self.last_path, self.stable_since = project_path, 0.0

    def state(self, project_path):
        global _last_capcut_exe
        wins = capcut_windows()
        if wins:
            _last_capcut_exe = wins[0][1]
        locked = bool(project_path) and (Path(project_path) / ".locked").exists()
        mtime = None
        if project_path:
            try:
                mtime = (Path(project_path) / "draft_content.json").stat().st_mtime_ns
            except OSError:
                pass
        if project_path != getattr(self, "last_path", None):
            self.last_path, self.last_mtime, self.stable_since = project_path, mtime, 0.0
        elif mtime != self.last_mtime:
            self.last_mtime, self.stable_since = mtime, time.time()
        settling = time.time() - self.stable_since < 2.0
        project_open = bool(wins) and locked
        return {
            "running": bool(wins),
            "project_open": project_open,
            "settling": settling,
            "safe": not project_open and not settling,
            "can_launch": capcut_exe() is not None,
        }


# --------------------------------------------------------------- проект ----
class Project:
    def __init__(self, path):
        self.path = Path(path)
        self.drafts = {}
        self.encrypted = []
        self.state = {}
        self.load()

    @property
    def name(self):
        return self.path.name

    def load(self):
        self.drafts.clear()
        self.encrypted.clear()
        for fname in cw.draft_paths(self.path):
            d = cw.read_draft(self.path / fname)
            if d is None:
                self.encrypted.append(fname)
            elif isinstance(d.get("tracks"), list):
                self.drafts[fname] = d
        self.state = cw.load_state(self.path)

    @property
    def main(self):
        return next(iter(self.drafts.values()), None)

    def info(self):
        d = self.main or {}
        canvas = d.get("canvas_config") or {}
        dur = int(d.get("duration") or 0)
        elements = self.elements()
        if elements:
            dur = max(dur, max(e["start"] + e["dur"] for e in elements))
        return {
            "name": self.name,
            "encrypted": bool(self.encrypted) and not self.drafts,
            "readable": bool(self.drafts),
            "canvas": {"w": int(canvas.get("width") or 1920), "h": int(canvas.get("height") or 1080)},
            "duration": dur,
            "elements": elements,
        }

    def elements(self):
        d = self.main
        if not d:
            return []
        mats = d.get("materials") or {}
        names = {}
        for m in mats.get("texts", []):
            names[m.get("id")] = cw.text_of_material(m)
        for m in mats.get("videos", []):
            names[m.get("id")] = m.get("material_name") or Path(str(m.get("path") or "")).name
        for m in mats.get("stickers", []):
            names[m.get("id")] = m.get("name") or ""
        try:
            import corner
            cstate = corner.load_corner_state(self.path)
        except Exception:
            cstate = {}
        out, counters, row = [], {}, 0
        tracks = [t for t in d.get("tracks") or [] if t.get("type") in TYPE_NAMES]
        # как в CapCut: тексты и стикеры сверху, видео снизу
        order = {"text": 0, "sticker": 1, "video": 2}
        # верхние слои сверху, основная видеодорожка — внизу (как в CapCut)
        idx = {id(t): i for i, t in enumerate(tracks)}
        tracks.sort(key=lambda t: (order.get(t.get("type"), 9), -idx[id(t)]))
        for track in tracks:
            t = track.get("type")
            counters[t] = counters.get(t, 0) + 1
            for seg in track.get("segments") or []:
                tr = seg.get("target_timerange") or {}
                status = cw.segment_status(seg, self.state)
                lists = cw.base_lists_for(seg, self.state)  # твои ключи (с правками из CapCut)
                key_times = sorted({int(k.get("time_offset", 0))
                                    for kl in lists.values() for k in kl.get("keyframe_list") or []})
                label = (names.get(seg.get("material_id")) or "").replace("\n", " ").strip()
                cst = cstate.get(str(seg.get("id")))
                if cst:
                    label = cst["orig_material"].get("material_name") or label
                clip = seg.get("clip") or {}
                ctr, csc = clip.get("transform") or {}, clip.get("scale") or {}
                base = {p: [[f[0], f[1], f[2], f[3][0], f[3][1], f[4][0], f[4][1]] for f in cw._frames(kl)]
                        for p, kl in lists.items()}
                out.append({
                    "id": seg.get("id"),
                    "type": t,
                    "track": f"{TYPE_NAMES[t]} {counters[t]}",
                    "row": row,
                    "label": label or "Без названия",
                    "start": int(tr.get("start") or 0),
                    "dur": int(tr.get("duration") or 0),
                    "status": status,
                    "keys": len(key_times),
                    "key_times": key_times,
                    "wiggle": (self.state.get(str(seg.get("id"))) or {}).get("params"),
                    "clip": {"x": float(ctr.get("x", 0)), "y": float(ctr.get("y", 0)),
                             "rot": float(clip.get("rotation", 0)),
                             "sx": float(csc.get("x", 1)), "sy": float(csc.get("y", 1))},
                    "uniform": bool((seg.get("uniform_scale") or {}).get("on")),
                    "base": base,
                    "cornered": bool(cst),
                })
            row += 1
        return out

    def segments(self, draft, ids):
        for track in draft.get("tracks") or []:
            for seg in track.get("segments") or []:
                if seg.get("id") in ids:
                    yield seg

    def needs_answer(self, ids):
        """Клипы со старой записью, где правки после рысканья не разобрать автоматически."""
        return [seg.get("id") for seg in self.segments(self.main, ids) if cw.needs_answer_on_edit(seg, self.state)]

    def statuses(self, ids):
        return {seg.get("id"): cw.segment_status(seg, self.state)
                for seg in self.segments(self.main, ids)}

    def apply(self, ids, params, seed, same_motion, on_edited):
        prev = copy.deepcopy(self.state)
        d = self.main
        canvas = d.get("canvas_config") or {}
        w, h = float(canvas.get("width") or 1920), float(canvas.get("height") or 1080)
        n = 0
        for seg in self.segments(d, ids):
            s = cw.segment_seed(seed, seg.get("id"), same_motion)
            entry = cw.apply_to_segment(seg, params, w, h, s, prev, on_edited)
            if entry:
                self.state[str(seg.get("id"))] = entry
                n += 1
        self.sync_copies(ids)
        return n

    def remove(self, ids, on_edited):
        prev = copy.deepcopy(self.state)
        n = 0
        for seg in self.segments(self.main, ids):
            cw.remove_from_segment(seg, prev, on_edited)
            n += 1
        for sid in ids:
            self.state.pop(str(sid), None)
        self.sync_copies(ids)
        return n

    def sync_copies(self, ids):
        """Копии таймлайна получают ровно те же ключи, что и основной файл."""
        src = {seg.get("id"): seg for seg in self.segments(self.main, ids)}
        for d in list(self.drafts.values())[1:]:
            for seg in self.segments(d, ids):
                if seg.get("id") in src:
                    seg["common_keyframes"] = copy.deepcopy(src[seg.get("id")].get("common_keyframes") or [])

    def save(self):
        alive = {str(seg.get("id")) for t in (self.main or {}).get("tracks") or []
                 for seg in t.get("segments") or []}
        self.state = {k: v for k, v in self.state.items() if k in alive}
        cw.backup_project(self.path, self.drafts.keys())
        for fname, d in self.drafts.items():
            cw.write_draft(self.path / fname, d)
        cw.save_state(self.path, self.state)

    def undo(self):
        n = cw.undo_project(self.path)
        self.load()
        return n

    def wiggle_params(self):
        """Параметры рысканья каждого элемента — чтобы нарисовать его кривую."""
        return {sid: st.get("params") for sid, st in self.state.items() if st.get("params")}
