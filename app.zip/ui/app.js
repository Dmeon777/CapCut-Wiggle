"use strict";

/* ================================================================ состояние */
const S = {
  params: {},            // ползунки
  seed: 1,
  same: false,
  projects: [],
  project: null,         // {name, canvas, duration, elements, readable, encrypted}
  selected: new Set(),
  tables: {},            // seed -> [4 таблицы шума]
  pendingSeeds: new Set(),
  capcut: null,
  busy: false,
  t0: performance.now(),
  paused: false,
  pausedAt: 0,
};
const PARAM_KEYS = ["position_px", "rotation_deg", "scale_pct", "frequency", "octaves", "keys_per_second"];
const $ = (id) => document.getElementById(id);
const motionOK = !window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/* ================================================================ сервер */
async function api(name, body = {}) {
  const r = await fetch("/api/" + name, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Token": window.WIGGLE_TOKEN },
    body: JSON.stringify(body),
  });
  const data = await r.json().catch(() => ({ ok: false, error: "Приложение не ответило." }));
  if (!r.ok && !data.error) data.error = "Ошибка " + r.status;
  return data;
}

/* ================================================================ шум (как в движке) */
function noiseAt(table, x) {
  const i = Math.floor(x);
  let t = x - i;
  t = (1 - Math.cos(t * Math.PI)) / 2;
  const a = table[((i % 512) + 512) % 512];
  const b = table[(((i + 1) % 512) + 512) % 512];
  return a * (1 - t) + b * t;
}
function fractal(table, x, octaves) {
  let total = 0, amp = 1, norm = 0, freq = 1;
  for (let o = 0; o < Math.max(1, octaves); o++) {
    total += noiseAt(table, x * freq) * amp;
    norm += amp; amp *= 0.5; freq *= 2;
  }
  return total / norm;
}
/* твои ключи — так же, как их считает CapCut (кривые Безье между ключами) */
function bez(a, b, c, d, u) { const m = 1 - u; return m * m * m * a + 3 * m * m * u * b + 3 * m * u * u * c + u * u * u * d; }
function interp(frames, t) {
  if (!frames || !frames.length) return null;
  if (t <= frames[0][0]) return frames[0][1];
  const last = frames[frames.length - 1];
  if (t >= last[0]) return last[1];
  for (let i = 0; i < frames.length - 1; i++) {
    const [t0, v0, c0, , , rx, ry] = frames[i];
    const [t1, v1, , lx, ly] = frames[i + 1];
    if (t < t0 || t > t1) continue;
    if (t1 === t0) return v1;
    if (c0 === "Line" || c0 === "" || (rx === 0 && ry === 0 && lx === 0 && ly === 0)) return v0 + (v1 - v0) * (t - t0) / (t1 - t0);
    const x1 = Math.min(Math.max(t0 + rx, t0), t1), x2 = Math.min(Math.max(t1 + lx, t0), t1);
    let lo = 0, hi = 1;
    for (let k = 0; k < 30; k++) { const mid = (lo + hi) / 2; if (bez(t0, x1, x2, t1, mid) < t) lo = mid; else hi = mid; }
    return bez(v0, v0 + ry, v1 + ly, v1, (lo + hi) / 2);
  }
  return last[1];
}
function baseAt(e, t) {
  const b = e.base || {}, c = e.clip || { x: 0, y: 0, rot: 0, sx: 1, sy: 1 };
  const g = (p, d) => { const v = interp(b[p], t); return v == null ? d : v; };
  const sx = g("KFTypeScaleX", c.sx);
  const sy = e.uniform ? sx : g("KFTypeScaleY", b.KFTypeScaleX ? sx : c.sy);
  return { x: g("KFTypePositionX", c.x), y: g("KFTypePositionY", c.y), rot: g("KFTypeRotation", c.rot), sx, sy };
}

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(str) {
  const bytes = new TextEncoder().encode(str);
  let c = 0xffffffff;
  for (const b of bytes) c = CRC_TABLE[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function segmentSeed(id) {
  return S.same ? S.seed : S.seed + (crc32(String(id)) % 100000);
}
async function ensureTables(seeds) {
  const need = seeds.filter((s) => !(s in S.tables) && !S.pendingSeeds.has(s));
  if (!need.length) return;
  need.forEach((s) => S.pendingSeeds.add(s));
  const res = await api("noise", { seeds: need });
  need.forEach((s) => S.pendingSeeds.delete(s));
  Object.assign(S.tables, res.tables || {});
  renderTimeline();
}

/* ================================================================ формат */
function fmtTime(us, precise = false) {
  const s = Math.max(0, us) / 1e6;
  const m = Math.floor(s / 60);
  const sec = s - m * 60;
  return precise ? `${m}:${sec.toFixed(1).padStart(4, "0")}` : `${m}:${String(Math.floor(sec)).padStart(2, "0")}`;
}
function plural(n, one, few, many) {
  const a = n % 10, b = n % 100;
  if (a === 1 && b !== 11) return one;
  if (a >= 2 && a <= 4 && (b < 12 || b > 14)) return few;
  return many;
}
const clipsWord = (n) => `${n} ${plural(n, "клип", "клипа", "клипов")}`;
const clipsWordDat = (n) => `${n} ${plural(n, "клипу", "клипам", "клипам")}`;
const clipsWordGen = (n) => `${n} ${plural(n, "клипа", "клипов", "клипов")}`;

/* ================================================================ ползунки */
function buildSliders() {
  document.querySelectorAll(".slider[data-key]").forEach((el) => {
    const key = el.dataset.key;
    const label = el.querySelector("label");
    const id = "s_" + key;
    label.htmlFor = id;
    const val = document.createElement("div");
    val.className = "val";
    val.innerHTML = `<input type="number" aria-label="${label.textContent}"><span class="unit">${el.dataset.unit}</span>`;
    const range = document.createElement("input");
    Object.assign(range, { type: "range", id, min: el.dataset.min, max: el.dataset.max, step: el.dataset.step });
    el.append(range, val);
    const num = val.querySelector("input");
    Object.assign(num, { min: el.dataset.min, max: el.dataset.max, step: el.dataset.step });

    const set = (v, from) => {
      const min = +el.dataset.min, max = +el.dataset.max, step = +el.dataset.step;
      v = Math.min(max, Math.max(min, Math.round(+v / step) * step));
      if (Number.isNaN(v)) return;
      S.params[key] = v;
      if (from !== "range") range.value = v;
      if (from !== "num") num.value = step < 1 ? v.toFixed(1) : String(v);
      range.style.setProperty("--fill", ((v - min) / (max - min)) * 100 + "%");
      saveConfigSoon();
    };
    el._set = set;
    range.addEventListener("input", () => set(range.value, "range"));
    num.addEventListener("change", () => set(num.value, "num"));
    num.addEventListener("blur", () => set(num.value));
  });
}
function setSlidersFromConfig(cfg) {
  document.querySelectorAll(".slider[data-key]").forEach((el) => {
    const v = cfg[el.dataset.key];
    el._set(v == null ? el.dataset.min : v);
  });
  S.seed = parseInt(cfg.seed ?? 1, 10) || 0;
  S.same = !!cfg.same_motion;
  $("seedInput").value = S.seed;
  $("sameMotion").checked = S.same;
}
let saveTimer = null;
function saveConfigSoon() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => api("save_config", { ...S.params, seed: S.seed, same_motion: S.same }), 400);
}

/* ================================================================ таймлайн */
const ICONS = {
  text: '<svg viewBox="0 0 16 16"><path d="M3 3.5h10M8 3.5v9"/></svg>',
  video: '<svg viewBox="0 0 16 16"><rect x="2" y="3.5" width="12" height="9" rx="1.5"/><path d="M6.5 6.2v3.6l3-1.8z"/></svg>',
  sticker: '<svg viewBox="0 0 16 16"><path d="M3 3h10v6l-4 4H3z"/><path d="M9 13V9h4"/></svg>',
};

function elementsSorted() {
  return (S.project?.elements || []).slice().sort((a, b) => a.row - b.row || a.start - b.start);
}

function renderTimeline() {
  const p = S.project;
  const labels = $("tlLabels"), tracks = $("tlTracks"), ruler = $("ruler"), empty = $("tlEmpty");
  labels.innerHTML = "";
  tracks.querySelectorAll(".tl-track").forEach((n) => n.remove());
  ruler.innerHTML = "";

  if (!p || !p.readable || !p.elements.length) {
    empty.hidden = false;
    empty.innerHTML = "";
    const title = document.createElement("strong");
    const text = document.createElement("span");
    if (!S.projects.length) {
      title.textContent = "Не нашёл проекты CapCut";
      text.textContent = "Укажи папку, где CapCut хранит черновики.";
      const b = document.createElement("button");
      b.className = "btn"; b.textContent = "Указать папку"; b.onclick = openSettings;
      empty.append(title, text, b);
    } else if (p && p.encrypted) {
      title.textContent = "Этот проект зашифрован";
      text.textContent = "Его файл CapCut сохранил в закрытом виде, поэтому изменить его нельзя.";
      empty.append(title, text);
    } else if (p) {
      title.textContent = "В проекте нет клипов для рысканья";
      text.textContent = "Добавь в CapCut текст, видео или стикер, и они появятся здесь.";
      empty.append(title, text);
    } else {
      title.textContent = "Выбери проект сверху";
      empty.append(title);
    }
    updateSelectionUI();
    return;
  }
  empty.hidden = true;

  const width = tracks.clientWidth;
  const D = Math.max(p.duration, 1e6);
  const usable = Math.max(100, width - 24);
  const xOf = (us) => (us / D) * usable + 8;

  // линейка
  const pxPerSec = usable / (D / 1e6);
  const steps = [0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300];
  const step = steps.find((s) => s * pxPerSec >= 70) || 600;
  for (let s = 0; s * 1e6 <= D + 1; s += step / 2) {
    const major = Math.round(s / step * 2) % 2 === 0;
    const tick = document.createElement("div");
    tick.className = "tick" + (major ? " major" : "");
    tick.style.left = xOf(s * 1e6) + "px";
    if (major) tick.innerHTML = `<span>${fmtTime(s * 1e6, step < 1)}</span>`;
    ruler.append(tick);
  }

  // дорожки
  const rows = new Map();
  for (const e of p.elements) {
    if (!rows.has(e.row)) rows.set(e.row, { name: e.track, type: e.type, items: [] });
    rows.get(e.row).items.push(e);
  }
  const needSeeds = [];
  [...rows.keys()].sort((a, b) => a - b).forEach((r) => {
    const row = rows.get(r);
    const lab = document.createElement("div");
    lab.className = "tl-label";
    lab.innerHTML = ICONS[row.type] || "";
    lab.append(document.createTextNode(row.name));
    labels.append(lab);

    const track = document.createElement("div");
    track.className = "tl-track";
    for (const e of row.items) {
      const clip = document.createElement("button");
      clip.className = "clip" + (S.selected.has(e.id) ? " selected" : "");
      clip.dataset.type = e.type;
      clip.dataset.id = e.id;
      const left = xOf(e.start), w = Math.max(6, xOf(e.start + e.dur) - left);
      clip.style.left = left + "px";
      clip.style.width = w + "px";
      clip.title = `${e.label}\n${fmtTime(e.start, true)} – ${fmtTime(e.start + e.dur, true)}` +
        (e.keys ? `\nТвоих ключей: ${e.keys}` : "") +
        (e.status === "wiggled" ? "\nРысканье есть" : "");
      clip.setAttribute("aria-pressed", S.selected.has(e.id) ? "true" : "false");

      const name = document.createElement("span");
      name.className = "clip-name";
      name.textContent = e.label;
      clip.append(name);

      if (e.cornered) {
        const badge = document.createElement("span");
        badge.className = "clip-badge";
        badge.textContent = "углы";
        clip.append(badge);
      } else if (e.status === "lost" || e.status === "edited") {
        const badge = document.createElement("span");
        badge.className = "clip-badge";
        badge.textContent = e.status === "lost" ? "сброшено CapCut" : "изменено в CapCut";
        clip.append(badge);
        name.style.right = "130px";
      }
      if (e.wiggle && e.status !== "lost") {
        const seed = e.wiggle.seed;
        if (S.tables[seed]) clip.append(waveSvg(e, w));
        else needSeeds.push(seed);
      }
      for (const kt of e.key_times) {
        if (kt < 0 || kt > e.dur) continue;
        const k = document.createElement("span");
        k.className = "clip-key";
        k.style.left = Math.min(w - 5, Math.max(5, (kt / e.dur) * w)) + "px";
        clip.append(k);
      }
      track.append(clip);
    }
    tracks.append(track);
  });
  if (needSeeds.length) ensureTables([...new Set(needSeeds)]);
  updateSelectionUI();
}

function waveSvg(e, w) {
  const P = e.wiggle, table = S.tables[P.seed][0];
  const ns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("class", "clip-wave");
  svg.setAttribute("viewBox", `0 0 ${w} 22`);
  svg.setAttribute("preserveAspectRatio", "none");
  const amp = Math.min(1, 0.55 + (P.position_px || 0) / 30) * 9;
  let d = "";
  for (let x = 0; x <= w; x += 2) {
    const tSec = (x / w) * (e.dur / 1e6);
    const v = fractal(table, tSec * P.frequency, Math.round(P.octaves));
    d += (x ? "L" : "M") + x.toFixed(1) + " " + (11 - v * amp).toFixed(2);
  }
  const path = document.createElementNS(ns, "path");
  path.setAttribute("d", d);
  svg.append(path);
  return svg;
}

/* ================================================================ выбор */
let lastClicked = null;
function onTrackClick(ev) {
  const clip = ev.target.closest(".clip");
  if (!clip) {
    if (ev.target.closest(".tl-track")) { S.selected.clear(); renderTimeline(); }
    return;
  }
  const id = clip.dataset.id;
  const order = elementsSorted().map((e) => e.id);
  if (ev.shiftKey && lastClicked && order.includes(lastClicked)) {
    const [a, b] = [order.indexOf(lastClicked), order.indexOf(id)].sort((x, y) => x - y);
    order.slice(a, b + 1).forEach((x) => S.selected.add(x));
  } else if (ev.ctrlKey || ev.metaKey) {
    S.selected.has(id) ? S.selected.delete(id) : S.selected.add(id);
  } else {
    S.selected = new Set([id]);
  }
  lastClicked = id;
  S.t0 = performance.now(); S.pausedAt = 0;
  renderTimeline();
}

function selectedElements() {
  return elementsSorted().filter((e) => S.selected.has(e.id));
}

function updateSelectionUI() {
  const sel = selectedElements();
  const n = sel.length;
  $("selInfo").textContent = S.project ? fmtTime(S.project.duration, true) : "";
  $("selInfo").title = "Длина проекта";
  $("applyBtn").disabled = !n || S.busy;
  $("applyBtn").textContent = n > 1 ? `Добавить рысканье к ${clipsWordDat(n)}` : "Добавить рысканье";
  $("removeBtn").disabled = !n || S.busy;
  $("undoBtn").disabled = !S.project || S.busy;

  const first = sel[0];
  const corner = window.CP && CP.active;
  $("stageEmpty").hidden = corner || (window.TH && TH.active) || !!first || !(S.project && S.project.elements.length);
  $("frame").style.visibility = first ? "visible" : "hidden";
  if (corner) CP.onSelection();
  const subj = $("subject");
  if (first) {
    subj.classList.toggle("is-video", first.type !== "text");
    $("subjectText").textContent = first.label;
    ensureTables([segmentSeed(first.id)]);
  }
  layoutStage();
}

/* ================================================================ сцена и превью */
function layoutStage() {
  const stage = $("stage"), frame = $("frame");
  const c = S.project?.canvas || { w: 1920, h: 1080 };
  const pad = 28;
  const sw = stage.clientWidth - pad * 2, sh = stage.clientHeight - pad * 2;
  const scale = Math.max(0.05, Math.min(sw / c.w, sh / c.h));
  frame.style.width = c.w * scale + "px";
  frame.style.height = c.h * scale + "px";
  frame.dataset.k = scale;
  const subj = $("subject");
  subj.style.fontSize = subj.classList.contains("is-video") ? "13px" : Math.max(13, c.h * scale * 0.1) + "px";
}

function frameLoop(now) {
  if (window.TH && TH.active) { requestAnimationFrame(frameLoop); return; }
  if (window.CP && CP.active) {
    CP.frame(now);
    requestAnimationFrame(frameLoop);
    return;
  }
  const sel = selectedElements();
  const first = sel[0];
  const ph = $("playhead");
  if (first && S.project) {
    const dur = Math.max(first.dur, 1);
    const t = S.paused || !motionOK ? S.pausedAt % dur : ((now - S.t0) * 1000) % dur;   // мкс внутри клипа
    S.curT = t;
    const seed = segmentSeed(first.id);
    const tb = S.tables[seed];
    const k = +$("frame").dataset.k || 0.4;
    const P = S.params;
    let dx = 0, dy = 0, rot = 0, sc = 1;
    if (tb) {
      const x = (t / 1e6) * P.frequency, o = Math.round(P.octaves);
      dx = P.position_px * fractal(tb[0], x, o);
      dy = P.position_px * fractal(tb[1], x, o);
      rot = P.rotation_deg * fractal(tb[2], x, o);
      sc = 1 + (P.scale_pct / 100) * fractal(tb[3], x, o);
    }
    // твоя анимация (место в кадре, ключи) + рысканье поверх
    const c = S.project.canvas, B = baseAt(first, t);
    const px = B.x * c.w / 2 + dx, py = -(B.y * c.h / 2) - dy;
    $("subject").style.transform =
      `translate(${(px * k).toFixed(2)}px, ${(py * k).toFixed(2)}px) rotate(${(B.rot + rot).toFixed(3)}deg) ` +
      `scale(${(B.sx * sc).toFixed(4)}, ${(B.sy * sc).toFixed(4)})`;

    // плейхед бежит по выбранному клипу
    const tracks = $("tlTracks");
    const D = Math.max(S.project.duration, 1e6);
    const usable = Math.max(100, tracks.clientWidth - 24);
    ph.hidden = false;
    ph.style.transform = "";
    ph.style.left = ((first.start + t) / D) * usable + 8 + "px";
    $("stageCaption").textContent = `${fmtTime(t, true)} / ${fmtTime(dur, true)}`;
    $("clipTitle").textContent = sel.length > 1 ? `${first.label} и ещё ${sel.length - 1}` : first.label;
  } else {
    ph.hidden = true;
    $("stageCaption").textContent = "0:00.0";
    $("clipTitle").textContent = "";
  }
  requestAnimationFrame(frameLoop);
}

function togglePlay() {
  if (window.CP && CP.active) { CP.togglePlay(); return; }
  if (S.paused) { S.paused = false; S.t0 = performance.now() - S.pausedAt / 1000; }
  else { S.paused = true; S.pausedAt = S.curT || 0; }
  const b = $("playBtn");
  b.classList.toggle("paused", S.paused);
  b.title = S.paused ? "Воспроизвести (пробел)" : "Пауза (пробел)";
  b.setAttribute("aria-label", S.paused ? "Воспроизвести" : "Пауза");
}

/* ================================================================ диалоги */
const ICON_WARN = '<svg viewBox="0 0 32 32"><path d="M16 4l13 23H3z"/><path d="M16 13v6M16 23v.5"/></svg>';
let sheetResolve = null;
function openSheet({ icon = "", title, text, live = null, field = null, buttons, inline = false }) {
  const d = $("sheet");
  $("sheetIcon").innerHTML = icon;
  $("sheetTitle").textContent = title;
  $("sheetText").textContent = text || "";
  $("sheetText").hidden = !text;
  $("sheetLive").hidden = live == null;
  $("sheetLiveText").textContent = live || "";
  $("sheetField").hidden = !field;
  if (field) $("sheetInput").value = field.value || "";
  const box = $("sheetButtons");
  box.className = "sheet-buttons" + (inline ? " inline" : "");
  box.innerHTML = "";
  for (const b of buttons) {
    const el = document.createElement("button");
    el.className = "btn" + (b.primary ? " primary" : "") + (b.danger ? " danger" : "");
    el.value = b.value;
    el.textContent = b.label;
    box.append(el);
  }
  return new Promise((resolve) => {
    sheetResolve = resolve;
    d.returnValue = "cancel";
    d.showModal();
    const primary = box.querySelector(".primary") || box.querySelector("button");
    if (!field && primary) primary.focus();
  });
}
function closeSheet(value) {
  const d = $("sheet");
  if (d.open) d.close(value);
}
$("sheet").addEventListener("close", () => {
  const r = sheetResolve; sheetResolve = null;
  if (r) r($("sheet").returnValue || "cancel");
});

/* ================================================================ уведомления */
let toastTimer = null;
function toast(text, { kind = "info", action = null } = {}) {
  const t = $("toast");
  $("toastText").textContent = text;
  t.dataset.kind = kind;
  const a = $("toastAction");
  a.hidden = !action;
  if (action) { a.textContent = action.label; a.onclick = () => { action.run(); t.hidden = true; }; }
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), action ? 9000 : 4500);
}

/* ================================================================ действия */
// вызов, который пишет в проект: если проект открыт в CapCut — ждём, пока из него выйдут
async function gated(name, body) {
  const res = await api(name, body);
  if (res.need !== "close_capcut") return res;
  const v = await waitCapcutClosed();
  if (v === "auto") return gated(name, { ...body, reopen: true });
  if (v === "force") return gated(name, { ...body, force: true });
  return null;
}
async function afterChange(res, done, reopen = false) {
  const name = S.project ? `«${S.project.name}»` : "проект";
  const st = await api("capcut");
  if (st.running) { toast(`${done}. Открой проект ${name} в CapCut.`); return; }
  if (reopen) {
    const r = await api("launch_capcut");
    toast(r.ok ? `${done}. CapCut открывается — открой проект ${name}.` : `${done}. ${r.error}`, { kind: r.ok ? "info" : "error" });
    return;
  }
  toast(`${done}. Открой проект ${name} в CapCut.`, st.can_launch ? { action: { label: "Открыть CapCut", run: () => api("launch_capcut") } } : {});
}
async function run(kind, extra = {}) {
  if (S.busy) return;
  const ids = [...S.selected];
  const body = { ids, params: S.params, seed: S.seed, same_motion: S.same, ...extra };
  S.busy = true; updateSelectionUI();
  let res;
  try { res = await api(kind, body); }
  finally { S.busy = false; updateSelectionUI(); }

  if (res.need === "close_capcut") {
    const v = await waitCapcutClosed();
    if (v === "auto") return run(kind, { ...extra, reopen: true });
    if (v === "force") return run(kind, { ...extra, force: true });
    return;
  }
  if (res.need === "edited") {
    const v = await openSheet({
      icon: ICON_WARN,
      title: "Ключи меняли после рысканья",
      text: `У ${clipsWordGen(res.count)} ключевые кадры правили в CapCut уже после того, как на них легло рысканье.`,
      buttons: [
        { label: "Вернуть мои ключи и наложить заново", value: "restore", primary: true },
        { label: "Оставить правки, наложить поверх", value: "current" },
        { label: "Отмена", value: "cancel" },
      ],
    });
    if (v === "restore" || v === "current") return run(kind, { ...extra, on_edited: v });
    return;
  }
  if (res.need === "edited_remove") {
    const v = await openSheet({
      icon: ICON_WARN,
      title: "Ключи меняли после рысканья",
      text: `У ${clipsWordGen(res.count)} ключи правили в CapCut после рысканья. Если вернуть ключи как было, эти правки пропадут.`,
      buttons: [
        { label: "Вернуть ключи как до рысканья", value: "restore", primary: true },
        { label: "Оставить как есть", value: "current" },
        { label: "Отмена", value: "cancel" },
      ],
    });
    if (v === "restore" || v === "current") return run(kind, { ...extra, on_edited: v });
    return;
  }
  if (res.need === "unknown") {
    const v = await openSheet({
      icon: ICON_WARN,
      title: "Не знаю, где тут рысканье",
      text: `У ${clipsWordGen(res.count)} рысканье добавляла старая версия программы (или ключи только твои), поэтому их нельзя отделить от твоих ключей.`,
      buttons: [
        { label: "Удалить все ключи позиции, поворота и масштаба", value: "wipe", danger: true },
        { label: "Не трогать эти клипы", value: "skip", primary: true },
      ],
    });
    if (v === "wipe" || v === "skip") return run(kind, { ...extra, wipe_unknown: v === "wipe" });
    return;
  }
  if (!res.ok) {
    toast(res.error || "Не получилось.", { kind: "error" });
    return;
  }

  if (res.project) { S.project = res.project; keepSelection(); renderTimeline(); }
  if (extra.reopen && res.count) {
    const name = S.project ? `«${S.project.name}»` : "проект";
    const done = kind === "apply" ? "Рысканье добавлено" : kind === "remove" ? "Рысканье убрано" : "Изменение отменено";
    const st = await api("capcut");
    if (st.running) {
      // CapCut на вкладке проектов — осталось открыть проект
      toast(`${done}. Открой проект ${name} в CapCut — он на вкладке проектов.`);
    } else {
      // CapCut закрыли целиком — запускаем снова
      const r = await api("launch_capcut");
      toast(r.ok ? `${done}. CapCut открывается — открой проект ${name}.` : `${done}. ${r.error}`, { kind: r.ok ? "info" : "error" });
    }
    return;
  }
  const launch = S.capcut && !S.capcut.running && S.capcut.can_launch
    ? { label: "Открыть CapCut", run: () => api("launch_capcut").then((r) => !r.ok && toast(r.error, { kind: "error" })) }
    : null;
  if (kind === "apply") toast(`Рысканье добавлено к ${clipsWordDat(res.count)}. Открой проект в CapCut.`, { action: launch });
  if (kind === "remove") toast(res.count ? `Рысканье убрано у ${clipsWordGen(res.count)}. Твои ключи на месте.` : "У выбранных клипов нечего убирать.", { action: res.count ? launch : null });
  if (kind === "undo") toast(res.count ? "Последнее изменение отменено." : "Отменять нечего.", { action: res.count ? launch : null });
}

function keepSelection() {
  const ids = new Set((S.project?.elements || []).map((e) => e.id));
  S.selected = new Set([...S.selected].filter((id) => ids.has(id)));
}

async function waitCapcutClosed() {
  let poll = null;
  const p = openSheet({
    icon: ICON_WARN,
    title: "Выйди из проекта в CapCut",
    text: "Пока проект открыт, CapCut держит его в памяти и сохранит поверх изменений. Нажми в CapCut крестик — он вернётся на вкладку проектов, а я сразу внесу изменения. Потом просто открой проект снова.",
    live: "Жду, пока ты выйдешь из проекта…",
    buttons: [
      { label: "Отмена", value: "cancel" },
      { label: "Применить, не дожидаясь", value: "force", danger: true },
    ],
    inline: true,
  });
  poll = setInterval(async () => {
    const st = await api("capcut");
    S.capcut = st; renderCapcut();
    if (st.safe) closeSheet("auto");
    else $("sheetLiveText").textContent = st.project_open ? "Проект ещё открыт в CapCut…" : "CapCut сохраняет проект…";
  }, 1000);
  const v = await p;
  clearInterval(poll);
  return v;
}

async function openSettings() {
  const st = await api("state");
  const promise = openSheet({
    title: "Папка проектов CapCut",
    text: "Обычно это …\\CapCut\\User Data\\Projects\\com.lveditor.draft. Точный путь видно в CapCut: Меню → Настройки → Черновики.",
    field: { value: st.drafts_dir },
    buttons: [{ label: "Сохранить", value: "save", primary: true }, { label: "Отмена", value: "cancel" }],
    inline: true,
  });
  $("sheetBrowse").onclick = async () => {
    const r = await api("browse");
    if (r.path) $("sheetInput").value = r.path;
  };
  const v = await promise;
  if (v !== "save") return;
  const r = await api("set_drafts_dir", { path: $("sheetInput").value });
  if (!r.ok) return toast(r.error || "Не получилось.", { kind: "error" });
  applyState(r);
}

/* ================================================================ обновление */
function setProjectList(projects, current) {
  S.projects = projects || [];
  const sel = $("projectSelect");
  sel.innerHTML = "";
  for (const p of S.projects) sel.append(new Option(p.name, p.name));
  if (current) sel.value = current;
  sel.disabled = !S.projects.length;
}
async function refreshProject({ quiet = false } = {}) {
  const btn = $("refreshBtn");
  btn.classList.remove("spinning"); void btn.offsetWidth; btn.classList.add("spinning");
  const r = await api("refresh");
  if (!r.ok) { if (!quiet) toast(r.error || "Не получилось обновить.", { kind: "error" }); return; }
  const before = S.project ? S.project.elements.length : 0;
  S.project = r.project;
  setProjectList(r.projects, S.project?.name);
  keepSelection();
  renderTimeline();
  if (!quiet) {
    const n = S.project ? S.project.elements.length : 0;
    const diff = n - before;
    toast(diff > 0 ? `Проект обновлён: ${diff > 1 ? "новых клипов: " + diff : "новый клип"} на таймлайне.` :
          `Проект обновлён: ${clipsWord(n)}.`);
  }
}

/* ================================================================ CapCut-индикатор */
function renderCapcut() {
  const st = S.capcut, pill = $("capcutPill"), text = $("capcutText");
  if (!st) return;
  if (st.project_open) { pill.dataset.state = "open"; text.textContent = "Проект открыт в CapCut"; }
  else if (st.settling) { pill.dataset.state = "settling"; text.textContent = "CapCut сохраняет проект…"; }
  else if (st.running) { pill.dataset.state = "safe"; text.textContent = "CapCut на вкладке проектов"; }
  else { pill.dataset.state = "safe"; text.textContent = "CapCut закрыт"; }
}
async function pollCapcut() {
  if (!$("sheet").open) {
    const st = await api("capcut").catch(() => null);
    if (st) {
      S.capcut = st; renderCapcut();
      if (st.changed && !st.settling && !S.busy) await refreshProject({ quiet: true });
    }
  }
  setTimeout(pollCapcut, 1500);
}

/* ================================================================ старт */
function applyState(st) {
  S.projects = st.projects || [];
  S.project = st.project;
  setSlidersFromConfig(st.config || {});
  const sel = $("projectSelect");
  sel.innerHTML = "";
  for (const p of S.projects) sel.append(new Option(p.name, p.name));
  if (S.project) sel.value = S.project.name;
  sel.disabled = !S.projects.length;
  keepSelection();
  renderTimeline();
}

async function init() {
  buildSliders();
  $("tlTracks").addEventListener("click", onTrackClick);
  $("projectSelect").addEventListener("change", async (e) => {
    const r = await api("open", { name: e.target.value });
    S.project = r.project; S.selected.clear(); renderTimeline();
  });
  $("applyBtn").onclick = () => run("apply");
  $("removeBtn").onclick = () => run("remove");
  $("undoBtn").onclick = () => run("undo");
  $("settingsBtn").onclick = openSettings;
  $("refreshBtn").onclick = () => refreshProject();
  $("playBtn").onclick = togglePlay;
  $("seedInput").addEventListener("change", (e) => {
    S.seed = Math.max(0, parseInt(e.target.value, 10) || 0);
    e.target.value = S.seed; S.t0 = performance.now(); saveConfigSoon(); updateSelectionUI();
  });
  $("diceBtn").onclick = () => {
    S.seed = 1 + Math.floor(Math.random() * 99999);
    $("seedInput").value = S.seed; S.t0 = performance.now(); saveConfigSoon(); updateSelectionUI();
  };
  $("sameMotion").addEventListener("change", (e) => { S.same = e.target.checked; saveConfigSoon(); updateSelectionUI(); });

  document.addEventListener("keydown", (e) => {
    if ($("sheet").open) return;
    if (e.key === "F5" || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "r")) {
      e.preventDefault(); refreshProject(); return;
    }
    const typing = /^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement?.tagName || "");
    if (window.TH && TH.active) return;   // у «Превью» свои клавиши
    if (e.key === "Escape" && S.selected.size) { S.selected.clear(); renderTimeline(); }
    if (typing) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "a" && S.project) {
      e.preventDefault(); S.project.elements.forEach((x) => S.selected.add(x.id)); renderTimeline();
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") { e.preventDefault(); run("undo"); }
    if (e.key === " " && !e.target.closest("button")) { e.preventDefault(); togglePlay(); }
  });

  let lastW = 0;
  new ResizeObserver(() => {
    const w = $("tlTracks").clientWidth;
    if (w !== lastW) { lastW = w; renderTimeline(); }
  }).observe($("tlTracks"));
  new ResizeObserver(() => layoutStage()).observe($("stage"));

  const st0 = await api("state");
  if (st0.version) {
    document.title = `CapCut Wiggle ${st0.version}`;
    document.querySelector(".app-name").title = `Версия ${st0.version}`;
  }
  applyState(st0);
  await CP.init();
  pollCapcut();
  setInterval(() => api("beat").catch(() => {}), 2000);
  api("beat");
  requestAnimationFrame(frameLoop);
}

init().catch((err) => toast("Не удалось запустить: " + err.message, { kind: "error" }));
