"""
CapCut Wiggle — процедурное «рысканье» для элементов проекта CapCut.

Рысканье накладывается ПОВЕРХ твоих ключевых кадров позиции, поворота и масштаба:
в каждый момент берётся значение из твоих ключей и к нему добавляется плавный шум.
Твои исходные ключи запоминаются в файле wiggle_state.json в папке проекта —
«убрать рысканье» возвращает их как были, а повторное применение строится от них.

Это движок и одновременно версия для командной строки. Обычно удобнее окно:
Start.bat / capcut_wiggle_gui.py.

  python capcut_wiggle.py --list   — показать проекты
  python capcut_wiggle.py          — применить настройки из wiggle_config.json
  python capcut_wiggle.py --undo   — вернуть проект из последней резервной копии

CapCut во время работы должен быть закрыт.
"""

import argparse
import copy
import hashlib
import json
import math
import os
import random
import shutil
import sys
import time
import uuid
import zlib
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "wiggle_config.json"
DRAFT_FILES = ("draft_content.json", "draft_info.json")
STATE_FILE = "wiggle_state.json"
CORNER_FILE = "corner_state.json"
BACKUP_SUFFIX = ".wiggle-backup-"
KEEP_BACKUPS = 20
US = 1_000_000  # микросекунд в секунде — в них CapCut хранит время

KF_POS_X = "KFTypePositionX"
KF_POS_Y = "KFTypePositionY"
KF_ROT = "KFTypeRotation"
KF_SCALE_X = "KFTypeScaleX"
KF_SCALE_Y = "KFTypeScaleY"
WIGGLE_PROPS = (KF_POS_X, KF_POS_Y, KF_ROT, KF_SCALE_X, KF_SCALE_Y)

DEFAULT_CONFIG = {
    "project": "",
    "drafts_dir": "",
    "targets": {"text": True, "sticker": False, "video": False},
    "match_text": "",
    "position_px": 6,
    "rotation_deg": 1.5,
    "scale_pct": 2,
    "frequency": 2.0,
    "octaves": 2,
    "keys_per_second": 12,
    "seed": 1,
    "same_motion": False,
}


# ---------------------------------------------------------------- конфиг ----
def load_config():
    if not CONFIG_PATH.exists():
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_CONFIG, f, indent=4, ensure_ascii=False)
    with open(CONFIG_PATH, "r", encoding="utf-8-sig") as f:
        data = json.load(f)
    cfg = copy.deepcopy(DEFAULT_CONFIG)
    for k, v in data.items():
        if k == "targets" and isinstance(v, dict):
            cfg["targets"].update(v)
        else:
            cfg[k] = v
    return cfg


def default_drafts_dirs():
    home = Path.home()
    dirs = []
    local = os.environ.get("LOCALAPPDATA")
    if local:
        dirs.append(Path(local) / "CapCut" / "User Data" / "Projects" / "com.lveditor.draft")
    dirs.append(home / "AppData" / "Local" / "CapCut" / "User Data" / "Projects" / "com.lveditor.draft")
    dirs.append(home / "Movies" / "CapCut" / "User Data" / "Projects" / "com.lveditor.draft")
    return dirs


def find_drafts_dir(cfg):
    if cfg.get("drafts_dir"):
        p = Path(os.path.expandvars(os.path.expanduser(cfg["drafts_dir"])))
        if p.is_dir():
            return p
        sys.exit(f"[!] Папка из drafts_dir не найдена: {p}")
    for p in default_drafts_dirs():
        if p.is_dir():
            return p
    sys.exit("[!] Не нашёл папку проектов CapCut. Посмотри её в CapCut: "
             "Настройки → Черновики (место хранения) и впиши в drafts_dir.")


def project_dirs(drafts_dir):
    return sorted(
        (d for d in drafts_dir.iterdir()
         if d.is_dir() and any((d / f).exists() for f in DRAFT_FILES)),
        key=lambda d: d.stat().st_mtime, reverse=True)


def resolve_project(cfg):
    name = str(cfg.get("project") or "").strip()
    if name:
        p = Path(os.path.expandvars(os.path.expanduser(name)))
        if p.is_dir() and any((p / f).exists() for f in DRAFT_FILES):
            return p
    drafts = find_drafts_dir(cfg)
    if not name:
        sys.exit("[!] Впиши имя проекта в wiggle_config.json (\"project\"). "
                 "Список: python capcut_wiggle.py --list")
    for d in project_dirs(drafts):
        if d.name == name:
            return d
    sys.exit(f"[!] Проект «{name}» не найден в {drafts}. "
             "Список: python capcut_wiggle.py --list")


# ------------------------------------------------------------------ шум ----
class Noise1D:
    """Плавный 1D-шум (value noise с косинусной интерполяцией), значения −1…1."""

    def __init__(self, seed):
        rnd = random.Random(seed)
        self.table = [rnd.uniform(-1.0, 1.0) for _ in range(512)]

    def _v(self, i):
        return self.table[i % 512]

    def at(self, x):
        i = math.floor(x)
        t = x - i
        t = (1 - math.cos(t * math.pi)) / 2
        return self._v(i) * (1 - t) + self._v(i + 1) * t

    def fractal(self, x, octaves):
        total, amp, norm, freq = 0.0, 1.0, 0.0, 1.0
        for _ in range(max(1, octaves)):
            total += self.at(x * freq) * amp
            norm += amp
            amp *= 0.5
            freq *= 2.0
        return total / norm


def segment_seed(seed, seg_id, same_motion):
    return seed if same_motion else seed + zlib.crc32(str(seg_id).encode()) % 100000


# ------------------------------------------------------- файлы проекта ----
def read_draft(path):
    raw = path.read_bytes()
    text = raw.decode("utf-8-sig", errors="replace").lstrip()
    if not text.startswith("{"):
        return None  # зашифрованный формат новых версий CapCut
    return json.loads(text)


def draft_paths(project_dir):
    """Файлы проекта, которые надо править (пути относительно папки проекта).

    Новые версии CapCut держат копию таймлайна ещё и в Timelines/<id>/draft_content.json —
    её правим вместе с основной, иначе CapCut может открыть старую копию."""
    project_dir = Path(project_dir)
    out = [f for f in DRAFT_FILES if (project_dir / f).exists()]
    timeline_ids = set()
    for f in out:
        try:
            d = read_draft(project_dir / f)
        except (OSError, json.JSONDecodeError):
            d = None
        if isinstance(d, dict) and d.get("id"):
            timeline_ids.add(str(d["id"]))
    for tid in sorted(timeline_ids):
        tdir = project_dir / "Timelines" / tid
        for f in DRAFT_FILES:
            if (tdir / f).exists():
                out.append(f"Timelines/{tid}/{f}")
    return out


def write_draft(path, draft):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(draft, f, ensure_ascii=False, separators=(",", ":"))


def load_state(project_dir):
    p = Path(project_dir) / STATE_FILE
    if not p.exists():
        return {}
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def save_state(project_dir, state):
    with open(Path(project_dir) / STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False)


def backup_project(project_dir, fnames):
    """Копия файлов проекта и состояния перед изменением. Возвращает метку."""
    project_dir = Path(project_dir)
    stamp = time.strftime("%Y%m%d-%H%M%S") + f"-{int(time.time() * 1000) % 1000:03d}"
    for fname in list(fnames) + [STATE_FILE, CORNER_FILE]:
        src = project_dir / fname
        dst = project_dir / (fname + BACKUP_SUFFIX + stamp)
        if src.exists():
            shutil.copy2(src, dst)
        elif fname in (STATE_FILE, CORNER_FILE):
            dst.write_text("{}", encoding="utf-8")  # чтобы откат вернул «состояния не было»
        for old in sorted(project_dir.glob(fname + BACKUP_SUFFIX + "*"))[:-KEEP_BACKUPS]:
            old.unlink(missing_ok=True)
    return stamp


def undo_project(project_dir):
    """Вернуть файлы к последней копии и удалить её. Возвращает число файлов."""
    project_dir = Path(project_dir)
    n = 0
    for fname in draft_paths(project_dir) + [STATE_FILE, CORNER_FILE]:
        backups = sorted(project_dir.glob(fname + BACKUP_SUFFIX + "*"))
        if backups:
            shutil.copy2(backups[-1], project_dir / fname)
            backups[-1].unlink(missing_ok=True)
            n += fname not in (STATE_FILE, CORNER_FILE)
    return n


def text_of_material(m):
    content = m.get("content")
    if isinstance(content, str):
        try:
            c = json.loads(content)
            if isinstance(c, dict) and "text" in c:
                return str(c["text"])
        except json.JSONDecodeError:
            return content
    return str(m.get("recognize_text") or m.get("text") or "")


# ------------------------------------------------------ ключевые кадры ----
def make_kf(t_us, value, curve="Line"):
    return {
        "curveType": curve,
        "graphID": "",
        "id": uuid.uuid4().hex.upper(),
        "left_control": {"x": 0.0, "y": 0.0},
        "right_control": {"x": 0.0, "y": 0.0},
        "time_offset": int(t_us),
        "values": [float(value)],
        "string_value": "",
    }


def make_kf_list(prop, frames):
    return {"id": uuid.uuid4().hex.upper(), "keyframe_list": frames,
            "material_id": "", "property_type": prop}


def get_lists(seg):
    """Списки ключей позиции/поворота/масштаба сегмента: {свойство: список}."""
    return {kl.get("property_type"): kl for kl in seg.get("common_keyframes") or []
            if kl.get("property_type") in WIGGLE_PROPS and kl.get("keyframe_list")}


def set_lists(seg, lists):
    others = [kl for kl in seg.get("common_keyframes") or []
              if kl.get("property_type") not in WIGGLE_PROPS]
    seg["common_keyframes"] = others + list(lists.values())  # порядок как был у тебя


def fingerprint(lists):
    data = {p: [(int(k.get("time_offset", 0)), round(float((k.get("values") or [0])[0]), 6))
                for k in lists[p].get("keyframe_list", [])]
            for p in sorted(lists)}
    return hashlib.sha1(json.dumps(data).encode()).hexdigest()


def user_key_count(lists):
    return sum(len(kl.get("keyframe_list") or []) for kl in lists.values())


def _frames(kl):
    """Ключи свойства: (время, значение, тип кривой, левая ручка, правая ручка)."""
    out = []
    for k in sorted(kl.get("keyframe_list") or [], key=lambda k: int(k.get("time_offset", 0))):
        lc, rc = k.get("left_control") or {}, k.get("right_control") or {}
        out.append((int(k.get("time_offset", 0)), float((k.get("values") or [0])[0]),
                    k.get("curveType") or "Line",
                    (float(lc.get("x", 0)), float(lc.get("y", 0))),
                    (float(rc.get("x", 0)), float(rc.get("y", 0)))))
    return out


def _bez(a, b, c, d, u):
    m = 1 - u
    return m * m * m * a + 3 * m * m * u * b + 3 * m * u * u * c + u * u * u * d


def interp(frames, t):
    """Значение твоих ключей в момент t — так же, как его считает CapCut.

    Между ключами CapCut строит кривую Безье: правая ручка ключа и левая ручка
    следующего — смещения (время в мкс, значение) от самих ключей. Пресеты
    скорости вроде «Rebound In/Out» записываются именно этими ручками."""
    if not frames:
        return None
    if t <= frames[0][0]:
        return frames[0][1]
    if t >= frames[-1][0]:
        return frames[-1][1]
    for (t0, v0, c0, _, r0), (t1, v1, _, l1, _) in zip(frames, frames[1:]):
        if not (t0 <= t <= t1):
            continue
        if t1 == t0:
            return v1
        if c0 in ("Line", "") or (r0 == (0.0, 0.0) and l1 == (0.0, 0.0)):
            return v0 + (v1 - v0) * (t - t0) / (t1 - t0)
        x1 = min(max(t0 + r0[0], t0), t1)
        x2 = min(max(t1 + l1[0], t0), t1)
        y1, y2 = v0 + r0[1], v1 + l1[1]
        lo, hi = 0.0, 1.0
        for _ in range(40):  # ищем u, при котором кривая проходит через момент t
            mid = (lo + hi) / 2
            if _bez(t0, x1, x2, t1, mid) < t:
                lo = mid
            else:
                hi = mid
        return _bez(v0, y1, y2, v1, (lo + hi) / 2)
    return frames[-1][1]


class WiggleNoise:
    """Смещения рысканья в любой момент времени — одинаковые при записи и при разборе
    правок, поэтому шум можно точно вычесть обратно."""

    def __init__(self, params, seed, canvas_w, canvas_h, uniform):
        self.pos = float(params.get("position_px") or 0)
        self.rot = float(params.get("rotation_deg") or 0)
        self.scl = float(params.get("scale_pct") or 0)
        self.freq = max(0.01, float(params.get("frequency") or 1))
        self.oct = int(round(float(params.get("octaves") or 1)))
        self.uniform = bool(uniform)
        self.amp_x = self.pos / (canvas_w / 2) if canvas_w else 0  # позиция — в долях полу-холста
        self.amp_y = self.pos / (canvas_h / 2) if canvas_h else 0
        self.n = [Noise1D(int(seed) * 7919 + k) for k in range(4)]

    def props(self):
        out = []
        if self.pos:
            out += [KF_POS_X, KF_POS_Y]
        if self.rot:
            out.append(KF_ROT)
        if self.scl:
            out.append(KF_SCALE_X)
            if not self.uniform:  # «Единый масштаб» — CapCut берёт масштаб только из ScaleX
                out.append(KF_SCALE_Y)
        return out

    def _f(self, i, t):
        return self.n[i].fractal(t / US * self.freq, self.oct)

    def apply(self, prop, t, base):
        if prop == KF_POS_X:
            return base + self.amp_x * self._f(0, t)
        if prop == KF_POS_Y:
            return base + self.amp_y * self._f(1, t)
        if prop == KF_ROT:
            return base + self.rot * self._f(2, t)
        return base * (1 + self.scl / 100 * self._f(3, t))

    def remove(self, prop, t, value):
        if prop not in self.props():
            return value
        if prop == KF_POS_X:
            return value - self.amp_x * self._f(0, t)
        if prop == KF_POS_Y:
            return value - self.amp_y * self._f(1, t)
        if prop == KF_ROT:
            return value - self.rot * self._f(2, t)
        k = 1 + self.scl / 100 * self._f(3, t)
        return value / k if k else value


def _canvas(draft):
    c = (draft or {}).get("canvas_config") or {}
    return float(c.get("width") or 1920), float(c.get("height") or 1080)


def wiggle_segment(seg, params, canvas_w, canvas_h, seed, base_lists):
    """Строит рысканье поверх base_lists (твоих ключей) и записывает в сегмент.

    Твои ключи остаются в списке под своими id и в свои моменты (их значение —
    твоё плюс смещение), рысканье добавляется между ними. Возвращает запись для
    состояния или None."""
    dur = int(seg.get("target_timerange", {}).get("duration") or 0)
    if dur <= 0:
        return None
    clip = seg.get("clip") or {}
    tr = clip.get("transform") or {}
    sc = clip.get("scale") or {}
    const = {KF_POS_X: float(tr.get("x", 0.0)), KF_POS_Y: float(tr.get("y", 0.0)),
             KF_ROT: float(clip.get("rotation", 0.0)),
             KF_SCALE_X: float(sc.get("x", 1.0)), KF_SCALE_Y: float(sc.get("y", 1.0))}
    frames = {p: _frames(kl) for p, kl in base_lists.items()}
    uniform = bool((seg.get("uniform_scale") or {}).get("on"))
    if KF_SCALE_X in frames and KF_SCALE_Y not in frames:
        frames[KF_SCALE_Y] = frames[KF_SCALE_X]  # масштаб с ключами только по X — он общий

    def base(p, t):
        v = interp(frames.get(p), t)
        return const[p] if v is None else v

    noise = WiggleNoise(params, seed, canvas_w, canvas_h, uniform)
    kps = max(1.0, float(params.get("keys_per_second") or 12))
    step = US / kps
    grid = {int(i * step) for i in range(int(dur / step) + 1)} | {dur}
    user_times = set()
    for fr in frames.values():
        user_times |= {f[0] for f in fr if 0 <= f[0] <= dur}
    # слишком близкие к твоим ключам точки сетки убираем, чтобы не было «двойных» ключей
    grid = {g for g in grid if all(abs(g - u) >= step * 0.35 for u in user_times)}
    times = sorted(grid | user_times)

    lists, baked_vals = {}, {}
    for prop in noise.props():
        own = {}
        if prop in base_lists:
            for k in base_lists[prop].get("keyframe_list") or []:
                own.setdefault(int(k.get("time_offset", 0)), k.get("id"))
        keys, vals = [], {}
        for t in times:
            kf = make_kf(t, noise.apply(prop, t, base(prop, t)))
            if t in own:
                kf["id"] = own[t]  # твой ключ остаётся твоим
            keys.append(kf)
            vals[kf["id"]] = kf["values"][0]
        list_id = (base_lists.get(prop) or {}).get("id") or uuid.uuid4().hex.upper()
        lists[prop] = {"id": list_id, "keyframe_list": keys, "material_id": "", "property_type": prop}
        baked_vals[prop] = vals
    for p, kl in base_lists.items():  # свойства без рысканья — твои ключи как есть
        lists.setdefault(p, copy.deepcopy(kl))
    set_lists(seg, lists)
    return {
        "originals": copy.deepcopy(base_lists),
        "baked": fingerprint(get_lists(seg)),
        "baked_vals": baked_vals,
        "params": {**{k: float(params[k]) for k in ("position_px", "rotation_deg", "scale_pct",
                                                    "frequency", "octaves", "keys_per_second")},
                   "seed": int(seed), "canvas_w": canvas_w, "canvas_h": canvas_h, "uniform": uniform},
    }


# --------------------------------------------- рысканье с учётом состояния ----
def segment_status(seg, state):
    """'none' — рысканья нет; 'wiggled' — наше и нетронутое;
    'lost' — CapCut сохранил поверх свою версию без рысканья (ключи снова как до него);
    'edited' — после рысканья ключи правили в CapCut."""
    st = state.get(str(seg.get("id")))
    if not st:
        return "none"
    cur = fingerprint(get_lists(seg))
    if cur == st.get("baked"):
        return "wiggled"
    if cur == fingerprint(st.get("originals") or {}):
        return "lost"
    return "edited"


def recover_user_lists(seg, st):
    """Твои ключи с учётом правок, сделанных в CapCut после рысканья.

    Твой ключ узнаётся по своему id; новый ключ — по незнакомому id; изменённый
    ключ рысканья тоже считается твоей правкой. Из значений вычитается шум
    (он детерминированный), так что получаются твои настоящие значения.
    None — если запись старая и разобрать правки нельзя."""
    P = st.get("params")
    baked = st.get("baked_vals")
    if not P or baked is None:
        return None
    noise = WiggleNoise(P, P["seed"], P.get("canvas_w", 1920), P.get("canvas_h", 1080), P.get("uniform"))
    orig = st.get("originals") or {}
    cur = get_lists(seg)
    out = {}
    for prop in list(orig) + [p for p in cur if p not in orig]:
        cur_list = cur.get(prop)
        if cur_list is None:
            if prop in baked:
                continue  # ты удалил все ключи этого свойства
            out[prop] = copy.deepcopy(orig[prop])
            continue
        orig_keys = {k.get("id"): k for k in (orig.get(prop) or {}).get("keyframe_list") or []}
        bvals = baked.get(prop, {})
        keys = []
        for k in cur_list.get("keyframe_list") or []:
            kid = k.get("id")
            t = int(k.get("time_offset", 0))
            v = float((k.get("values") or [0])[0])
            unchanged = kid in bvals and abs(v - bvals[kid]) < 1e-9
            if kid in orig_keys:
                nk = copy.deepcopy(orig_keys[kid])
                nk["time_offset"] = t
                if not unchanged:
                    nk["values"] = [noise.remove(prop, t, v)]
                keys.append(nk)
            elif unchanged:
                continue  # ключ рысканья, ты его не трогал
            else:
                nk = copy.deepcopy(k)
                nk["values"] = [noise.remove(prop, t, v)]
                keys.append(nk)
        if keys:
            keys.sort(key=lambda k: int(k.get("time_offset", 0)))
            base = copy.deepcopy(orig.get(prop) or cur_list)
            base["keyframe_list"] = keys
            out[prop] = base
    return out


def base_lists_for(seg, state, on_edited="restore"):
    """Твои ключи, от которых строится рысканье, — с учётом всего, что было."""
    status = segment_status(seg, state)
    st = state.get(str(seg.get("id")))
    if status in ("wiggled", "lost"):
        return copy.deepcopy(st.get("originals") or {})
    if status == "edited":
        rec = recover_user_lists(seg, st)
        if rec is not None:
            return rec
        if on_edited == "restore":
            return copy.deepcopy(st.get("originals") or {})
    return copy.deepcopy(get_lists(seg))


def apply_to_segment(seg, params, canvas_w, canvas_h, seed, prev_state, on_edited="restore"):
    """Накладывает рысканье. Возвращает новую запись состояния (или None)."""
    base = base_lists_for(seg, prev_state, on_edited)
    return wiggle_segment(seg, params, canvas_w, canvas_h, seed, base)


def remove_from_segment(seg, prev_state, on_edited="restore"):
    """Убирает рысканье и возвращает твои ключи — вместе с правками, сделанными
    в CapCut после рысканья. Для элементов без записи удаляет ключи позиции/поворота/масштаба."""
    st = prev_state.get(str(seg.get("id")))
    if st is None:
        set_lists(seg, {})
        return
    status = segment_status(seg, prev_state)
    if status == "lost":
        return
    if status == "edited" and recover_user_lists(seg, st) is None and on_edited == "current":
        return
    set_lists(seg, base_lists_for(seg, prev_state, on_edited))


def needs_answer_on_edit(seg, state):
    """Правки после рысканья, которые нельзя разобрать автоматически (старая запись)."""
    st = state.get(str(seg.get("id")))
    return bool(st) and segment_status(seg, state) == "edited" and recover_user_lists(seg, st) is None


# --------------------------------------------------------------- команды ----
def iter_targets(draft, cfg):
    texts = {m.get("id"): text_of_material(m)
             for m in (draft.get("materials") or {}).get("texts", [])}
    targets = {k for k, v in cfg["targets"].items() if v}
    needle = str(cfg.get("match_text") or "").lower()
    for track in draft.get("tracks") or []:
        ttype = track.get("type")
        if ttype not in targets:
            continue
        for seg in track.get("segments") or []:
            label = ttype
            if ttype == "text":
                label = texts.get(seg.get("material_id"), "")
                if needle and needle not in label.lower():
                    continue
            yield seg, label.replace("\n", " ")[:40] or ttype


def cmd_list(cfg):
    drafts = find_drafts_dir(cfg)
    print(f"Проекты в {drafts} (новые сверху):")
    for d in project_dirs(drafts):
        files = [f for f in DRAFT_FILES if (d / f).exists()]
        status = "ok"
        try:
            if all(read_draft(d / f) is None for f in files):
                status = "ЗАШИФРОВАН — не прочитать"
        except Exception as e:
            status = f"не читается: {e}"
        print(f"  • {d.name}   [{status}]")


def cmd_apply(cfg):
    project = resolve_project(cfg)
    drafts = {}
    encrypted = False
    for fname in draft_paths(project):
        p = project / fname
        if p.exists():
            d = read_draft(p)
            if d is None:
                encrypted = True
            elif isinstance(d.get("tracks"), list):
                drafts[fname] = d
    if not drafts:
        sys.exit("[!] Файл проекта зашифрован новой версией CapCut — изменить нельзя."
                 if encrypted else "[!] В проекте не нашлось файла с дорожками.")

    prev = load_state(project)
    new_state = dict(prev)
    seed0 = int(cfg.get("seed") or 0)
    done = []
    names = list(drafts)
    main = drafts[names[0]]
    canvas = main.get("canvas_config") or {}
    w, h = float(canvas.get("width") or 1920), float(canvas.get("height") or 1080)
    changed = {}
    for seg, label in iter_targets(main, cfg):
        if segment_status(seg, prev) == "edited":
            print(f"   ! «{label}»: ключи меняли после рысканья — беру их как основу")
        entry = apply_to_segment(seg, cfg, w, h,
                                 segment_seed(seed0, seg.get("id"), cfg.get("same_motion")),
                                 prev, on_edited="current")
        if entry:
            new_state[str(seg.get("id"))] = entry
            changed[seg.get("id")] = seg
            done.append(label)
    for fname in names[1:]:  # копии таймлайна — те же ключи
        for track in drafts[fname].get("tracks") or []:
            for seg in track.get("segments") or []:
                if seg.get("id") in changed:
                    seg["common_keyframes"] = copy.deepcopy(changed[seg.get("id")].get("common_keyframes") or [])
    backup_project(project, drafts.keys())
    for fname, d in drafts.items():
        write_draft(project / fname, d)
    save_state(project, new_state)
    print(f"Рысканье добавлено к {len(done)} элементам:")
    for label in done:
        print(f"   – {label}")
    print("Открой проект в CapCut. Откатить: python capcut_wiggle.py --undo")


def cmd_undo(cfg):
    project = resolve_project(cfg)
    if undo_project(project):
        print("Проект возвращён к состоянию до последнего изменения.")
    else:
        sys.exit("[!] Резервных копий не нашлось.")


def main():
    ap = argparse.ArgumentParser(description="Процедурное рысканье для проектов CapCut")
    ap.add_argument("--list", action="store_true", help="показать проекты CapCut")
    ap.add_argument("--undo", action="store_true", help="вернуть проект из последней копии")
    args = ap.parse_args()
    cfg = load_config()
    if args.list:
        cmd_list(cfg)
    elif args.undo:
        cmd_undo(cfg)
    else:
        cmd_apply(cfg)


if __name__ == "__main__":
    main()
