"use strict";
/* Растяжение по углам: ручки на сцене, ключи с изингом, фон проекта, пресеты, рендер. */

/* ======================================================================= */
const CP = {
  active: false,
  info: null,      // ответ corner_info
  keys: [],
  t: 0,            // мкс внутри клипа
  playing: true,
  clock0: 0,
  t0: 0,
  media: null,
  bgEls: [],
  drag: null,
  loadingId: null,
  rendering: false,

  /* ---------- режим ---------- */
  /* mode: "wiggle" | "corner" | "mods" */
  /* mode: "wiggle" | "corner" | "mods" | "thumb" */
  setMode(mode) {
    const on = mode === "corner" || mode === "mods", was = this.active;
    this.active = on; this.mode = mode;
    for (const [id, m] of [["modeWiggle", "wiggle"], ["modeCorner", "corner"], ["modeMods", "mods"], ["modeThumb", "thumb"]])
      $(id).setAttribute("aria-selected", String(mode === m));
    $("wigglePane").hidden = mode !== "wiggle";
    $("cornerPane").hidden = !on;
    $("thumbPane").hidden = mode !== "thumb";
    $("cornerBody").hidden = mode !== "corner";
    $("modsBody").hidden = mode !== "mods";
    $("inspHead").textContent = { wiggle: "Рысканье", corner: "Растяжение по углам", mods: "Модификаторы", thumb: "Превью ролика" }[mode];
    $("cpScrub").hidden = !on;
    $("subject").hidden = mode !== "wiggle";
    // у SVG нет свойства hidden — только атрибут
    for (const id of ["cpBg", "cpAsset"]) $(id).toggleAttribute("hidden", !on);
    $("cpHandles").toggleAttribute("hidden", mode !== "corner");
    if (mode === "thumb") TH.enter(); else TH.leave();
    if (on && !was) { this.onSelection(); this.prefetchFfmpeg(); }
    if (!on) this.unload();
    if (mode !== "thumb") updateSelectionUI();
  },

  frameRate() { return this.info ? this.info.fps : 30; },
  frameUs() { return 1e6 / this.frameRate(); },

  /* ---------- выбор клипа ---------- */
  async onSelection() {
    if (!this.active) return;
    const first = selectedElements()[0];
    const msg = this.message.bind(this);
    if (!first) { this.unload(); return msg("Выбери на таймлайне видео или картинку."); }
    if (first.type === "text") { this.unload(); return msg("Растягивать можно видео и картинки. Текст сначала экспортируй как картинку."); }
    if (this.info && this.info.id === first.id) return;
    this.loadingId = first.id;
    const info = await api("corner_info", { id: first.id });
    if (this.loadingId !== first.id) return;
    if (!info.ok) { this.unload(); return msg(info.error || "Не получилось открыть клип."); }
    const draft = await api("corner_draft", { id: first.id });
    this.load(info, draft);
  },

  message(text) {
    let m = $("cpMsg");
    if (!m) { m = document.createElement("p"); m.id = "cpMsg"; m.className = "cp-msg"; $("stage").append(m); }
    m.textContent = text; m.hidden = !text;
    $("cpRender").disabled = true; $("cpRestore").disabled = true;
  },

  unload() {
    this.info = null; this.keys = [];
    $("cpAsset").innerHTML = ""; $("cpBg").innerHTML = ""; $("cpHandles").innerHTML = "";
    disposeLayer(this.L);
    this.media = null; this.L = null; this.bgEls = [];
    this.mods = normMods(null); this.syncModsUI && this.syncModsUI();
    $("modsWiggle").hidden = true;
    $("cpScrub").querySelectorAll(".cp-key").forEach((n) => n.remove());
    const m = $("cpMsg"); if (m) m.hidden = true;
  },

  load(info, draft) {
    draft = Array.isArray(draft) ? { keys: draft } : draft || {};
    const draftKeys = draft.keys;
    this.unload();
    this.info = info;
    this.mods = normMods(draft.mods || info.mods);
    this.s0 = Math.max(1e-6, Math.hypot(info.quad[1][0] - info.quad[0][0], info.quad[1][1] - info.quad[0][1]) / info.asset_w);
    const m = $("cpMsg"); if (m) m.hidden = true;
    const base = info.keys && info.keys.length ? info.keys : [{ t: 0, pts: info.quad, ease: "smooth" }];
    this.keys = (draftKeys && draftKeys.length ? draftKeys : base).map((k) => ({
      t: k.t, pts: clonePts(k.pts), ease: k.ease || "smooth", r: +k.r || 0,
      ...(k.flat && k.made ? { flat: clonePts(k.flat), made: clonePts(k.made) } : {}),
    }));
    this.sortKeys();
    if (!info.exists) toast("Исходный файл клипа не найден на диске — превью будет пустым.", { kind: "error" });

    // ассет: рамка (эффекты в кадре) > перспектива > кожа (скругление, эффекты на плоскости) > медиа
    this.L = makeLayerDom(info.url, info.type, info.asset_w, info.asset_h);
    this.L.s0 = this.s0;
    if (info.type === "video") this.L.media.playbackRate = info.speed || 1;
    $("cpAsset").append(this.L.box);
    const el = this.L.media;
    this.media = el; this._rad = null; this.L._modsK = null;
    if (info.wiggle && info.wiggle.seed != null) ensureTables([info.wiggle.seed]);
    const w = info.wiggle && info.wiggle.params;
    $("modsWiggle").hidden = !w;
    if (w) $("modsWiggle").textContent = `У клипа есть рысканье: сдвиг ${w.position_px} px, поворот ${w.rotation_deg}°, масштаб ${w.scale_pct}%. ` +
      "Оно запечётся в рендер и будет качать клип вокруг его центра вместе с тенью и отражением.";
    this.syncModsUI();

    // фон: остальные видео проекта
    for (const b of info.bg) {
      const e = document.createElement(b.type === "video" ? "video" : "img");
      e.src = b.url; e.style.width = b.w + "px"; e.style.height = b.h + "px";
      if (b.type === "video") { e.muted = true; e.playsInline = true; e.preload = "metadata"; e.playbackRate = b.speed || 1; }
      e.dataset.bg = "1";
      $("cpBg").append(e);
      this.bgEls.push({ el: e, b });
    }
    $("cpBg").toggleAttribute("hidden", !$("cpBgToggle").checked);

    this.t = 0; this.clock0 = performance.now(); this.t0 = 0;
    this.seekMedia(0, true);
    if (this.playing && el.play) el.play().catch(() => {});
    $("cpRender").disabled = !info.exists;
    $("cpRestore").disabled = !info.cornered;
    this.drawHandles();
    this.drawScrub();
    this.updateKeyPanel();
    this.applyMods();
  },

  sortKeys() { this.keys.sort((a, b) => a.t - b.t); },

  /* ---------- время ---------- */
  seekMedia(t, hard) {
    const i = this.info; if (!i) return;
    if (this.media && i.type === "video") {
      const want = i.src_start / 1e6 + (t / 1e6) * i.speed;
      if (hard || Math.abs(this.media.currentTime - want) > 0.25) this.media.currentTime = want;
    }
    const projT = i.start + t;
    for (const { el, b } of this.bgEls) {
      const on = projT >= b.start && projT < b.start + b.dur;
      el.style.visibility = on ? "visible" : "hidden";
      if (!on || b.type !== "video") continue;
      const want = b.src_start / 1e6 + ((projT - b.start) / 1e6) * b.speed;
      if (hard || Math.abs(el.currentTime - want) > 0.25) el.currentTime = want;
      if (this.playing && el.paused) el.play().catch(() => {});
      if (!this.playing && !el.paused) el.pause();
    }
  },

  setTime(t, { pause = true } = {}) {
    const i = this.info; if (!i) return;
    this.t = Math.max(0, Math.min(i.dur, t));
    if (pause) this.pause();
    this.t0 = this.t; this.clock0 = performance.now();
    this.seekMedia(this.t, true);
  },

  pause() {
    if (!this.playing) return;
    this.playing = false;
    if (this.media && this.media.pause) this.media.pause();
    this.bgEls.forEach(({ el }) => el.pause && el.pause());
    $("playBtn").classList.add("paused");
  },
  play() {
    if (this.playing) return;
    this.playing = true;
    this.t0 = this.t; this.clock0 = performance.now();
    this.seekMedia(this.t, true);
    if (this.media && this.media.play) this.media.play().catch(() => {});
    $("playBtn").classList.remove("paused");
  },
  togglePlay() { this.playing ? this.pause() : this.play(); },

  frame(now) {
    const i = this.info;
    if (!i) return;
    if (this.playing) {
      const dur = Math.max(1, i.dur);
      let t = this.t0 + (now - this.clock0) * 1000;
      if (t >= dur) { this.t0 = 0; this.clock0 = now; t = 0; this.seekMedia(0, true); }
      this.t = t;
      this.seekMedia(t, false);
    }
    this.render();
  },

  /* ---------- отрисовка ---------- */
  k() { return +$("frame").dataset.k || 0.4; },

  /* рысканье в превью — только пока играет, на паузе углы стоят ровно по ключам */
  wiggleAt(t) {
    const w = this.info && this.info.wiggle;
    if (!w || !this.playing) return null;
    const tb = S.tables[w.seed]; if (!tb) return null;
    const P = w.params, x = (t / 1e6) * P.frequency, o = Math.round(P.octaves);
    return [P.position_px * fractal(tb[0], x, o), -P.position_px * fractal(tb[1], x, o),
      P.rotation_deg * fractal(tb[2], x, o), 1 + (P.scale_pct / 100) * fractal(tb[3], x, o)];
  },

  /* движение клипа по ключам CapCut (позиция, поворот, масштаб) в момент t */
  motionAt(t) {
    const m = this.info && this.info.motion;
    if (!m || !m.length) return null;
    return affine2(this.info.quad, m[Math.max(0, Math.min(m.length - 1, Math.round(t / this.frameUs())))]);
  },

  render() {
    const i = this.info; if (!i) return;
    const k = this.k();
    let quad = cornersAt(this.keys, this.t);
    const mo = this.motionAt(this.t);
    if (mo) quad = applyAff(mo, quad);
    const wg = this.wiggleAt(this.t);
    if (wg) quad = wiggleQuad(quad, wg);
    const disp = quad.map(([x, y]) => [x * k, y * k]);
    const L = this.L;
    if (L && k !== L._modsK) this.applyMods();
    if (L) {
      L.unit.style.transform = matrix3d(i.asset_w, i.asset_h, disp);
      // скругление в пикселях ассета — до перспективы, ровно как в рендере
      const rad = Math.round(radiusAt(this.keys, this.t) * 4) / 4;
      if (rad !== this._rad) {
        this._rad = rad;
        L.skin.style.borderRadius = L.reflSkin.style.borderRadius = (rad / 100) * Math.min(i.asset_w, i.asset_h) + "px";
        if (!this._radDrag) this.radiusSlider.set(rad, true);
      }
      if (L.shadeFx) renderLayerShade(L, disp);
      drawLayerRefl(L);
    }
    for (const { el, b } of this.bgEls) el.style.transform = matrix3d(b.w, b.h, b.quad.map(([x, y]) => [x * k, y * k]));
    this.placeHandles(disp);
    $("cpScrubHead").style.left = (this.t / Math.max(1, i.dur)) * 100 + "%";
    // текст и размеры трогаем только когда они меняются — без лишних перерасчётов разметки
    const cap = `${fmtTime(this.t, true)} / ${fmtTime(i.dur, true)}`;
    if (cap !== this._cap) { this._cap = cap; $("stageCaption").textContent = cap; }
    if (this._title !== i.id) { this._title = i.id; const f = selectedElements()[0]; $("clipTitle").textContent = f ? f.label : ""; }
    if (S.project) {
      const D = Math.max(S.project.duration, 1e6), usable = Math.max(100, (this._tlw || 0) - 24);
      const ph = $("playhead");
      ph.hidden = false;
      ph.style.transform = `translateX(${((i.start + this.t) / D) * usable + 8}px)`;
      ph.style.left = "0";
    }
    this.updateKeyPanel(true);
  },

  /* ---------- модификаторы в превью ---------- */
  applyMods() {
    if (!this.info || !this.L) return;
    applyFx(this.L, this.mods.stack, this.k());
  },

  modsChanged() {
    this.applyMods();
    this.saveSoon();
  },

  saveSoon() {
    clearTimeout(this._saveT);
    const id = this.info && this.info.id, keys = this.keys, mods = this.mods;
    this._saveT = setTimeout(() => id && api("corner_save", { id, keys, mods }), 500);
  },

  syncModsUI() { if (this.fxUI) this.fxUI.sync(); },

  drawHandles() {
    const svg = $("cpHandles");
    const ns = "http://www.w3.org/2000/svg";
    svg.innerHTML = "";
    const poly = document.createElementNS(ns, "polygon"); poly.setAttribute("class", "quad"); poly.dataset.part = "body";
    const d1 = document.createElementNS(ns, "line"); d1.setAttribute("class", "diag");
    const d2 = document.createElementNS(ns, "line"); d2.setAttribute("class", "diag");
    svg.append(poly, d1, d2);
    const labels = ["ЛВ", "ПВ", "ЛН", "ПН"];
    for (let c = 0; c < 4; c++) {
      const h = document.createElementNS(ns, "circle");
      h.setAttribute("r", 7); h.setAttribute("class", "h"); h.dataset.part = String(c);
      const tl = document.createElementNS(ns, "text"); tl.setAttribute("class", "hl"); tl.textContent = labels[c];
      svg.append(h, tl);
    }
    const hs = [...svg.querySelectorAll(".h")], ls = [...svg.querySelectorAll(".hl")];
    this.handleEls = { poly, d1, d2, hs, ls, rot: makeRotHandle(svg) };
  },

  placeHandles(d) {
    const H = this.handleEls; if (!H) return;
    H.poly.setAttribute("points", [d[0], d[1], d[3], d[2]].map((p) => p.join(",")).join(" "));
    H.d1.setAttribute("x1", d[0][0]); H.d1.setAttribute("y1", d[0][1]); H.d1.setAttribute("x2", d[3][0]); H.d1.setAttribute("y2", d[3][1]);
    H.d2.setAttribute("x1", d[1][0]); H.d2.setAttribute("y1", d[1][1]); H.d2.setAttribute("x2", d[2][0]); H.d2.setAttribute("y2", d[2][1]);
    const off = [[-14, -10], [8, -10], [-14, 18], [8, 18]];
    H.hs.forEach((h, c) => { h.setAttribute("cx", d[c][0]); h.setAttribute("cy", d[c][1]); });
    H.ls.forEach((l, c) => { l.setAttribute("x", d[c][0] + off[c][0]); l.setAttribute("y", d[c][1] + off[c][1]); });
    this._rotG = placeRotHandle(H.rot, d, this.drag && this.drag.part === "rot" ? this.drag.angle : null);
  },

  drawScrub() {
    const sc = $("cpScrub"), i = this.info;
    sc.querySelectorAll(".cp-key").forEach((n) => n.remove());
    if (!i) return;
    const cur = this.currentKeyIndex();
    this.keys.forEach((key, idx) => {
      const b = document.createElement("button");
      b.className = "cp-key" + (idx === cur.at ? " sel" : "");
      b.style.left = (key.t / Math.max(1, i.dur)) * 100 + "%";
      b.title = `Ключ ${fmtTime(key.t, true)} · ${EASE_NAMES[key.ease] || ""}`;
      b.dataset.idx = idx;
      sc.append(b);
    });
  },

  /* ключ в текущий момент (at) или ближайший слева (prev) */
  currentKeyIndex() {
    const tol = this.frameUs() / 2;
    let at = -1, prev = -1;
    this.keys.forEach((k, i) => { if (Math.abs(k.t - this.t) <= tol) at = i; if (k.t <= this.t + tol) prev = i; });
    return { at, prev };
  },

  updateKeyPanel(light) {
    const { at, prev } = this.currentKeyIndex();
    const sig = `${at}|${prev}|${this.keys.length}`;
    if (light && sig === this._sig) return;
    this._sig = sig;
    const info = $("cpKeyInfo");
    if (!this.info) { info.textContent = "—"; return; }
    const idx = at >= 0 ? at : prev;
    info.textContent = at >= 0 ? `Ключ ${at + 1} из ${this.keys.length} · ${fmtTime(this.keys[at].t, true)}`
      : `Между ключами · всего ${this.keys.length}`;
    $("cpEase").value = idx >= 0 ? this.keys[idx].ease : "smooth";
    $("cpEase").disabled = idx < 0 || idx === this.keys.length - 1 && this.keys.length > 1 && at === this.keys.length - 1;
    $("cpDelKey").disabled = at < 0 || this.keys.length <= 1;
    this.drawScrub();
  },

  /* ---------- правка ---------- */
  keyHere() {
    // ключ в текущий момент: существующий или новый (с текущими углами)
    const { at } = this.currentKeyIndex();
    if (at >= 0) return this.keys[at];
    const t = Math.round(this.t / this.frameUs()) * this.frameUs();
    const k = { t: Math.round(t), pts: cornersAt(this.keys, this.t), r: radiusAt(this.keys, this.t),
      ease: this.keys[this.currentKeyIndex().prev]?.ease || "smooth" };
    this.keys.push(k); this.sortKeys();
    this.t = k.t;
    return k;
  },

  changed() {
    this.drawScrub(); this._sig = null; this.updateKeyPanel();
    this.saveSoon();
  },

  pointerDown(ev) {
    const part = ev.target.dataset && ev.target.dataset.part;
    if (part == null || !this.info) return;
    ev.preventDefault();
    this.pause();
    const key = this.keyHere();
    const rect = $("frame").getBoundingClientRect();
    const k = this.k();
    // если клип движется ключами CapCut, сдвиг мыши переводим в его систему координат
    const mo = this.motionAt(key.t);
    let inv = [1, 0, 0, 1];
    if (mo) { const det = mo[0] * mo[4] - mo[1] * mo[3] || 1; inv = [mo[4] / det, -mo[1] / det, -mo[3] / det, mo[0] / det]; }
    this.drag = { part, key, x0: ev.clientX, y0: ev.clientY, start: key.pts.map((p) => p.slice()), rect, k, inv };
    if (part === "rot" && this._rotG) Object.assign(this.drag, { cx: rect.left + this._rotG.cx, cy: rect.top + this._rotG.cy, angle: 0 });
    ev.target.classList && ev.target.classList.add("active");
    $("cpHandles").setPointerCapture(ev.pointerId);
    this.changed();
  },
  pointerMove(ev) {
    const d = this.drag; if (!d) return;
    if (d.part === "rot") {   // поворот всего клипа вокруг центра
      d.angle = rotDelta(d.cx, d.cy, d.x0, d.y0, ev.clientX, ev.clientY, ev.shiftKey);
      d.key.pts = Q.rotate(d.start, d.angle);
      return;
    }
    const sx = (ev.clientX - d.x0) / d.k, sy = (ev.clientY - d.y0) / d.k;
    const dx = d.inv[0] * sx + d.inv[1] * sy, dy = d.inv[2] * sx + d.inv[3] * sy;
    if (d.part === "body") d.key.pts = d.start.map(([x, y]) => [x + dx, y + dy]);
    else { const c = +d.part; d.key.pts[c] = [d.start[c][0] + dx, d.start[c][1] + dy]; }
  },
  pointerUp() {
    if (!this.drag) return;
    $("cpHandles").querySelectorAll(".active").forEach((n) => n.classList.remove("active"));
    this.drag = null;
    this.changed();
  },

  scrubAt(ev) {
    const r = $("cpScrub").getBoundingClientRect();
    const p = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width));
    this.setTime(p * this.info.dur);
  },

  /* ---------- пресеты ---------- */
  buildPresets() {
    const box = $("presets");
    const ns = "http://www.w3.org/2000/svg";
    const base = [[3, 3], [31, 3], [3, 19], [31, 19]];
    for (const p of PRESETS) {
      const b = document.createElement("button");
      b.className = "preset";
      b.title = p.anim ? `${p.name}: анимация ${(p.span / 1e6).toFixed(1)} с от курсора` : `${p.name}: на ключ под курсором`;
      const svg = document.createElementNS(ns, "svg"); svg.setAttribute("viewBox", "0 0 34 22");
      const ks = p.make(base, base);
      const poly = (q, cls) => { const e = document.createElementNS(ns, "polygon"); e.setAttribute("class", cls); e.setAttribute("points", [q[0], q[1], q[3], q[2]].map((x) => x.join(",")).join(" ")); return e; };
      if (p.anim) svg.append(poly(ks[0], "from"));
      svg.append(poly(ks[ks.length - 1], "to"));
      const span = document.createElement("span"); span.textContent = p.name;
      b.append(svg, span);
      b.onclick = () => this.applyPreset(p);
      box.append(b);
    }
  },
  /* та же рамка, что у клипа, но с центром и размером текущих углов, без наклонов */
  flatOf(cur) { return flatOfQuad(cur, this.info.quad); },
  applyPreset(p) {
    if (!this.info) return toast("Сначала выбери видео или картинку на таймлайне.", { kind: "error" });
    this.pause();
    const fu = this.frameUs();
    const t = Math.round(Math.round(this.t / fu) * fu);
    const cur = cornersAt(this.keys, t), r = radiusAt(this.keys, t);
    const at = this.currentKeyIndex().at, here = at >= 0 ? this.keys[at] : null;
    // повторный пресет на том же ключе строится от той же плоской рамки — наклоны не копятся
    const flat = here && here.flat && samePts(here.pts, here.made) ? clonePts(here.flat) : this.flatOf(cur);
    const shapes = p.make(cur, flat);
    if (!p.anim) {
      const k = this.keyHere();
      k.pts = clonePts(shapes[0]); k.flat = flat; k.made = clonePts(shapes[0]);
      this.changed();
      this.setTime(k.t);
      return toast(`«${p.name}» на ключе ${fmtTime(k.t, true)}`);
    }
    const t1 = Math.min(this.info.dur, t + p.span);
    if (t1 - t < fu * 3) return toast("До конца клипа слишком мало места — поставь курсор левее.", { kind: "error" });
    const tol = fu / 2;
    const endEase = (this.keys.find((k) => Math.abs(k.t - t1) <= tol) || {}).ease || "smooth";
    this.keys = this.keys.filter((k) => k.t < t - tol || k.t > t1 + tol);   // ключи внутри отрезка заменяются
    this.keys.push({ t, pts: clonePts(shapes[0]), ease: p.ease, r }, { t: Math.round(t1), pts: clonePts(shapes[1]), ease: endEase, r });
    this.sortKeys();
    this.changed();
    this.setTime(t, { pause: false }); this.play();
    toast(`«${p.name}»: ${fmtTime(t, true)} → ${fmtTime(t1, true)}`);
  },

  /* ---------- скругление ---------- */
  buildRadius() {
    const sl = makeSlider($("cpRadius"), (v) => {
      if (!this.info) return;
      this.pause();
      const k = this.keyHere(); k.r = v;
      this._rad = null; this.changed();
    });
    sl.range.addEventListener("pointerdown", () => (this._radDrag = true));
    sl.range.addEventListener("pointerup", () => (this._radDrag = false));
    this.radiusSlider = { set: (v) => sl.show(v) };
    sl.show(0);
  },

  /* ffmpeg качается в фоне, как только открыта вкладка «Углы» */
  async prefetchFfmpeg() {
    if (this._ffPoll) return;
    const line = $("cpFfmpeg");
    let st = await api("ffmpeg");
    if (st.found) { line.hidden = true; return; }
    if (!st.download.running && !st.download.done) { await api("ffmpeg_install"); st = await api("ffmpeg"); }
    this._ffPoll = true;
    line.hidden = false;
    while (true) {
      const d = st.download;
      if (st.found && d.done) { line.textContent = "ffmpeg скачан, можно рендерить."; setTimeout(() => (line.hidden = true), 4000); break; }
      if (d.error) { line.textContent = d.error + " Нажми «Рендер и замена», чтобы попробовать ещё раз."; break; }
      line.textContent = d.total_mb
        ? `Скачиваю ffmpeg для рендера: ${Math.round(d.progress * 100)}% из ${d.total_mb.toFixed(0)} МБ`
        : "Скачиваю ffmpeg для рендера…";
      await new Promise((r) => setTimeout(r, 700));
      st = await api("ffmpeg");
    }
    this._ffPoll = false;
  },

  /* ---------- рендер ---------- */
  async ensureFfmpeg() {
    const st = await api("ffmpeg");
    if (st.found) return true;
    if (!st.download.running) {
      const p = openSheet({
        title: "Для рендера нужен ffmpeg",
        text: "Это бесплатный видеокодировщик. Скачаю только ffmpeg.exe в папку приложения, один раз. В систему ничего не ставится.",
        buttons: [{ label: "Скачать", value: "go", primary: true }, { label: "Отмена", value: "cancel" }],
        inline: true,
      });
      if (await p !== "go") return false;
      await api("ffmpeg_install");
    }
    const live = openSheet({ title: "Скачиваю ffmpeg", live: "Начинаю…", buttons: [{ label: "Свернуть", value: "hide" }] });
    let ok = false;
    while (true) {
      await new Promise((r) => setTimeout(r, 500));
      const s = await api("ffmpeg");
      if (s.found && s.download.done) { ok = true; break; }
      if (s.download.error) { closeSheet("x"); toast(s.download.error, { kind: "error" }); return false; }
      $("sheetLiveText").textContent = s.download.total_mb
        ? `${Math.round(s.download.progress * 100)}% из ${s.download.total_mb.toFixed(0)} МБ`
        : "Подключаюсь…";
      if (!$("sheet").open) break;
    }
    closeSheet("done");
    await live;
    return ok || (await api("ffmpeg")).found;
  },

  async renderAndReplace() {
    if (!this.info || this.rendering) return;
    if (!(await this.ensureFfmpeg())) return;
    this.rendering = true;
    const btn = $("cpRender"), bar = $("cpProgress"), fill = $("cpProgressFill");
    btn.disabled = true; btn.textContent = "Рендер 0%"; bar.hidden = false; fill.style.width = "0";
    try {
      const r = await api("render", { id: this.info.id, keys: this.keys, mods: this.mods, codec: $("cpCodec").value });
      if (!r.ok) { toast(r.error || "Не получилось начать рендер.", { kind: "error" }); return; }
      let st;
      while (true) {
        await new Promise((res) => setTimeout(res, 400));
        st = await api("render_status", { job: r.job });
        const pct = Math.round((st.progress || 0) * 100);
        btn.textContent = `Рендер ${pct}%`; fill.style.width = pct + "%";
        if (!st.running) break;
      }
      if (!st.done) { toast("Рендер не удался: " + (st.error || "неизвестная ошибка"), { kind: "error" }); return; }
      btn.textContent = "Заменяю клип…";
      const res = await gated("corner_apply", { job: r.job });
      if (!res) { toast("Рендер готов, но клип не заменён. Нажми «Рендер и замена» ещё раз, когда проект будет закрыт.", { kind: "error" }); return; }
      if (!res.ok) { toast(res.error || "Не получилось заменить клип.", { kind: "error" }); return; }
      S.project = res.project; keepSelection(); renderTimeline();
      await afterChange(res, "Клип заменён растянутой версией");
      this.info = null; this.onSelection();
    } finally {
      this.rendering = false;
      btn.textContent = "Рендер и замена"; btn.disabled = !this.info; bar.hidden = true;
    }
  },

  async restore() {
    if (!this.info) return;
    const res = await gated("corner_restore", { id: this.info.id });
    if (!res || !res.ok) { if (res) toast(res.error || "Не получилось.", { kind: "error" }); return; }
    S.project = res.project; keepSelection(); renderTimeline();
    await afterChange(res, "Оригинал возвращён");
    this.info = null; this.onSelection();
  },

  /* ---------- мои пресеты ---------- */
  buildMyPresets() {
    const P = Object.keys(S.params);
    new PresetBar($("myWiggle"), "wiggle", {
      title: "Сохранить текущие настройки рысканья",
      collect: () => ({ ...Object.fromEntries(P.map((k) => [k, S.params[k]])), seed: S.seed, same_motion: S.same }),
      apply: (d, name) => {
        setSlidersFromConfig({ ...S.params, ...d });
        S.t0 = performance.now(); saveConfigSoon(); updateSelectionUI();
        toast(`Рысканье «${name}» — теперь нажми «Добавить рысканье»`);
      },
    });
    const needClip = () => { if (this.info) return true; toast("Сначала выбери видео или картинку на таймлайне.", { kind: "error" }); return false; };
    new PresetBar($("myCorner"), "corner", {
      title: "Сохранить растяжение (все ключи клипа)",
      canSave: needClip,
      collect: () => ({ keys: this.keys.map((k) => ({ t: k.t, pts: toUnit(k.pts, this.info.quad), ease: k.ease, r: +k.r || 0 })) }),
      apply: (d, name) => this.applyMyCorner(d, name),
    });
    new PresetBar($("myMods"), "mods", {
      title: "Сохранить стек эффектов",
      canSave: () => {
        if (this.mods.stack.length > 1) return true;
        toast("В стеке пока нет эффектов.", { kind: "error" }); return false;
      },
      collect: () => ({ stack: stackForPreset(this.mods.stack) }),
      apply: (d, name) => {
        if (!needClip()) return;
        this.mods = stackFromPreset(d.stack);
        this.syncModsUI(); this.modsChanged();
        toast(`Эффекты «${name}» применены`);
      },
    });
  },

  /* один ключ — форма для ключа под курсором; несколько — вся анимация на свои места от начала клипа */
  applyMyCorner(d, name) {
    if (!this.info) return toast("Сначала выбери видео или картинку на таймлайне.", { kind: "error" });
    const keys = (d.keys || []).slice().sort((a, b) => a.t - b.t);
    if (!keys.length) return;
    const q = this.info.quad;
    this.pause();
    if (keys.length === 1) {
      const k = this.keyHere();
      k.pts = fromUnit(keys[0].pts, q); k.r = keys[0].r || 0; delete k.flat; delete k.made;
      this.changed(); this.setTime(k.t);
      return toast(`«${name}» на ключе ${fmtTime(k.t, true)}`);
    }
    const dur = this.info.dur, tol = this.frameUs() / 2;
    const add = keys.filter((k) => k.t <= dur + tol).map((k) => ({ t: Math.min(dur, Math.round(k.t)), pts: fromUnit(k.pts, q), ease: k.ease || "smooth", r: k.r || 0 }));
    if (!add.length) return toast("Пресет длиннее этого клипа — ни один ключ не поместился.", { kind: "error" });
    const t0 = add[0].t, t1 = add[add.length - 1].t;
    this.keys = this.keys.filter((k) => k.t < t0 - tol || k.t > t1 + tol).concat(add);
    this.sortKeys(); this.changed();
    this.setTime(t0, { pause: false }); this.play();
    toast(`«${name}»: ${add.length} ${plural(add.length, "ключ", "ключа", "ключей")}, ${fmtTime(t0, true)} → ${fmtTime(t1, true)}`);
  },

  async init() {
    this.buildPresets();
    this.buildRadius();
    this.mods = normMods(null);
    this.fxUI = new FxStackUI($("fxList"), $("fxAdd"), {
      get: () => this.mods.stack, set: (v) => (this.mods.stack = v), changed: () => this.modsChanged(),
    });
    this.syncModsUI();
    // ширину таймлайна читаем при изменении размера, а не на каждом кадре
    const tl = $("tlTracks");
    this._tlw = tl.clientWidth;
    new ResizeObserver(() => { this._tlw = tl.clientWidth; }).observe(tl);
    const st = await api("ffmpeg");
    const sel = $("cpCodec");
    for (const [k, label] of Object.entries(st.codecs || {})) sel.append(new Option(label, k));
    $("modeWiggle").onclick = () => this.setMode("wiggle");
    $("modeCorner").onclick = () => this.setMode("corner");
    $("modeMods").onclick = () => this.setMode("mods");
    $("modeThumb").onclick = () => this.setMode("thumb");
    TH.init();
    this.buildMyPresets();
    MY.load();
    const svg = $("cpHandles");
    svg.addEventListener("pointerdown", (e) => this.pointerDown(e));
    svg.addEventListener("pointermove", (e) => this.pointerMove(e));
    svg.addEventListener("pointerup", () => this.pointerUp());
    svg.addEventListener("pointercancel", () => this.pointerUp());
    const sc = $("cpScrub");
    let scrubbing = false;
    sc.addEventListener("pointerdown", (e) => {
      if (!this.info) return;
      const kb = e.target.closest(".cp-key");
      if (kb) { const k = this.keys[+kb.dataset.idx]; this.setTime(k.t); this._sig = null; this.updateKeyPanel(); return; }
      scrubbing = true; sc.setPointerCapture(e.pointerId); this.scrubAt(e);
    });
    sc.addEventListener("pointermove", (e) => scrubbing && this.scrubAt(e));
    sc.addEventListener("pointerup", () => (scrubbing = false));
    $("cpEase").onchange = (e) => {
      const { at, prev } = this.currentKeyIndex(); const i = at >= 0 ? at : prev;
      if (i >= 0) { this.keys[i].ease = e.target.value; this.changed(); }
    };
    $("cpAddKey").onclick = () => { if (this.info) { this.pause(); this.keyHere(); this.changed(); } };
    $("cpDelKey").onclick = () => {
      const { at } = this.currentKeyIndex();
      if (at >= 0 && this.keys.length > 1) { this.keys.splice(at, 1); this.changed(); }
    };
    $("cpResetKey").onclick = () => {
      if (!this.info) return;
      this.pause(); const k = this.keyHere(); k.pts = this.info.quad.map((p) => p.slice()); this.changed();
    };
    $("cpBgToggle").onchange = (e) => { $("cpBg").toggleAttribute("hidden", !e.target.checked); };
    $("cpRender").onclick = () => this.renderAndReplace();
    $("cpRestore").onclick = () => this.restore();
    $("cpUndo").onclick = async () => { await run("undo"); this.info = null; this.onSelection(); };
    document.addEventListener("keydown", (e) => {
      if (!this.active || $("sheet").open) return;
      if (/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement?.tagName || "")) return;
      if (e.key.toLowerCase() === "k" || e.key.toLowerCase() === "л") { $("cpAddKey").click(); }
      if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
        e.preventDefault();
        const step = e.shiftKey ? 10 : 1;
        this.setTime(this.t + (e.key === "ArrowRight" ? 1 : -1) * step * this.frameUs());
      }
      if (e.key === "Delete" && document.activeElement?.classList.contains("cp-key") === false) $("cpDelKey").click();
    });
  },
};
window.CP = CP;
