"""
Растяжение по углам (corner pin) для клипов CapCut.

Ассет (видео или картинка) растягивается по четырём углам, углы анимируются
ключами с изингом. Результат рендерится ffmpeg в видео с прозрачностью на весь
кадр проекта и подменяет собой клип в проекте — место на таймлайне, длительность,
эффекты и остальное остаются. Оригинал запоминается и возвращается одной кнопкой.

Углы везде в порядке ffmpeg: [левый верх, правый верх, левый низ, правый низ],
в пикселях кадра проекта, y вниз.
"""

import copy
import json
import math
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import uuid
import zipfile
import zlib
from pathlib import Path

import capcut_wiggle as cw

CORNER_FILE = "corner_state.json"
RENDER_DIR = "wiggle_renders"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
US = 1_000_000

# ---------------------------------------------------------------- изинги ----
# одни и те же кривые в Python (рендер) и в JS (превью)
EASINGS = {
    "linear":  (0.0, 0.0, 1.0, 1.0),
    "smooth":  (0.42, 0.0, 0.58, 1.0),
    "out":     (0.16, 1.0, 0.3, 1.0),
    "in":      (0.7, 0.0, 0.84, 0.0),
    "back":    (0.34, 1.56, 0.64, 1.0),
    "hold":    None,  # стоять до следующего ключа
}


def _bez(a, b, c, d, u):
    m = 1 - u
    return m * m * m * a + 3 * m * m * u * b + 3 * m * u * u * c + u * u * u * d


def ease(name, p):
    p = min(1.0, max(0.0, p))
    if name == "hold":
        return 0.0 if p < 1 else 1.0
    x1, y1, x2, y2 = EASINGS.get(name) or EASINGS["smooth"]
    lo, hi = 0.0, 1.0
    for _ in range(40):
        mid = (lo + hi) / 2
        if _bez(0, x1, x2, 1, mid) < p:
            lo = mid
        else:
            hi = mid
    return _bez(0, y1, y2, 1, (lo + hi) / 2)


def corners_at(keys, t):
    """Углы в момент t (мкс от начала клипа). keys: [{t, pts, ease}] по возрастанию t."""
    keys = sorted(keys, key=lambda k: k["t"])
    if t <= keys[0]["t"]:
        return [tuple(p) for p in keys[0]["pts"]]
    if t >= keys[-1]["t"]:
        return [tuple(p) for p in keys[-1]["pts"]]
    for a, b in zip(keys, keys[1:]):
        if a["t"] <= t <= b["t"]:
            span = max(1, b["t"] - a["t"])
            e = ease(a.get("ease", "smooth"), (t - a["t"]) / span)
            return [(pa[0] + (pb[0] - pa[0]) * e, pa[1] + (pb[1] - pa[1]) * e)
                    for pa, pb in zip(a["pts"], b["pts"])]
    return [tuple(p) for p in keys[-1]["pts"]]


def radius_at(keys, t):
    """Скругление углов в момент t, в процентах от короткой стороны ассета (0..50)."""
    keys = sorted(keys, key=lambda k: k["t"])
    r = lambda k: float(k.get("r") or 0)
    if t <= keys[0]["t"]:
        return r(keys[0])
    if t >= keys[-1]["t"]:
        return r(keys[-1])
    for a, b in zip(keys, keys[1:]):
        if a["t"] <= t <= b["t"]:
            e = ease(a.get("ease", "smooth"), (t - a["t"]) / max(1, b["t"] - a["t"]))
            return r(a) + (r(b) - r(a)) * e
    return r(keys[-1])


# ------------------------------------------------------------ геометрия ----
def homography(src, dst):
    """3x3 (плоским списком) для перехода src -> dst по 4 точкам."""
    A, B = [], []
    for (x, y), (u, v) in zip(src, dst):
        A.append([x, y, 1, 0, 0, 0, -u * x, -u * y]); B.append(u)
        A.append([0, 0, 0, x, y, 1, -v * x, -v * y]); B.append(v)
    n = 8
    M = [A[i] + [B[i]] for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        M[c], M[p] = M[p], M[c]
        if abs(M[c][c]) < 1e-12:
            raise ValueError("углы вырождены")
        for r in range(n):
            if r != c:
                f = M[r][c] / M[c][c]
                M[r] = [a - f * b for a, b in zip(M[r], M[c])]
    return [M[i][n] / M[i][i] for i in range(n)] + [1.0]


def project_point(h, x, y):
    d = h[6] * x + h[7] * y + h[8]
    return ((h[0] * x + h[1] * y + h[2]) / d, (h[3] * x + h[4] * y + h[5]) / d)


def _quad(material, canvas_w, canvas_h, x, y, rot, sx, sy, flip):
    w = float(material.get("width") or canvas_w)
    h = float(material.get("height") or canvas_h)
    fit = min(canvas_w / w, canvas_h / h)  # CapCut вписывает ассет в кадр
    hw, hh = w * fit * sx / 2, h * fit * sy / 2
    cx = canvas_w / 2 + x * canvas_w / 2
    cy = canvas_h / 2 - y * canvas_h / 2   # в CapCut y вверх
    a = math.radians(rot)                  # по часовой
    ca, sa = math.cos(a), math.sin(a)
    pts = [(-hw, -hh), (hw, -hh), (-hw, hh), (hw, hh)]
    if flip.get("horizontal"):
        pts = [pts[1], pts[0], pts[3], pts[2]]
    if flip.get("vertical"):
        pts = [pts[2], pts[3], pts[0], pts[1]]
    return [[cx + px * ca - py * sa, cy + px * sa + py * ca] for px, py in pts]


def _static(seg):
    clip = seg.get("clip") or {}
    tr, sc = clip.get("transform") or {}, clip.get("scale") or {}
    return (float(tr.get("x", 0)), float(tr.get("y", 0)), float(clip.get("rotation", 0)),
            float(sc.get("x", 1)), float(sc.get("y", 1)), clip.get("flip") or {})


def clip_quad(seg, material, canvas_w, canvas_h):
    """Где клип стоит в кадре (по его положению, масштабу, повороту, без ключей)."""
    x, y, rot, sx, sy, flip = _static(seg)
    return _quad(material, canvas_w, canvas_h, x, y, rot, sx, sy, flip)


def motion_quads(seg, material, canvas_w, canvas_h, lists, uniform, fps, frames):
    """Рамка клипа на каждом кадре по ключам CapCut (позиция, поворот, масштаб). None — ключей нет."""
    if not lists:
        return None
    x0, y0, r0, sx0, sy0, flip = _static(seg)
    F = {p: cw._frames(kl) for p, kl in lists.items()}
    val = lambda p, t, d: cw.interp(F[p], t) if F.get(p) else d
    out = []
    for i in range(frames):
        t = i / fps * US
        sx = val(cw.KF_SCALE_X, t, sx0)
        sy = sx if uniform else val(cw.KF_SCALE_Y, t, sy0)
        out.append(_quad(material, canvas_w, canvas_h, val(cw.KF_POS_X, t, x0), val(cw.KF_POS_Y, t, y0),
                         val(cw.KF_ROT, t, r0), sx, sy, flip))
    return out


def affine(src, dst):
    """Аффинное преобразование рамки src в рамку dst (по трём углам): (a, b, c, d, e, f)."""
    ux, uy = src[1][0] - src[0][0], src[1][1] - src[0][1]
    vx, vy = src[2][0] - src[0][0], src[2][1] - src[0][1]
    Ux, Uy = dst[1][0] - dst[0][0], dst[1][1] - dst[0][1]
    Vx, Vy = dst[2][0] - dst[0][0], dst[2][1] - dst[0][1]
    det = ux * vy - vx * uy
    if abs(det) < 1e-9:
        return (1, 0, 0, 0, 1, 0)
    ia, ib, ic, id_ = vy / det, -vx / det, -uy / det, ux / det
    a, b = Ux * ia + Vx * ic, Ux * ib + Vx * id_
    d, e = Uy * ia + Vy * ic, Uy * ib + Vy * id_
    return (a, b, dst[0][0] - a * src[0][0] - b * src[0][1], d, e, dst[0][1] - d * src[0][0] - e * src[0][1])


def apply_affine(m, q):
    a, b, c, d, e, f = m
    return [(a * x + b * y + c, d * x + e * y + f) for x, y in q]


# --------------------------------------------------------------- ffmpeg ----
# GitHub отдаёт файлы через быстрый CDN, gyan.dev — запасной вариант
FFMPEG_URLS = [
    "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip",
    "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
]
DL_THREADS = 8
DL_CHUNK = 2 << 20

CODECS = {
    "prores": {"ext": ".mov", "label": "ProRes 4444 (MOV)",
               # фиксированное качество вместо подбора битрейта: в ~2.5 раза быстрее, визуально без потерь
               "args": ["-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le", "-qscale:v", "6",
                        "-vendor", "apl0", "-threads", "0"],
               "audio": ["-c:a", "pcm_s16le"]},
    "vp9":    {"ext": ".webm", "label": "WebM VP9",
               "args": ["-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-b:v", "12M", "-auto-alt-ref", "0", "-row-mt", "1",
                        "-deadline", "good", "-cpu-used", "4", "-threads", "0"],
               "audio": ["-c:a", "libopus"]},
    "qtrle":  {"ext": ".mov", "label": "QuickTime Animation (MOV)",
               "args": ["-c:v", "qtrle", "-pix_fmt", "argb"], "audio": ["-c:a", "pcm_s16le"]},
    "png":    {"ext": ".mov", "label": "PNG в MOV",
               "args": ["-c:v", "png", "-pix_fmt", "rgba"], "audio": ["-c:a", "pcm_s16le"]},
}


WIN = sys.platform.startswith("win")
_FF = {"path": None, "miss_at": 0.0, "checked": {}}


def _ff_candidates():
    exe = "ffmpeg.exe" if WIN else "ffmpeg"
    yield cw.BASE_DIR / "bin" / exe
    w = shutil.which("ffmpeg")
    if w:
        yield Path(w)
    if not WIN:
        return
    env = os.environ.get
    la, up, pd = Path(env("LOCALAPPDATA", "-")), Path(env("USERPROFILE", "-")), Path(env("ProgramData", "-"))
    yield la / "Microsoft" / "WinGet" / "Links" / exe
    pk = la / "Microsoft" / "WinGet" / "Packages"
    if pk.is_dir():
        yield from sorted(pk.glob("*FFmpeg*/*/bin/" + exe), reverse=True)
    yield up / "scoop" / "apps" / "ffmpeg" / "current" / "bin" / exe
    yield up / "scoop" / "shims" / exe
    yield pd / "chocolatey" / "bin" / exe
    yield Path("C:/ffmpeg/bin") / exe
    for pf in (env("ProgramFiles"), env("ProgramFiles(x86)")):
        if pf:
            yield Path(pf) / "ffmpeg" / "bin" / exe


def _ff_usable(path):
    """Подходит ли этот ffmpeg: нужен фильтр perspective и кодек ProRes."""
    key = str(path)
    if key in _FF["checked"]:
        return _FF["checked"][key]
    ok = False
    try:
        run = lambda *a: subprocess.run([key, "-hide_banner", *a], capture_output=True, text=True,
                                        errors="replace", timeout=15, creationflags=NO_WINDOW).stdout
        ok = " perspective " in run("-filters") and "prores_ks" in run("-encoders")
    except (OSError, subprocess.SubprocessError):
        ok = False
    _FF["checked"][key] = ok
    return ok


def ffmpeg_path():
    """Свой ffmpeg из bin/ или уже установленный в системе (winget, scoop, choco, PATH)."""
    p = _FF["path"]
    if p and Path(p).exists():
        return p
    if not p and time.time() - _FF["miss_at"] < 20:
        return None
    _FF["path"] = None
    for c in _ff_candidates():
        try:
            if c.is_file() and _ff_usable(c):
                _FF["path"] = str(c)
                return _FF["path"]
        except OSError:
            continue
    _FF["miss_at"] = time.time()
    return None


def _ff_help(ff):
    key = "help:" + ff
    if key not in _FF["checked"]:
        try:
            _FF["checked"][key] = subprocess.run([ff, "-hide_banner", "-h", "long"], capture_output=True, text=True,
                                                 errors="replace", timeout=15, creationflags=NO_WINDOW).stdout
        except (OSError, subprocess.SubprocessError):
            _FF["checked"][key] = ""
    return _FF["checked"][key]


def _graph_file_args(ff, path):
    """Как передать граф из файла: в ffmpeg 8 убрали -filter_complex_script, вместо него -/filter_complex."""
    if "filter_complex_script" in _ff_help(ff):
        return ["-filter_complex_script", str(path)]
    return ["-/filter_complex", str(path)]


def _thread_args(ff):
    return ["-filter_complex_threads", "0"] if "filter_complex_threads" in _ff_help(ff) else []


def _ff_reset():
    _FF.update(path=None, miss_at=0.0)
    _FF["checked"].clear()


def _req(url, rng=None, timeout=30):
    h = {"User-Agent": "CapCutWiggle"}
    if rng:
        h["Range"] = f"bytes={rng[0]}-{rng[1]}"
    return urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=timeout)


class _NoRange(Exception):
    pass


def _get(url, a, b, tries=3):
    """Байты a..b включительно."""
    for n in range(tries):
        try:
            with _req(url, (a, b)) as r:
                if r.status != 206:
                    raise _NoRange()
                data = r.read()
            if len(data) != b - a + 1:
                raise OSError("оборванный ответ")
            return data
        except _NoRange:
            raise
        except Exception:
            if n == tries - 1:
                raise
            time.sleep(0.5 * (n + 1))


class RemoteZip:
    """Читает zip по сети кусками: оглавление с конца файла, потом только нужный файл."""

    def __init__(self, url):
        with _req(url, (0, 0)) as r:
            if r.status != 206 or "Content-Range" not in r.headers:
                raise _NoRange()
            self.url = r.geturl()          # адрес после редиректа — не ходим через него 8 раз
            self.size = int(r.headers["Content-Range"].rsplit("/", 1)[1])
        tail_len = min(self.size, 1 << 16)
        tail = _get(self.url, self.size - tail_len, self.size - 1)
        i = tail.rfind(b"PK\x05\x06")
        if i < 0:
            raise ValueError("не zip")
        cd_size, cd_off = struct.unpack("<II", tail[i + 12:i + 20])
        if cd_off == 0xFFFFFFFF or cd_size == 0xFFFFFFFF:       # zip64
            j = tail.rfind(b"PK\x06\x07", 0, i)
            (z64_off,) = struct.unpack("<Q", tail[j + 8:j + 16])
            z = _get(self.url, z64_off, z64_off + 55)
            cd_size, cd_off = struct.unpack("<QQ", z[40:56])
        base = self.size - tail_len
        cd = tail[cd_off - base:cd_off - base + cd_size] if cd_off >= base else _get(self.url, cd_off, cd_off + cd_size - 1)
        self.entries = {}
        p = 0
        while p + 46 <= len(cd) and cd[p:p + 4] == b"PK\x01\x02":
            (method, crc, csize, usize, nlen, xlen, clen) = struct.unpack("<H4xIIIHHH", cd[p + 10:p + 34])
            (lho,) = struct.unpack("<I", cd[p + 42:p + 46])
            name = cd[p + 46:p + 46 + nlen].decode("utf-8", "replace")
            extra = cd[p + 46 + nlen:p + 46 + nlen + xlen]
            q = 0
            while q + 4 <= len(extra):                         # zip64: настоящие размеры в extra
                hid, hlen = struct.unpack("<HH", extra[q:q + 4])
                if hid == 1:
                    vals = list(struct.unpack(f"<{hlen // 8}Q", extra[q + 4:q + 4 + hlen // 8 * 8]))
                    if usize == 0xFFFFFFFF and vals: usize = vals.pop(0)
                    if csize == 0xFFFFFFFF and vals: csize = vals.pop(0)
                    if lho == 0xFFFFFFFF and vals: lho = vals.pop(0)
                q += 4 + hlen
            self.entries[name] = {"method": method, "crc": crc, "csize": csize, "usize": usize, "lho": lho}
            p += 46 + nlen + xlen + clen

    def find(self, base):
        for name, e in self.entries.items():
            if name.rsplit("/", 1)[-1].lower() == base:
                return e
        return None

    def extract(self, e, dst, on_progress):
        lh = _get(self.url, e["lho"], e["lho"] + 29)
        nlen, xlen = struct.unpack("<HH", lh[26:30])
        start = e["lho"] + 30 + nlen + xlen
        tmp = Path(str(dst) + ".part")
        _parallel_download(self.url, start, e["csize"], tmp, on_progress)
        _inflate(tmp, dst, e["method"], e["crc"])


def _parallel_download(url, start, length, out, on_progress):
    """Качает start..start+length несколькими соединениями сразу."""
    pieces = [(o, min(DL_CHUNK, length - o)) for o in range(0, length, DL_CHUNK)]
    lock = threading.Lock()
    got = [0]
    errors = []
    with open(out, "wb") as f:
        f.truncate(length)

        def worker():
            while not errors:
                with lock:
                    if not pieces:
                        return
                    off, n = pieces.pop(0)
                try:
                    data = _get(url, start + off, start + off + n - 1)
                except Exception as ex:
                    errors.append(ex)
                    return
                with lock:
                    f.seek(off)
                    f.write(data)
                    got[0] += n
                    on_progress(got[0], length)

        ts = [threading.Thread(target=worker, daemon=True) for _ in range(min(DL_THREADS, len(pieces)))]
        for t in ts:
            t.start()
        for t in ts:
            t.join()
    if errors:
        out.unlink(missing_ok=True)
        raise errors[0]


def _inflate(src, dst, method, crc):
    tmp = Path(str(dst) + ".tmp")
    c = 0
    with open(src, "rb") as fi, open(tmp, "wb") as fo:
        d = zlib.decompressobj(-15) if method == 8 else None
        if method not in (0, 8):
            raise RuntimeError("неизвестное сжатие в архиве")
        while True:
            chunk = fi.read(1 << 20)
            if not chunk:
                break
            out = d.decompress(chunk) if d else chunk
            c = zlib.crc32(out, c)
            fo.write(out)
        if d:
            out = d.flush()
            c = zlib.crc32(out, c)
            fo.write(out)
    src.unlink(missing_ok=True)
    if c & 0xFFFFFFFF != crc:
        tmp.unlink(missing_ok=True)
        raise RuntimeError("файл скачался с ошибкой, попробуй ещё раз")
    os.replace(tmp, dst)
    if not WIN:
        os.chmod(dst, 0o755)


class Downloader:
    """Скачивает только ffmpeg.exe (без ffprobe и ffplay) в папку приложения, в несколько потоков."""

    def __init__(self):
        self.state = {"running": False, "done": False, "error": "", "progress": 0.0, "mb": 0.0, "total_mb": 0.0}

    def start(self):
        if self.state["running"]:
            return
        self.state = {"running": True, "done": False, "error": "", "progress": 0.0, "mb": 0.0, "total_mb": 0.0}
        threading.Thread(target=self._run, daemon=True).start()

    def _progress(self, got, total):
        self.state.update(mb=got / 1e6, total_mb=total / 1e6, progress=got / total if total else 0.0)

    def _run(self):
        bin_dir = cw.BASE_DIR / "bin"
        bin_dir.mkdir(exist_ok=True)
        dst = bin_dir / ("ffmpeg.exe" if WIN else "ffmpeg")
        last_err = ""
        for url in FFMPEG_URLS:
            try:
                try:
                    z = RemoteZip(url)
                    e = z.find("ffmpeg.exe")
                    if not e:
                        raise RuntimeError("в архиве нет ffmpeg.exe")
                    z.extract(e, dst, self._progress)
                except _NoRange:
                    self._whole(url, bin_dir, dst)      # сервер не умеет кусками — качаем целиком
                _ff_reset()
                if not ffmpeg_path():
                    raise RuntimeError("скачанный ffmpeg не запускается")
                self.state.update(running=False, done=True, progress=1.0)
                return
            except Exception as ex:
                last_err = str(ex)
        self.state.update(running=False, done=False, error="Не удалось скачать ffmpeg: " + last_err)

    def _whole(self, url, bin_dir, dst):
        tmp = bin_dir / "ffmpeg-download.zip"
        try:
            with _req(url) as r, open(tmp, "wb") as f:
                total = int(r.headers.get("Content-Length") or 0)
                got = 0
                while True:
                    chunk = r.read(1 << 18)
                    if not chunk:
                        break
                    f.write(chunk)
                    got += len(chunk)
                    self._progress(got, total)
            with zipfile.ZipFile(tmp) as zf:
                name = next((n for n in zf.namelist() if n.rsplit("/", 1)[-1].lower() == "ffmpeg.exe"), None)
                if not name:
                    raise RuntimeError("в архиве нет ffmpeg.exe")
                with zf.open(name) as src, open(dst, "wb") as out:
                    shutil.copyfileobj(src, out, 1 << 20)
        finally:
            tmp.unlink(missing_ok=True)


# ---------------------------------------------------------------- рендер ----
def _tree(vals, lo, hi):
    """Значение по номеру кадра `in` — двоичное дерево if, чтобы выражение было неглубоким."""
    if hi - lo == 1:
        return f"{vals[lo]:.3f}"
    mid = (lo + hi) // 2
    return f"if(lt(in\\,{mid})\\,{_tree(vals, lo, mid)}\\,{_tree(vals, mid, hi)})"


def _corner_rows(r):
    """Строки маски одного угла радиусом r: сглаженный край (покрытие по расстоянию до дуги)."""
    n = int(math.ceil(r))
    rows = []
    for y in range(n):
        dy = max(0.0, r - (y + 0.5))
        row = bytearray(n)
        lo = max(0, int(r - math.sqrt(max(0.0, (r + 0.5) ** 2 - dy * dy)) - 1))
        x = lo
        while x < n:
            d = math.hypot(max(0.0, r - (x + 0.5)), dy)
            cov = r - d + 0.5
            if cov >= 1:
                row[x:] = b"\xff" * (n - x)
                break
            row[x] = 0 if cov <= 0 else int(cov * 255 + 0.5)
            x += 1
        rows.append(bytes(row))
    return rows


def mask_frame(w, h, r):
    """Кадр маски w×h (оттенки серого) со скруглёнными углами радиусом r пикселей."""
    r = min(float(r), w // 2, h // 2)
    if r < 0.5:
        return b"\xff" * (w * h)
    top = [c + b"\xff" * (w - 2 * len(c)) + c[::-1] for c in _corner_rows(r)]
    n = len(top)
    return b"".join(top) + b"\xff" * (w * (h - 2 * n)) + b"".join(reversed(top))


def radius_px(keys, fps, frames, asset_w, asset_h):
    short = min(asset_w, asset_h)
    return [round(radius_at(keys, i / fps * US) / 100 * short * 4) / 4 for i in range(frames)]


# ----------------------------------------------------------- модификаторы ----
# Модификаторы — стек эффектов. Порядок = порядок применения. Элемент {"type": "warp"} — растяжение по углам:
# эффекты выше него работают на плоскости клипа (до перспективы), ниже — на готовом кадре.
FX_DEFAULTS = {
    "color":   {"brightness": 0, "contrast": 0, "saturation": 0, "temperature": 0, "tint": 0, "hue": 0},
    "shade":   {"angle": -135, "strength": 60},
    "outline": {"width": 8, "soft": 0, "opacity": 100, "color": "#ffffff"},
    "shadow":  {"x": 18, "y": 24, "blur": 30, "opacity": 55, "color": "#000000"},
    "reflect": {"opacity": 35, "length": 45, "gap": 4},
    "pixel":   {"size": 8},
    "blur":    {"radius": 8},
}
PLANE_ONLY = {"reflect"}
_OLD_ORDER = (["color", "shade", "outline", "reflect"], ["shadow", "pixel"])   # как было до стека


def norm_mods(m):
    """{"stack": [...]} с ровно одним разделителем warp; старый формат (словарь переключателей) переводится."""
    m = m or {}
    if isinstance(m.get("stack"), list):
        raw = m["stack"]
    else:   # старые сохранения: включённые эффекты в прежнем порядке
        raw = [dict(m[t], type=t) for t in _OLD_ORDER[0] if (m.get(t) or {}).get("on")]
        raw.append({"type": "warp"})
        raw += [dict(m[t], type=t) for t in _OLD_ORDER[1] if (m.get(t) or {}).get("on")]
    out, warp = [], False
    for i, e in enumerate(raw):
        t = (e or {}).get("type")
        if t == "warp":
            if not warp:
                out.append({"type": "warp", "id": "warp"})
                warp = True
            continue
        if t not in FX_DEFAULTS:
            continue
        item = dict(FX_DEFAULTS[t])
        item.update({k: v for k, v in e.items() if k in FX_DEFAULTS[t]})
        item.update(type=t, id=str(e.get("id") or f"{t}{i}"), on=e.get("on", True) is not False)
        out.append(item)
    if not warp:
        out.append({"type": "warp", "id": "warp"})
    return {"stack": out}


def color_matrix(c):
    """Цветокоррекция одной матрицей 3x4 (sRGB 0..1) — та же, что feColorMatrix в превью."""
    def mul(A, B):   # 3x4 · 3x4 (как аффинные)
        return [[sum(A[i][k] * B[k][j] for k in range(3)) + (A[i][3] if j == 3 else 0) for j in range(4)]
                for i in range(3)]
    t, tn = float(c["temperature"]) / 100, float(c["tint"]) / 100
    M = [[1 + 0.22 * t + 0.08 * tn, 0, 0, 0], [0, 1 + 0.04 * t - 0.16 * tn, 0, 0], [0, 0, 1 - 0.22 * t + 0.08 * tn, 0]]
    sat = max(0.0, 1 + float(c["saturation"]) / 100)
    S = [[0.213 + 0.787 * sat, 0.715 - 0.715 * sat, 0.072 - 0.072 * sat, 0],
         [0.213 - 0.213 * sat, 0.715 + 0.285 * sat, 0.072 - 0.072 * sat, 0],
         [0.213 - 0.213 * sat, 0.715 - 0.715 * sat, 0.072 + 0.928 * sat, 0]]
    M = mul(S, M)
    a = math.radians(float(c["hue"]))
    ca, sa = math.cos(a), math.sin(a)
    Hm = [[0.213 + ca * 0.787 - sa * 0.213, 0.715 - ca * 0.715 - sa * 0.715, 0.072 - ca * 0.072 + sa * 0.928, 0],
          [0.213 - ca * 0.213 + sa * 0.143, 0.715 + ca * 0.285 + sa * 0.140, 0.072 - ca * 0.072 - sa * 0.283, 0],
          [0.213 - ca * 0.213 - sa * 0.787, 0.715 - ca * 0.715 + sa * 0.715, 0.072 + ca * 0.928 + sa * 0.072, 0]]
    M = mul(Hm, M)
    k = max(0.0, 1 + float(c["contrast"]) / 100)
    M = mul([[k, 0, 0, 0.5 - 0.5 * k], [0, k, 0, 0.5 - 0.5 * k], [0, 0, k, 0.5 - 0.5 * k]], M)
    b = max(0.0, 1 + float(c["brightness"]) / 100)
    return mul([[b, 0, 0, 0], [0, b, 0, 0], [0, 0, b, 0]], M)


def color_is_identity(c):
    return all(abs(float(c[k])) < 0.5 for k in ("brightness", "contrast", "saturation", "temperature", "tint", "hue"))


def write_cube(path, M, n=33):
    lines = [f"LUT_3D_SIZE {n}"]
    for bi in range(n):
        for gi in range(n):
            for ri in range(n):
                r, g, b = ri / (n - 1), gi / (n - 1), bi / (n - 1)
                lines.append(" ".join(f"{min(1.0, max(0.0, row[0] * r + row[1] * g + row[2] * b + row[3])):.5f}" for row in M))
    Path(path).write_text("\n".join(lines) + "\n", encoding="ascii")


def _color(c):
    c = str(c or "").lstrip("#")
    return "0x" + (c if len(c) == 6 and all(ch in "0123456789abcdefABCDEF" for ch in c) else "000000")


def wiggle_offsets(w):
    """t -> (dx, dy, поворот, масштаб) в пикселях кадра (y вниз) — тот же шум, что у рысканья в CapCut."""
    if not w or not w.get("params"):
        return None
    P = w["params"]
    pos, rot, scl = (float(P.get(k) or 0) for k in ("position_px", "rotation_deg", "scale_pct"))
    if not (pos or rot or scl):
        return None
    nz = cw.WiggleNoise(P, int(w.get("seed") or 0), 1, 1, True)
    return lambda t: (pos * nz._f(0, t), -pos * nz._f(1, t), rot * nz._f(2, t), 1 + scl / 100 * nz._f(3, t))


def wiggle_quad(q, off):
    """Рысканье вокруг центра самого клипа."""
    dx, dy, rot, sc = off
    cx, cy = sum(p[0] for p in q) / 4, sum(p[1] for p in q) / 4
    a = math.radians(rot)
    ca, sa = math.cos(a), math.sin(a)
    return [(cx + sc * ((x - cx) * ca - (y - cy) * sa) + dx, cy + sc * ((x - cx) * sa + (y - cy) * ca) + dy)
            for x, y in q]


def shade_map(quad, to_screen, rect, angle, strength, mw, mh):
    """Карта света мелким кадром (ffmpeg растянет): 128 — без изменений, меньше — тень, больше — свет.
    Градиент идёт по клипу (quad) от стороны, откуда светит. rect — какую область покрывает карта,
    to_screen — перевод её точек в координаты кадра."""
    a = math.radians(angle)
    lx, ly = math.cos(a), math.sin(a)
    cx, cy = sum(p[0] for p in quad) / 4, sum(p[1] for p in quad) / 4
    R = max(abs((x - cx) * lx + (y - cy) * ly) for x, y in quad) or 1.0
    k = strength / 100
    L, T, Rr, B = rect
    out = bytearray(mw * mh)
    i = 0
    for j in range(mh):
        v = T + (j + 0.5) / mh * (B - T)
        for n in range(mw):
            x, y = to_screen(L + (n + 0.5) / mw * (Rr - L), v)
            g = max(-1.0, min(1.0, ((x - cx) * lx + (y - cy) * ly) / R))
            out[i] = int(128 - 128 * min(1.0, k * 0.85 * -g)) if g < 0 else int(128 + 127 * min(1.0, k * 0.45 * g))
            i += 1
    return bytes(out)


def scale_of(quad, asset_w):
    """Сколько пикселей кадра в одном пикселе ассета (по исходной рамке клипа)."""
    return max(1e-6, math.hypot(quad[1][0] - quad[0][0], quad[1][1] - quad[0][1]) / max(1, asset_w))


class _Graph:
    def __init__(self, fps, D, tmp):
        self.parts, self.inputs, self.n, self.fps, self.D, self.tmp = [], [], 0, fps, D, tmp

    def lab(self, p="l"):
        self.n += 1
        return f"{p}{self.n}"

    def add(self, line):
        self.parts.append(line)

    def input(self, args, path=None):
        self.inputs.append((args, path))
        return len(self.inputs)          # 0 — исходник

    def pad(self, u, w, h, l, t, r, b):
        if not (l or t or r or b):
            return u
        o = self.lab()
        self.add(f"[{u}]pad={w + l + r}:{h + t + b}:{l}:{t}:color=black@0[{o}]")
        return o

    def solid(self, color, w, h):
        o = self.lab()
        self.add(f"color=c={color}:s={w}x{h}:r={self.fps}:d={self.D},format=rgba[{o}]")
        return o

    # ---- эффекты: вход u размером w×h -> выход того же размера
    def color(self, u, e):
        name = f"color{self.n}.cube"
        write_cube(self.tmp / name, color_matrix(e))
        o = self.lab()
        self.add(f"[{u}]lut3d=file={name}:interp=tetrahedral,format=rgba[{o}]")
        return o

    def blur(self, u, sigma):
        o = self.lab()
        self.add(f"[{u}]premultiply=inplace=1,gblur=sigma={sigma:.2f},unpremultiply=inplace=1,format=rgba[{o}]")
        return o

    def outline(self, u, w, h, wpx, sf, opacity, color):
        o1, o2, oa, olab, o = (self.lab() for _ in range(5))
        alpha = f"[{o2}]alphaextract"
        if wpx:
            alpha += f",gblur=sigma={max(0.5, wpx / 2):.2f}"
        alpha += ",lut=y='clip((val-3)*42,0,255)'"
        if sf >= 0.5:
            alpha += f",gblur=sigma={sf / 2:.2f}"
        alpha += f",lut=y='clip(val*{opacity / 100:.3f}-2,0,255)'"
        self.add(f"[{u}]split[{o1}][{o2}]")
        self.add(alpha + f"[{oa}]")
        oc = self.solid(_color(color), w, h)
        self.add(f"[{oc}][{oa}]alphamerge[{olab}]")
        self.add(f"[{olab}][{o1}]overlay=format=rgb[{o}]")
        return o

    def shadow(self, u, w, h, dx, dy, sigma, opacity, color):
        h1, h2, ha, hs, hsh, o = (self.lab() for _ in range(6))
        self.add(f"[{u}]split[{h1}][{h2}]")
        self.add(f"[{h2}]alphaextract" + (f",gblur=sigma={sigma:.2f}" if sigma >= 0.3 else "") + f"[{ha}]")
        hc = self.solid(_color(color), w, h)
        self.add(f"[{hc}][{ha}]alphamerge,colorchannelmixer=aa={opacity / 100:.3f}[{hs}]")
        hb = self.solid("black@0", w, h)
        self.add(f"[{hb}][{hs}]overlay={dx:.1f}:{dy:.1f}:format=rgb[{hsh}]")
        self.add(f"[{hsh}][{h1}]overlay=format=rgb[{o}]")
        return o

    def pixel(self, u, w, h, pa):
        o = self.lab()
        self.add(f"[{u}]premultiply=inplace=1,scale={max(1, round(w / pa))}:{max(1, round(h / pa))}:flags=area,"
                 f"unpremultiply=inplace=1,scale={w}:{h}:flags=neighbor,format=rgba[{o}]")
        return o

    def shade(self, u, w, h, maps, mw, mh):
        f = self.tmp / f"shade{self.n}.raw"
        f.write_bytes(maps)
        si = self.input(["-f", "rawvideo", "-pix_fmt", "gray", "-s", f"{mw}x{mh}", "-framerate", f"{self.fps}",
                         "-i", f.name], f)
        s1, s2, da, la, dl, ll, sc, sa, sal, x3, x4, o = (self.lab() for _ in range(12))
        self.add(f"[{si}:v]scale={w}:{h}:flags=bicubic,setpts=PTS-STARTPTS,split[{s1}][{s2}]")
        self.add(f"[{s1}]lut=y='clip((128-val)*2,0,255)'[{da}]")
        self.add(f"[{s2}]lut=y='clip((val-128)*2,0,255)'[{la}]")
        cb, cw_ = self.solid("black", w, h), self.solid("white", w, h)
        self.add(f"[{cb}][{da}]alphamerge[{dl}]")
        self.add(f"[{cw_}][{la}]alphamerge[{ll}]")
        self.add(f"[{u}]split[{sc}][{sa}]")
        self.add(f"[{sa}]alphaextract[{sal}]")
        self.add(f"[{sc}][{dl}]overlay=format=rgb[{x3}]")
        self.add(f"[{x3}][{ll}]overlay=format=rgb[{x4}]")
        self.add(f"[{x4}][{sal}]alphamerge[{o}]")
        return o

    def reflect(self, u, w, h, LH, gap, opacity):
        rows = b"".join(bytes([int(255 * opacity * (1 - (y + 0.5) / LH) ** 1.6)]) * w for y in range(LH))
        f = self.tmp / f"reflect{self.n}.pgm"
        f.write_bytes(f"P5\n{w} {LH}\n255\n".encode() + rows)
        gi = self.input(["-loop", "1", "-framerate", f"{self.fps}", "-t", self.D, "-i", f.name], f)
        r1, r2, r3, r4, r5, r6, r7, r8, r9, o = (self.lab() for _ in range(10))
        self.add(f"[{u}]split[{r1}][{r2}]")
        self.add(f"[{r2}]vflip,crop={w}:{LH}:0:0,split[{r3}][{r4}]")
        self.add(f"[{r4}]alphaextract[{r5}]")
        self.add(f"[{gi}:v]format=gray,setpts=PTS-STARTPTS[{r6}]")
        self.add(f"[{r5}][{r6}]blend=all_mode=multiply[{r7}]")
        self.add(f"[{r3}][{r7}]alphamerge[{r8}]")
        self.add(f"[{r1}]pad={w}:{h + gap + LH}:0:0:color=black@0[{r9}]")
        self.add(f"[{r9}][{r8}]overlay=0:{h + gap}:format=rgb[{o}]")
        return o


def _shade_maps(quads, screen_fns, rect, e, mw, mh):
    """Карты света на все кадры подряд (+2 запасных). screen_fns[i] — перевод точек карты в кадр на кадре i."""
    cache, out = {}, []
    n = len(quads)
    for i in list(range(n)) + [n - 1, n - 1]:
        q = quads[i]
        key = tuple(round(c, 2) for p in q for c in p)
        if key not in cache:
            if len(cache) > 4:
                cache.clear()
            cache[key] = shade_map(q, screen_fns[i], rect, float(e["angle"]), float(e["strength"]), mw, mh)
        out.append(cache[key])
    return b"".join(out)


def build_render(s, fps, frames, tmp):
    """Граф ffmpeg: ассет -> скругление -> эффекты на плоскости (по порядку стека) -> перспектива ->
    эффекты в кадре. Возвращает (граф, доп. входы [(аргументы, временный файл)], маски для stdin или None)."""
    aw, ah = int(s["asset_w"]), int(s["asset_h"])
    W, H = int(s["canvas_w"]), int(s["canvas_h"])
    keys = s["keys"]
    stack = [e for e in norm_mods(s.get("mods"))["stack"]]
    s0 = scale_of(s.get("quad") or [[0, 0], [aw, 0], [0, ah], [aw, ah]], aw)
    D = f"{frames / fps + 0.5:.3f}"
    wig = wiggle_offsets(s.get("wiggle"))
    motion, q0 = s.get("motion"), s.get("quad")
    quads = []
    for i in range(frames):
        t = i / fps * US
        q = corners_at(keys, t)
        if motion and q0:
            q = apply_affine(affine(q0, motion[min(i, len(motion) - 1)]), q)
        quads.append(wiggle_quad(q, wig(t)) if wig else q)

    G = _Graph(fps, D, tmp)
    feed = None
    timing = f"setpts=(PTS-STARTPTS)/{s['speed']:.6f}," if s["is_video"] else "setpts=PTS-STARTPTS,"
    u = G.lab("u")
    G.add(f"[0:v]{timing}fps={fps},format=rgba,scale={aw}:{ah},setsar=1[{u}]")

    # скругление углов — часть самого клипа, до всех эффектов
    radii = radius_px(keys, fps, frames, aw, ah)
    if max(radii) >= 0.5:
        if min(radii) != max(radii):
            mi = G.input(["-f", "rawvideo", "-pix_fmt", "gray", "-s", f"{aw}x{ah}", "-framerate", f"{fps}", "-i", "pipe:0"])
            feed = (aw, ah, radii)
        else:
            f = tmp / "mask.pgm"
            f.write_bytes(f"P5\n{aw} {ah}\n255\n".encode() + mask_frame(aw, ah, radii[0]))
            mi = G.input(["-loop", "1", "-framerate", f"{fps}", "-t", D, "-i", f.name], f)
        c, d, al, m, am, u2 = (G.lab() for _ in range(6))
        G.add(f"[{u}]split[{c}][{d}]")
        G.add(f"[{d}]alphaextract[{al}]")
        G.add(f"[{mi}:v]format=gray,scale={aw}:{ah},setpts=PTS-STARTPTS[{m}]")
        G.add(f"[{al}][{m}]blend=all_mode=multiply[{am}]")
        G.add(f"[{c}][{am}]alphamerge[{u2}]")
        u = u2

    wi = next(i for i, e in enumerate(stack) if e["type"] == "warp")
    plane = [e for e in stack[:wi] if e.get("on")]
    frame_fx = [e for e in stack[wi + 1:] if e.get("on") and e["type"] not in PLANE_ONLY]
    rect_h = [homography([(0, 0), (aw, 0), (0, ah), (aw, ah)], q) for q in quads]

    # ---- на плоскости: L,T,R,B — какую область (в пикселях ассета) занимает картинка
    L, T, R, B = 0, 0, aw, ah
    for e in plane:
        t = e["type"]
        w, h = R - L, B - T
        if t == "color" and not color_is_identity(e):
            u = G.color(u, e)
        elif t == "blur" and float(e["radius"]) > 0:
            sg = float(e["radius"]) / s0
            p = math.ceil(sg * 3)
            u = G.pad(u, w, h, p, p, p, p)
            L, T, R, B = L - p, T - p, R + p, B + p
            u = G.blur(u, sg)
        elif t == "outline" and float(e["opacity"]) > 0:
            wpx = max(0, round(float(e["width"]) / s0))
            sf = float(e["soft"]) / s0
            if wpx == 0 and sf < 0.5:
                continue
            p = wpx + (math.ceil(sf * 1.8) if sf >= 0.5 else 0)
            u = G.pad(u, w, h, p, p, p, p)
            L, T, R, B = L - p, T - p, R + p, B + p
            u = G.outline(u, R - L, B - T, wpx, sf, float(e["opacity"]), e["color"])
        elif t == "shadow" and float(e["opacity"]) > 0:
            dx, dy, sg = float(e["x"]) / s0, float(e["y"]) / s0, float(e["blur"]) / 2 / s0
            ext = math.ceil(sg * 3)
            l_, r_ = ext + math.ceil(max(0, -dx)), ext + math.ceil(max(0, dx))
            t_, b_ = ext + math.ceil(max(0, -dy)), ext + math.ceil(max(0, dy))
            u = G.pad(u, w, h, l_, t_, r_, b_)
            L, T, R, B = L - l_, T - t_, R + r_, B + b_
            u = G.shadow(u, R - L, B - T, dx, dy, sg, float(e["opacity"]), e["color"])
        elif t == "pixel" and float(e["size"]) >= 2:
            u = G.pixel(u, w, h, max(1.5, float(e["size"]) / s0))
        elif t == "shade" and float(e["strength"]) > 0:
            mw = 64
            mh = max(4, round(64 * h / w))
            fns = [(lambda x, y, hm=hm: project_point(hm, x, y)) for hm in rect_h]
            maps = _shade_maps(quads, fns, (L, T, R, B), e, mw, mh)
            u = G.shade(u, w, h, maps, mw, mh)
        elif t == "reflect" and float(e["opacity"]) > 0 and float(e["length"]) > 0:
            LH = max(2, min(h, round(float(e["length"]) / 100 * h)))
            gap = max(0, round(float(e["gap"]) / s0))
            u = G.reflect(u, w, h, LH, gap, float(e["opacity"]) / 100)
            B += gap + LH

    # ---- перспектива: углы всей картинки через ту же гомографию
    m = 4
    ext = [(L - m, T - m), (R + m, T - m), (L - m, B + m), (R + m, B + m)]
    per_frame = []
    for hm in rect_h:
        try:
            per_frame.append([project_point(hm, x, y) for x, y in ext])
        except (ValueError, ZeroDivisionError):
            per_frame.append(per_frame[-1] if per_frame else [(0, 0)] * 4)
    names = ["x0", "y0", "x1", "y1", "x2", "y2", "x3", "y3"]
    pp = []
    for ci in range(4):
        pp.append(f"{names[2 * ci]}='{_tree([p[ci][0] for p in per_frame], 0, frames)}'")
        pp.append(f"{names[2 * ci + 1]}='{_tree([p[ci][1] for p in per_frame], 0, frames)}'")
    pv = G.lab("p")
    G.add(f"[{u}]pad=iw+{2 * m}:ih+{2 * m}:{m}:{m}:color=black@0,scale={W}:{H}:flags=bilinear,"
          f"perspective={':'.join(pp)}:sense=destination:eval=frame:interpolation=linear,"
          f"trim=end_frame={frames}[{pv}]")
    u = pv

    # ---- в кадре
    for e in frame_fx:
        t = e["type"]
        if t == "color" and not color_is_identity(e):
            u = G.color(u, e)
        elif t == "blur" and float(e["radius"]) > 0:
            u = G.blur(u, float(e["radius"]))
        elif t == "outline" and float(e["opacity"]) > 0 and (float(e["width"]) > 0 or float(e["soft"]) >= 0.5):
            u = G.outline(u, W, H, round(float(e["width"])), float(e["soft"]), float(e["opacity"]), e["color"])
        elif t == "shadow" and float(e["opacity"]) > 0:
            u = G.shadow(u, W, H, float(e["x"]), float(e["y"]), float(e["blur"]) / 2, float(e["opacity"]), e["color"])
        elif t == "pixel" and float(e["size"]) >= 2:
            u = G.pixel(u, W, H, float(e["size"]))
        elif t == "shade" and float(e["strength"]) > 0:
            maps = _shade_maps(quads, [lambda x, y: (x, y)] * len(quads), (0, 0, W, H), e, 64, 36)
            u = G.shade(u, W, H, maps, 64, 36)
    G.add(f"[{u}]trim=end_frame={frames}[v]")
    return ";".join(G.parts), G.inputs, feed


def _atempo(speed):
    out, s = [], speed
    while s > 2.0:
        out.append("atempo=2.0"); s /= 2.0
    while s < 0.5:
        out.append("atempo=0.5"); s /= 0.5
    out.append(f"atempo={s:.6f}")
    return ",".join(out)


class RenderJob:
    def __init__(self, spec):
        self.spec = spec
        self.state = {"running": True, "done": False, "error": "", "progress": 0.0, "out": ""}
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        s = self.spec
        try:
            ff = ffmpeg_path()
            if not ff:
                raise RuntimeError("ffmpeg не найден")
            codec = CODECS.get(s["codec"]) or CODECS["prores"]
            fps = float(s["fps"]) or 30.0
            dur = s["dur"] / US
            frames = max(1, int(round(dur * fps)))
            out_dir = (Path(s["project_dir"]) / RENDER_DIR).resolve()
            out_dir.mkdir(exist_ok=True)
            out = out_dir / f"corner_{s['seg_id'][:8]}_{time.strftime('%Y%m%d-%H%M%S')}{codec['ext']}"
            tmp = Path(tempfile.mkdtemp(prefix="wiggle_render_"))
            graph, extra_inputs, feed = build_render(s, fps, frames, tmp)
            gfile = tmp / "graph.txt"
            gfile.write_text(graph, encoding="utf-8")
            animated = feed is not None
            cmd = [ff, "-y", "-hide_banner", "-loglevel", "error", "-nostats", "-progress", "pipe:1",
                   *_thread_args(ff)]
            if s["is_video"]:
                cmd += ["-ss", f"{s['src_start'] / US:.6f}", "-t", f"{dur * s['speed'] + 0.5:.6f}", "-i", s["src"]]
            else:
                cmd += ["-loop", "1", "-framerate", f"{fps}", "-t", f"{dur + 0.5:.6f}", "-i", s["src"]]
            for args, _ in extra_inputs:
                cmd += args
            cmd += _graph_file_args(ff, gfile) + ["-map", "[v]"]
            if s["is_video"] and s.get("has_audio"):
                cmd += ["-map", "0:a?", "-af", _atempo(s["speed"]), *codec["audio"]]
            cmd += codec["args"] + ["-r", f"{fps}", "-t", f"{dur:.6f}", str(out)]
            p = subprocess.Popen(cmd, stdin=subprocess.PIPE if animated else subprocess.DEVNULL, cwd=str(tmp),
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 text=True, encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
            if animated:
                threading.Thread(target=self._feed_masks, args=(p, *feed), daemon=True).start()
            for line in p.stdout:
                if line.startswith("out_time_us=") or line.startswith("out_time_ms="):
                    try:
                        us = int(line.split("=", 1)[1])
                        self.state["progress"] = min(0.99, us / (dur * US))
                    except ValueError:
                        pass
            err = p.stderr.read()
            p.wait()
            shutil.rmtree(tmp, ignore_errors=True)
            if p.returncode != 0 or not out.exists():
                raise RuntimeError(err.strip().splitlines()[-1] if err.strip() else f"ffmpeg завершился с кодом {p.returncode}")
            self.state.update(running=False, done=True, progress=1.0, out=str(out),
                              frames=frames, has_audio=bool(s["is_video"] and s.get("has_audio")))
        except Exception as e:
            self.state.update(running=False, done=False, error=str(e))


    @staticmethod
    def _feed_masks(p, w, h, radii):
        cache = {}
        try:
            for r in radii + radii[-1:] * 2:
                if r not in cache:
                    if len(cache) > 8:
                        cache.clear()
                    cache[r] = mask_frame(w, h, r)
                p.stdin.buffer.write(cache[r]) if hasattr(p.stdin, "buffer") else p.stdin.write(cache[r])
        except (BrokenPipeError, OSError, ValueError):
            pass
        finally:
            try:
                p.stdin.close()
            except OSError:
                pass


# ------------------------------------------------------- обложка (превью) ----
def render_layer_png(ff, s, out):
    """Один слой обложки: картинка с углами и стеком эффектов на весь кадр, PNG с прозрачностью."""
    tmp = Path(tempfile.mkdtemp(prefix="wiggle_thumb_"))
    try:
        graph, extra, _ = build_render(s, 30.0, 1, tmp)
        (tmp / "graph.txt").write_text(graph, encoding="utf-8")
        cmd = [ff, "-y", "-hide_banner", "-loglevel", "error", *_thread_args(ff),
               "-loop", "1", "-framerate", "30", "-t", "0.5", "-i", str(s["src"])]
        for args, _ in extra:
            cmd += args
        cmd += _graph_file_args(ff, tmp / "graph.txt") + ["-map", "[v]", "-frames:v", "1", "-c:v", "png",
                                                           "-pix_fmt", "rgba", str(out)]
        r = subprocess.run(cmd, cwd=str(tmp), capture_output=True, text=True, errors="replace",
                           creationflags=NO_WINDOW, stdin=subprocess.DEVNULL)
        if r.returncode != 0 or not Path(out).exists():
            raise RuntimeError((r.stderr.strip().splitlines() or [f"ffmpeg: код {r.returncode}"])[-1])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def compose_thumb(ff, W, H, bg, layers, out_png, out_jpg):
    """Склеить слои (снизу вверх) на фоне: [(png, прозрачность 0..1)]."""
    cmd = [ff, "-y", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", f"color=c={_color(bg)}:s={W}x{H}:d=1"]
    parts, cur = ["[0:v]format=rgba[b0]"], "b0"
    for i, (png, op) in enumerate(layers, 1):
        cmd += ["-i", str(png)]
        parts.append(f"[{i}:v]format=rgba" + (f",colorchannelmixer=aa={op:.3f}" if op < 0.999 else "") + f"[l{i}]")
        parts.append(f"[{cur}][l{i}]overlay=format=rgb[b{i}]")
        cur = f"b{i}"
    parts.append(f"[{cur}]format=rgb24,split[o1][o2]")
    cmd += ["-filter_complex", ";".join(parts), "-map", "[o1]", "-frames:v", "1", str(out_png),
            "-map", "[o2]", "-frames:v", "1", "-q:v", "2", str(out_jpg)]
    r = subprocess.run(cmd, capture_output=True, text=True, errors="replace", creationflags=NO_WINDOW,
                       stdin=subprocess.DEVNULL)
    if r.returncode != 0:
        raise RuntimeError((r.stderr.strip().splitlines() or [f"ffmpeg: код {r.returncode}"])[-1])


class ThumbJob:
    """Рендер обложки в фоне: каждый слой отдельно (тот же движок, что у клипов), потом склейка."""

    def __init__(self, W, H, bg, layers, out_dir):
        self.args = (W, H, bg, layers, Path(out_dir))
        self.state = {"running": True, "done": False, "error": "", "progress": 0.0, "png": "", "jpg": ""}
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        W, H, bg, layers, out_dir = self.args
        tmp = Path(tempfile.mkdtemp(prefix="wiggle_cover_"))
        try:
            ff = ffmpeg_path()
            if not ff:
                raise RuntimeError("ffmpeg не найден")
            out_dir.mkdir(parents=True, exist_ok=True)
            pngs = []
            for i, (spec, op) in enumerate(layers):
                out = tmp / f"layer{i}.png"
                render_layer_png(ff, spec, out)
                pngs.append((out, op))
                self.state["progress"] = (i + 1) / (len(layers) + 1)
            stamp = time.strftime("%Y%m%d-%H%M%S")
            png, jpg = out_dir / f"cover_{stamp}.png", out_dir / f"cover_{stamp}.jpg"
            compose_thumb(ff, W, H, bg, pngs, png, jpg)
            self.state.update(running=False, done=True, progress=1.0, png=str(png), jpg=str(jpg))
        except Exception as e:
            self.state.update(running=False, done=False, error=str(e))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


# ------------------------------------------------------- проект CapCut ----
def load_corner_state(project_dir):
    p = Path(project_dir) / CORNER_FILE
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    except (OSError, json.JSONDecodeError):
        return {}


def save_corner_state(project_dir, state):
    (Path(project_dir) / CORNER_FILE).write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")


def find_segment(draft, seg_id):
    for track in draft.get("tracks") or []:
        for seg in track.get("segments") or []:
            if seg.get("id") == seg_id:
                return track, seg
    return None, None


def find_video_material(draft, mid):
    for m in (draft.get("materials") or {}).get("videos") or []:
        if m.get("id") == mid:
            return m
    return None


def source_info(draft, seg, cstate, wstate=None):
    """Откуда брать картинку: оригинальный ассет (даже если клип уже заменён рендером).
    wstate — записи рысканья проекта: из ключей клипа нужны твои, без шума рысканья."""
    sid = str(seg.get("id"))
    st = cstate.get(sid)
    if st:
        mat = st["orig_material"]
        oseg = dict(seg, **st["orig_segment"])
        ws = {sid: st["orig_wiggle_state"]} if st.get("orig_wiggle_state") else {}
    else:
        mat = find_video_material(draft, seg.get("material_id"))
        oseg = seg
        ws = wstate or {}
    if not mat:
        return None
    w, h = _canvas(draft)
    src = oseg.get("source_timerange") or {}
    return {
        "material": mat,
        "path": mat.get("path") or "",
        "type": "photo" if mat.get("type") == "photo" else "video",
        "asset_w": int(mat.get("width") or w),
        "asset_h": int(mat.get("height") or h),
        "has_audio": bool(mat.get("has_audio")),
        "src_start": int(src.get("start") or 0),
        "speed": float(oseg.get("speed") or 1.0) or 1.0,
        "quad": clip_quad(oseg, mat, w, h),
        "keys": (st or {}).get("keys"),
        "cornered": bool(st),
        "seg": oseg,
        "lists": cw.base_lists_for(oseg, ws, "restore"),
        "uniform": bool((oseg.get("uniform_scale") or {}).get("on")),
    }


def _canvas(draft):
    c = draft.get("canvas_config") or {}
    return float(c.get("width") or 1920), float(c.get("height") or 1080)


def replace_with_render(drafts, seg_id, out_path, dur_us, has_audio, keys, cstate):
    """Подменяет ассет клипа рендером. Всё остальное у клипа остаётся.

    drafts — все копии файла проекта (основной и копия таймлайна): в них одинаковые
    изменения с одинаковыми id."""
    main = drafts[0]
    _, seg = find_segment(main, seg_id)
    if not seg:
        raise ValueError("клип не найден в проекте")
    prev = cstate.get(seg_id)
    if prev is None:
        mat = find_video_material(main, seg.get("material_id"))
        if not mat:
            raise ValueError("у клипа нет видео/картинки")
        speed_mats = {m.get("id"): m.get("speed") for m in (main.get("materials") or {}).get("speeds") or []
                      if m.get("id") in (seg.get("extra_material_refs") or [])}
        prev = {
            "orig_material": copy.deepcopy(mat),
            "orig_segment": {
                "material_id": seg.get("material_id"),
                "source_timerange": copy.deepcopy(seg.get("source_timerange")),
                "speed": seg.get("speed", 1.0),
                "clip": copy.deepcopy(seg.get("clip")),
                "uniform_scale": copy.deepcopy(seg.get("uniform_scale")),
                "common_keyframes": copy.deepcopy(seg.get("common_keyframes") or []),
                "speed_materials": speed_mats,
            },
        }
    w, h = _canvas(main)
    new_id = str(uuid.uuid4()).upper()
    local_id = str(uuid.uuid4())
    for d in drafts:
        _, s = find_segment(d, seg_id)
        if not s:
            continue
        base = find_video_material(d, s.get("material_id")) or prev["orig_material"]
        nm = copy.deepcopy(base)
        nm.update({
            "id": new_id, "type": "video", "path": str(out_path).replace("\\", "/"),
            "material_name": Path(out_path).name, "width": int(w), "height": int(h),
            "duration": int(dur_us), "has_audio": bool(has_audio), "local_material_id": local_id,
            "unique_id": "", "crop_ratio": "free", "crop_scale": 1.0,
            "crop": {"upper_left_x": 0.0, "upper_left_y": 0.0, "upper_right_x": 1.0, "upper_right_y": 0.0,
                     "lower_left_x": 0.0, "lower_left_y": 1.0, "lower_right_x": 1.0, "lower_right_y": 1.0},
        })
        vids = d.setdefault("materials", {}).setdefault("videos", [])
        # прошлый рендер этого клипа больше не нужен
        old = s.get("material_id")
        if prev is cstate.get(seg_id) and old != prev["orig_segment"]["material_id"]:
            vids[:] = [m for m in vids if m.get("id") != old]
        vids.append(nm)
        s["material_id"] = new_id
        s["source_timerange"] = {"start": 0, "duration": int(dur_us)}
        s["speed"] = 1.0
        for m in (d.get("materials") or {}).get("speeds") or []:
            if m.get("id") in (s.get("extra_material_refs") or []):
                m["speed"] = 1.0
        clip = s.setdefault("clip", {})
        clip["transform"] = {"x": 0.0, "y": 0.0}
        clip["scale"] = {"x": 1.0, "y": 1.0}
        clip["rotation"] = 0.0
        clip["flip"] = {"vertical": False, "horizontal": False}
        if isinstance(s.get("uniform_scale"), dict):
            s["uniform_scale"]["value"] = 1.0
        # положение/масштаб/поворот теперь внутри рендера
        s["common_keyframes"] = [kl for kl in s.get("common_keyframes") or []
                                 if kl.get("property_type") not in cw.WIGGLE_PROPS]
    prev["keys"] = keys
    prev["render"] = str(out_path)
    cstate[seg_id] = prev


def restore_original(drafts, seg_id, cstate):
    st = cstate.get(seg_id)
    if not st:
        return False
    o = st["orig_segment"]
    for d in drafts:
        _, s = find_segment(d, seg_id)
        if not s:
            continue
        cur = s.get("material_id")
        vids = d.setdefault("materials", {}).setdefault("videos", [])
        if cur != o["material_id"]:
            vids[:] = [m for m in vids if m.get("id") != cur]
        if not any(m.get("id") == o["material_id"] for m in vids):
            vids.append(copy.deepcopy(st["orig_material"]))
        s["material_id"] = o["material_id"]
        s["source_timerange"] = copy.deepcopy(o["source_timerange"])
        s["speed"] = o["speed"]
        s["clip"] = copy.deepcopy(o["clip"])
        if o.get("uniform_scale") is not None:
            s["uniform_scale"] = copy.deepcopy(o["uniform_scale"])
        s["common_keyframes"] = copy.deepcopy(o["common_keyframes"])
        for m in (d.get("materials") or {}).get("speeds") or []:
            if m.get("id") in o.get("speed_materials", {}):
                m["speed"] = o["speed_materials"][m["id"]]
    cstate.pop(seg_id, None)
    return True
