@echo off
chcp 65001 >nul
cd /d "%~dp0"
title CapCut Wiggle - debug

rem То же приложение, но с консолью: если что-то падает, здесь будет видна ошибка.
if exist "python\python.exe" ("python\python.exe" "app.py" & goto end)
where py >nul 2>nul && (py "app.py" & goto end)
where python >nul 2>nul && (python "app.py" & goto end)
echo Python не найден. Установи его с https://www.python.org/downloads/

:end
echo.
echo Приложение закрылось. Если выше есть ошибка - скопируй её текст.
pause
