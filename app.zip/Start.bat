@echo off
chcp 65001 >nul
cd /d "%~dp0"

rem Запуск приложения без консоли. Сначала встроенный Python (сборка с установщиком
rem или портативная), потом py-лаунчер и обычный Python из системы.
if exist "python\pythonw.exe" (start "" "python\pythonw.exe" "app.py" & exit /b 0)
where pyw >nul 2>nul && (start "" pyw "app.py" & exit /b 0)
where pythonw >nul 2>nul && (start "" pythonw "app.py" & exit /b 0)
where py >nul 2>nul && (start "" py "app.py" & exit /b 0)
where python >nul 2>nul && (start "" python "app.py" & exit /b 0)

echo.
echo  Python не найден.
echo  Скачай установщик CapCut Wiggle (в нём Python уже есть)
echo  или поставь Python с https://www.python.org/downloads/
echo  и при установке отметь "Add python.exe to PATH".
echo.
pause
